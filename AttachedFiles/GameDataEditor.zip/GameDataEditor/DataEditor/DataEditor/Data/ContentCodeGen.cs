﻿using System;
using System.Text;
using System.IO;
namespace DataEditor
{
	public class ContentCodeGen
	{
		public static void GenerateCodeFromContent(string path, ContentDataManager manager){
			//SchemeCodeGen.ClearFolder(path);
			if(System.IO.File.Exists(path+"/"+"GDInstKeys.cs")==true){
				System.IO.File.Delete(path+"/"+"GDInstKeys.cs");
			}

			StringBuilder totalStrBuilder = new StringBuilder();
			var list = manager.ContentList;
			for(int i = 0 ; i < list.Count ; i++){
				var content = list[i];
				if(content.isStruct == true)
					continue;
				totalStrBuilder.Append(string.Format(SINGLE_ITEM,content.Scheme.name,content.name,content.id));
			}
			string totalStr = string.Format(TOTAL_SHELL,totalStrBuilder.ToString());
			//Console.WriteLine(totalStr);
			System.IO.File.WriteAllText(path+"/"+"GDInstKeys.cs",totalStr);
		}
		public static string TOTAL_SHELL = "public class GDInstKey{{\n{0}\n}}\n";
		public static string SINGLE_ITEM = "\tpublic const int {0}_{1} = {2};\n";
	}
}

