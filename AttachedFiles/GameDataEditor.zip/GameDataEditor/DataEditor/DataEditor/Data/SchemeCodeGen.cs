﻿using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
namespace DataEditor
{
	public class SchemeCodeGen
	{
		public static string SCHEME_FILENAME = "GDSchemeDef.cs";
		public static string SCHEME_INST_FILENAME = "GDSchemeInst.cs";
		public static void ClearFolder(string FolderName)
		{
			DirectoryInfo dir = new DirectoryInfo(FolderName);
			foreach(FileInfo fi in dir.GetFiles())
			{
				fi.Delete();
			}

			foreach (DirectoryInfo di in dir.GetDirectories())
			{
				ClearFolder(di.FullName);
				di.Delete();
			}
		}
		public static void GenerateCodeFromScheme(string path,SchemeDataManager schemeManager){
			//ClearFolder(path);
			//if(System.IO.File.Exists(path);
			GenerateClassesFromScheme(path,schemeManager);
			GenerateInstCreatorFromScheme(path,schemeManager);
		}
		public static void GenerateInstCreatorFromScheme(string path, SchemeDataManager schemeManager){
			//StringBuilder builder = new StringBuilder();

			if(System.IO.File.Exists(path+"/"+SCHEME_INST_FILENAME)==true){
				System.IO.File.Delete(path+"/"+SCHEME_INST_FILENAME);
			}

			StringBuilder schemeToInstBuilder = new StringBuilder();
			StringBuilder schemeToTypeBuilder = new StringBuilder();
			var list = schemeManager.SchemeList;
			for(int i = 0 ; i < list.Count ; i++){
				var scheme = list[i];
				if(scheme.type == SchemeDataClass.Type.Enum ||
				   scheme.type == SchemeDataClass.Type.Flag_Enum)
					continue;
				schemeToInstBuilder.Append(string.Format(SCHEMEID_TO_INST,scheme.id,scheme.name));
				schemeToTypeBuilder.Append(string.Format(SCHEMEID_TO_TYPE,scheme.id,scheme.name));
			}
			string schemeToInstStr = string.Format(SCHEMEID_TO_INST_SHELL,schemeToInstBuilder.ToString());
			string schemeToTypeStr = string.Format(SCHEMEID_TO_TYPE_SHELL,schemeToTypeBuilder.ToString());
			string totalStr = string.Format(INST_CREATOR_TOTAL_SHELL,schemeToInstStr,schemeToTypeStr);
			//Console.WriteLine(totalStr);
			System.IO.File.WriteAllText(path+"/"+SCHEME_INST_FILENAME,totalStr);
		}
		public static string INST_CREATOR_TOTAL_SHELL = "public class GDInstCreator:IGDInstCreator{{\n" +
			"\tpublic static GDInstCreator Inst{{\n\t\tget{{\n\t\t\treturn new GDInstCreator();\n\t\t}}\n\t}}\n" +
			"{0}\n{1}\n}}\n";
		public static string SCHEMEID_TO_INST_SHELL = "\tpublic GDDataBase CreateInstanceBySchemeID(int schemeID){{\n" +
			"\t\tswitch(schemeID){{\n{0}\n\t\t}}\n" +
			"\t\treturn null;\n" +
			"\t}}\n";
		public static string SCHEMEID_TO_TYPE_SHELL = "\tpublic System.Type SchemeIDToType(int schemeID){{\n" +
			"\t\tswitch(schemeID){{\n{0}\n\t\t}}\n" +
			"\t\treturn null;\n" +
			"\t}}\n";
		public static string SCHEMEID_TO_INST = "\t\tcase {0}:\n\t\t\treturn new GD{1}();\n";
		public static string SCHEMEID_TO_TYPE = "\t\tcase {0}:\n\t\t\treturn typeof(GD{1});\n";


		public static void GenerateClassesFromScheme(string path,SchemeDataManager schemeManager){
			//First base classes!
			if(System.IO.File.Exists(path+"/"+SCHEME_FILENAME)==true){
				System.IO.File.Delete(path+"/"+SCHEME_FILENAME);
			}

			StringBuilder builder = new StringBuilder();
			builder.Append(HEADER);
			var list = schemeManager.SchemeList;
			List<string> flagEnumNames = new List<string>();
			for(int i = 0 ; i < list.Count ; i++){
				var scheme = list[i];

				if(scheme.type == SchemeDataClass.Type.Enum){
					StringBuilder enumNameBuilder = new StringBuilder();
					for(int j = 0 ; j < scheme.enumNames.Count ; j++){
						enumNameBuilder.AppendLine("\t"+scheme.enumNames[j] + "," );
					}
					//enumNameBuilder.AppendLine("\tMax");
					string totalStr = string.Format(ENUM_CLASS_SHELL,scheme.name,enumNameBuilder.ToString());
					builder.Append(totalStr);
					continue;
				}
				if(scheme.type == SchemeDataClass.Type.Flag_Enum){
					StringBuilder enumNameBuilder = new StringBuilder();
					for(int j = 0 ; j < scheme.enumNames.Count ; j++){
						enumNameBuilder.AppendLine("\t"+scheme.enumNames[j] + "=1<<"+j.ToString()+"," );
					}
					//enumNameBuilder.AppendLine("\tMax");
					string totalStr = string.Format(ENUM_CLASS_SHELL,scheme.name,enumNameBuilder.ToString());
					builder.Append(totalStr);
					flagEnumNames.Add(scheme.name);
					continue;
				}

				StringBuilder attribBuilder = new StringBuilder();
				StringBuilder loadxmlFuncBuilder = new StringBuilder();
				StringBuilder loadRefFuncBuilder = new StringBuilder();
				bool isRefExists = false;
				for(int j = 0 ; j < scheme.attrib.Count ; j++){
					SchemeDataAttrib attrib = scheme.attrib[j];
					//Property
					string varNameStr = attrib.name;

					string property_typeNameStr = "";
					//string property_arrayStr = "";

					string loadxml_typeNameStr = "";
					string loadxml_arrayStr = "";
					string loadxml_templateStr = "";

					switch(attrib.type){
						case SchemeDataAttrib.Type.BOOL:
							property_typeNameStr = "bool";
							loadxml_typeNameStr = "Bool";
						break;
						case SchemeDataAttrib.Type.INT:
							property_typeNameStr = "int";
							loadxml_typeNameStr = "Int";
						break;
						case SchemeDataAttrib.Type.FLOAT:
							property_typeNameStr = "float";
							loadxml_typeNameStr = "Float";
						break;
						case SchemeDataAttrib.Type.STRING:
							property_typeNameStr = "string";
							loadxml_typeNameStr = "String";
						break;
						case SchemeDataAttrib.Type.DATETIME:
							property_typeNameStr = "DateTime";
							loadxml_typeNameStr = "DateTime";
						break;
						case SchemeDataAttrib.Type.TIMESPAN:
							property_typeNameStr = "TimeSpan";
							loadxml_typeNameStr = "TimeSpan";
						break;
						case SchemeDataAttrib.Type.ENUM:
							property_typeNameStr = "GD"+attrib.CustomClass.name;
							loadxml_typeNameStr = "Enum";
							loadxml_templateStr = "<GD"+attrib.CustomClass.name+">";
						break;
						case SchemeDataAttrib.Type.FLAG_ENUM:
							property_typeNameStr = "GD"+attrib.CustomClass.name;
							loadxml_typeNameStr = "Flag";
							loadxml_templateStr = "<GD"+attrib.CustomClass.name+">";
						break;
						case SchemeDataAttrib.Type.CUSTOM:
							property_typeNameStr = "GD"+attrib.CustomClass.name;
							loadxml_typeNameStr = "Ref";
							loadxml_templateStr = "<GD"+attrib.CustomClass.name+">";
						break;
					}
					if(attrib.isArray == true){
						//property_arrayStr = "[]";
						property_typeNameStr = string.Format("List<{0}>",property_typeNameStr);
						loadxml_arrayStr = "Arr";
					}

					attribBuilder.Append(string.Format(PROPERTY_BASE_SHELL,property_typeNameStr,varNameStr));
					if(attrib.type == SchemeDataAttrib.Type.CUSTOM){
						isRefExists = true;
						loadRefFuncBuilder.Append(string.Format(LOAD_FROM_XML_ATTRIBUTE_REF_SHELL,
						                                            varNameStr,
						                                            loadxml_typeNameStr,
						                                            loadxml_arrayStr,
						                                            loadxml_templateStr,
						                                            varNameStr));
					}else{
						//if(attrib.type == SchemeDataAttrib.Type.

						loadxmlFuncBuilder.Append(string.Format(LOAD_FROM_XML_ATTRIBUTE_SHELL,
						                                            varNameStr,
						                                            loadxml_typeNameStr,
						                                            loadxml_arrayStr,
						                                            loadxml_templateStr,
						                                            varNameStr));
					}
				}
				if(isRefExists == true){
					loadxmlFuncBuilder.Append(REFEXISTS);
				}
				string loadxmlstr = string.Format(LOAD_FROM_XML_SHELL,loadxmlFuncBuilder.ToString());
				string loadrefstr = string.Format(LOAD_REF_SHELL,loadRefFuncBuilder.ToString());
				string totalClass = string.Format(CLASS_SHELL,scheme.name,
				                                  attribBuilder.ToString(),
				                                  loadxmlstr,
				                                  loadrefstr);
				builder.Append(totalClass);
			}
			StringBuilder enumBuilder = new StringBuilder();
			for(int i = 0 ; i < flagEnumNames.Count ; i++){
				enumBuilder.Append(string.Format(FLAG_ENUM_SINGLE_SHELL,flagEnumNames[i]));
			}
			builder.Append(string.Format(FLAG_ENUM_EXTENSION_SHELL,enumBuilder.ToString()));
			//Console.WriteLine(builder.ToString());
			System.IO.File.WriteAllText(path+"/"+SCHEME_FILENAME,builder.ToString());
		}

		public static string HEADER = "using System;\nusing System.Collections;\nusing System.Collections.Generic;\nusing System.Xml.Linq;\n";
		public static string CLASS_SHELL = "public partial class GD{0}:GDDataBase{{\n{1}\n{2}\n{3}\n}}\n";
		public static string LOAD_FROM_XML_SHELL = "\tpublic override void LoadFromXml(XElement xml,out bool isLinkNeeded){{\n" +
			"\t\tbase.LoadFromXml(xml,out isLinkNeeded);\n" +
			"{0}\n" +
			"\t}}";
		public static string LOAD_REF_SHELL = "\tpublic override void LoadReferences(GDManager manager,XElement xml){{\n" +
			"{0}\n" +
			"\t}}";
		public static string PROPERTY_BASE_SHELL = "\tpublic {0} {1}{{get;private set;}}\n";
		//public static string PROPERTY_CUSTOM_SHELL = "public GD{0}{1} {2};";

		public static string LOAD_FROM_XML_ATTRIBUTE_SHELL = "\t\t{0} = xml.Get{1}FromAttrib{2}{3}(\"{4}\");\n";
		public static string LOAD_FROM_XML_ATTRIBUTE_REF_SHELL = "\t\t{0} = xml.Get{1}FromAttrib{2}{3}(manager,\"{4}\");\n";
		public static string REFEXISTS = "\t\tisLinkNeeded = true;\n";

		public static string ENUM_CLASS_SHELL = "public enum GD{0}{{\n{1}}}\n";

		public static string FLAG_ENUM_EXTENSION_SHELL = "public static class GDEnumExtension{{\n{0}\n}}";
		public static string FLAG_ENUM_SINGLE_SHELL = "\tpublic static bool IsFlagSet(this GD{0} current, GD{0} value){{\n\t\treturn (current&value)!=0;\n\t}}\n" +
			"\tpublic static GD{0} AddFlag(this GD{0} current, GD{0} value){{\n\t\treturn current | value;\n\t}}\n"+
			"\tpublic static GD{0} RemoveFlag(this GD{0} current, GD{0} value){{\n\t\treturn current & ~value;\n\t}}\n";
	}
}

