﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace DataEditor
{
	public class SchemeDataManager{
		public int instCnt = 1;
		public Dictionary<int,SchemeDataClass> schemeDic = new Dictionary<int, SchemeDataClass>();
		public string SaveAsXml(){
			XElement xmlData = new XElement("root");
			xmlData.Add( new XElement("instCnt",instCnt.ToString()) );

			XElement schemeDic = new XElement("schemeDic");
			for(int i = 0 ; i < SchemeList.Count ; i++){
				schemeDic.Add( SchemeList[i].SaveAsXml() );
			}
			xmlData.Add(schemeDic);

			return xmlData.ToString();
		}
		public static SchemeDataManager LoadFromString(string data){
			XElement xmlData = XElement.Parse(data);
			SchemeDataManager temp = new SchemeDataManager();
			temp.instCnt = System.Convert.ToInt32( xmlData.Element("instCnt").Value );
			foreach(var item in xmlData.Element("schemeDic").Elements()){
				//Console.WriteLine(item.ToString());
				var realTemp = SchemeDataClass.LoadFromXml( item );
				temp.schemeDic.Add( realTemp.id, realTemp );
			}
			return temp;
		}
		public void RemoveScheme(int id){
			//var scheme = schemeDic[id];
			schemeDic.Remove(id);
			//Delete those has this scheme as customID
			foreach(var item in SchemeList){
				if(item.type != SchemeDataClass.Type.Normal)
					continue;
				int idx = 0;
				while(idx < item.attrib.Count){
					var attrib = item.attrib[idx];
					if((attrib.type == SchemeDataAttrib.Type.CUSTOM ||
					   attrib.type == SchemeDataAttrib.Type.ENUM ||
					    attrib.type == SchemeDataAttrib.Type.FLAG_ENUM) && attrib.customTypeID == id){
						item.attrib.RemoveAt(idx);
					}else{
						idx++;
					}
				}

			}
		}
		public List<SchemeDataClass> SchemeList
		{
			get
			{
				return (from item in schemeDic
				        //orderby item.Key ascending
				        select item.Value).ToList();
			}
		}
		public string[] SchemeNames{
			get{
				return (from item in schemeDic
				        where item.Value.type != SchemeDataClass.Type.Enum
				        where item.Value.type != SchemeDataClass.Type.Flag_Enum
				        //orderby item.Key ascending
				        select item.Value.name).ToArray();
			}
		}
		public string[] SchemeEnumNames{
			get{
				return (from item in schemeDic
				        where item.Value.type == SchemeDataClass.Type.Enum
				        //orderby item.Key ascending
				        select item.Value.name).ToArray();
			}
		}
		public string[] SchemeFlagEnumNames{
			get{
				return (from item in schemeDic
				        where item.Value.type == SchemeDataClass.Type.Flag_Enum
				        //orderby item.Key ascending
				        select item.Value.name).ToArray();
			}
		}
		public int GetSchemeIDByIdx(int idx){
			string name = SchemeNames[idx];
			return (from item in schemeDic
			        where item.Value.name == name
			        select item.Key).FirstOrDefault();
		}
		public SchemeDataClass GetSchemeByIdx(int idx){
			string name = SchemeNames[idx];
			return (from item in schemeDic
			        where item.Value.name == name
			        select item.Value).FirstOrDefault();
		}
		public int GetEnumIDByIdx(int idx){
			string name = SchemeEnumNames[idx];
			return (from item in schemeDic
				where item.Value.name == name
			 select item.Key).FirstOrDefault();
		}
		public int GetFlagEnumIDByIdx(int idx){
			string name = SchemeFlagEnumNames[idx];
			return (from item in schemeDic
			        where item.Value.name == name
			        select item.Key).FirstOrDefault();
		}
		public SchemeDataClass CreateScheme( SchemeDataClass.Type type, string name ){
			foreach(var pair in schemeDic){
				if( pair.Value.name == name ){
					return null;
				}
			}

			var item = new SchemeDataClass();
			item.id = instCnt;
			instCnt++;
			item.name = name;
			item.type = type;
			schemeDic.Add(item.id, item);
			return item;
		}
	}
	public class SchemeDataClass
	{
		public enum Type{
			Normal,
			Enum,
			Flag_Enum
		}
		public int id;
		public string name;
		public Type type;
		public List<SchemeDataAttrib> attrib = new List<SchemeDataAttrib>();
		public List<string> enumNames = new List<string>();
		public bool HasOnlyPrimitiveAttribute(){
			bool isPrimitive = true;
			foreach(var item in attrib){
				if(item.isArray == true){
					isPrimitive = false;
				}
				if(item.type == SchemeDataAttrib.Type.CUSTOM){
					if(item.isStruct == true)
						isPrimitive = false;
				}
			}
			return isPrimitive;
		}
		public XElement SaveAsXml(){
			XElement data = new XElement("class");
			data.Add( new XElement("id",id.ToString()));
			data.Add( new XElement("name",name));
			data.Add( new XElement("type",type.ToString()) );
			if(type == Type.Enum ||
			   type == Type.Flag_Enum){
				XElement enumXml = new XElement("enumNames");
				for(int i = 0; i < enumNames.Count ; i++){
					enumXml.Add( new XElement("obj",enumNames[i]) );
				}
				data.Add(enumXml);
				return data;
			}

			XElement attribXml = new XElement("attrib");
			for(int i = 0 ; i < attrib.Count ; i++){
				attribXml.Add( attrib[i].SaveAsXml() );
			}
			data.Add(attribXml);
			return data;
		}
		public static SchemeDataClass LoadFromXml(XElement element){
			SchemeDataClass temp = new SchemeDataClass();
			temp.id = System.Convert.ToInt32( element.Element("id").Value );
			temp.name = element.Element("name").Value;
			temp.type = (Type)System.Enum.Parse(typeof(Type), element.Element("type").Value );
			if(temp.type == Type.Enum ||
			   temp.type == Type.Flag_Enum){
				foreach(var item in element.Element("enumNames").Elements()){
					temp.enumNames.Add( item.Value );
				}
				return temp;
			}

			foreach(var item in element.Element("attrib").Elements()){
				temp.attrib.Add( SchemeDataAttrib.LoadFromXml(item) );
			}
			return temp;
		}
		public void CreateAttrib(SchemeDataAttrib.Type type, string name, bool isArray){
			SchemeDataAttrib temp = new SchemeDataAttrib();
			temp.type = type;
			temp.name = name;
			temp.isArray = isArray;
			attrib.Add(temp);
			//RearrangeAttrib();
		}
		public void RearrangeAttrib(){
			List<SchemeDataAttrib> arrangedList = new List<SchemeDataAttrib>();
			int idx = 0;
			//first normal ones.
			while(idx < attrib.Count){
				if(attrib[idx].isArray == false &&
				   attrib[idx].type != SchemeDataAttrib.Type.CUSTOM ){
					Console.WriteLine("first Attrib name="+attrib[idx].name);
					arrangedList.Add( attrib[idx] );
					attrib.RemoveAt(idx);
					continue;
				}
				idx++;
			}
			//first normal ones.
			idx = 0;
			while(idx < attrib.Count){
				if(attrib[idx].isArray == false &&
				   attrib[idx].type == SchemeDataAttrib.Type.CUSTOM &&
				   attrib[idx].isStruct == false){
					Console.WriteLine("second Attrib name="+attrib[idx].name);
					arrangedList.Add( attrib[idx] );
					attrib.RemoveAt(idx);
					continue;
				}
				idx++;
			}
			//structs
			idx = 0;
			while(idx < attrib.Count){
				if(attrib[idx].isArray == false &&
				   attrib[idx].isStruct == true){
					Console.WriteLine("third Attrib name="+attrib[idx].name);
					arrangedList.Add( attrib[idx] );
					attrib.RemoveAt(idx);
					continue;
				}
				idx++;
			}
			//others
			idx = 0;
			while(idx < attrib.Count){
				Console.WriteLine("else Attrib name="+attrib[idx].name);
				arrangedList.Add( attrib[idx] );
				idx++;
			}
			attrib = arrangedList;
		}
		public void CreateEnumAttrib(int customTypeID, string name, bool isArray){
			SchemeDataAttrib temp = new SchemeDataAttrib();
			temp.type = SchemeDataAttrib.Type.ENUM;
			temp.name = name;
			temp.isArray = isArray;
			temp.customTypeID = customTypeID;
			attrib.Add(temp);
			RearrangeAttrib();
		}
		public void CreateFlagEnumAttrib(int customTypeID, string name, bool isArray){
			SchemeDataAttrib temp = new SchemeDataAttrib();
			temp.type = SchemeDataAttrib.Type.FLAG_ENUM;
			temp.name = name;
			temp.isArray = isArray;
			temp.customTypeID = customTypeID;
			attrib.Add(temp);
			RearrangeAttrib();
		}
		public void RemoveAttrib(SchemeDataAttrib attribData){
			attrib.Remove(attribData);
		}
		public void CreateAttribCustom(int type, string name, bool isArray, bool isStruct){
			SchemeDataAttrib temp = new SchemeDataAttrib();
			temp.type = SchemeDataAttrib.Type.CUSTOM;
			temp.name = name;
			temp.customTypeID = type;
			temp.isArray = isArray;
			temp.isStruct = isStruct;
			attrib.Add(temp);
			RearrangeAttrib();
		}
	}
	public class SchemeDataAttrib{
		public enum Type{
			BOOL,
			INT,
			FLOAT,
			STRING,
			TIMESPAN,
			DATETIME,
			MAX,

			CUSTOM,
			ENUM,
			FLAG_ENUM,
		}
		public static string[] TypeNames{
			get{
				List<string> temp = new List<string>();
				for(int i = 0 ; i < (int)Type.MAX ; i++){
					temp.Add( ((Type)i).ToString() );
				}
				return temp.ToArray();
			}
		}
		public Type type;
		public string name;
		public bool isArray;
		public bool isStruct;

		public int customTypeID;
		public SchemeDataClass CustomClass{
			get{
				return DataEditorWindow.Inst.schemeData.schemeDic[customTypeID];
			}
		}
		public XElement SaveAsXml(){
			XElement temp = new XElement("attrib");
			temp.Add( new XElement("type",type.ToString() ) );
			temp.Add( new XElement("name",name));
			temp.Add( new XElement("isArray",isArray.ToString()));
			temp.Add( new XElement("isStruct",isStruct.ToString()));
			switch(type){
				case Type.CUSTOM:
				case Type.ENUM:
				case Type.FLAG_ENUM:
					temp.Add(new XElement("customTypeID",customTypeID.ToString()));
				break;
			}
			return temp;
		}
		public static SchemeDataAttrib LoadFromXml(XElement element){
			SchemeDataAttrib temp = new SchemeDataAttrib();
			temp.type = (Type)System.Enum.Parse(typeof(Type), element.Element("type").Value );
			temp.name = element.Element("name").Value;
			temp.isArray = System.Convert.ToBoolean(element.Element("isArray").Value);
			temp.isStruct = System.Convert.ToBoolean(element.Element("isStruct").Value);
			switch(temp.type){
				case Type.CUSTOM:
				case Type.FLAG_ENUM:
				case Type.ENUM:
					temp.customTypeID = System.Convert.ToInt32( element.Element("customTypeID").Value );
				break;
			}
			return temp;
		}
	}
}

