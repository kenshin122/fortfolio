﻿using System;
namespace DataEditor
{
	public class RuntimeSchemeData
	{
		public RuntimeSchemeData()
		{
		}
	}
}

