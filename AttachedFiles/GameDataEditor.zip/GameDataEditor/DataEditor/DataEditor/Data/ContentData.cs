﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;


namespace DataEditor
{
	public class ContentDataManager
	{
		public int instCnt = 1;
		public Dictionary<int,ContentData> contentDic = new Dictionary<int, ContentData>();

		public static HashSet<int> checkAbbandonedStructDic;
		public string SaveAsXml(){
			XElement xmlData = new XElement("root");
			xmlData.Add( new XElement("instCnt",instCnt.ToString()) );

			//Checking
			checkAbbandonedStructDic = new HashSet<int>();
			for(int i = 0 ; i < ContentList.Count ; i++){
				if(ContentList[i].isStruct == true){
					Console.WriteLine("Adding abandonable item id="+ContentList[i].id);
					checkAbbandonedStructDic.Add(ContentList[i].id);
				}
			}
			for(int i = 0 ; i < ContentList.Count ; i++){
				ContentList[i].CheckForAbandoned();
			}
			foreach(var key in checkAbbandonedStructDic){
				Console.WriteLine("Removing abandoned item id="+key);
				contentDic.Remove(key);
			}
			//Done

			XElement contentXml = new XElement("contentDic");
			for(int i = 0 ; i < ContentList.Count ; i++){
				contentXml.Add( ContentList[i].SaveAsXml() );
			}

			xmlData.Add(contentXml);

			return xmlData.ToString();
		}
		public void CheckForChange(){
			//Check For Deleted Contents.
			HashSet<int> deleted = new HashSet<int>();
			//Deleted.
			foreach(var pair in contentDic){
				if(deleted.Contains(pair.Value.schemeTypeID) == false){
					deleted.Add(pair.Value.schemeTypeID);
				}
			}
			foreach(var schemeID in deleted){
				if( DataEditorWindow.Inst.schemeData.schemeDic.ContainsKey( schemeID ) == false ){
					//Delete content that is schemeID

					var list = (from item in contentDic
					            select item.Value).ToList();
					foreach(var item in list){
						if(item.schemeTypeID == schemeID){
							//Console.WriteLine("CheckForChange Deleting Content="+item.name+" Scheme="+item.Scheme.name);
							contentDic.Remove(item.id);
							Console.WriteLine("CheckForChange Deleting Content="+item.name);
						}
					}
				}
			}

			//Check for attribute changes.
			Dictionary<int,ContentData> tempDic = new Dictionary<int, ContentData>(contentDic);
			foreach(var pair in tempDic){
				pair.Value.CheckForAttributeChange();
			}
		}
		public static ContentDataManager LoadFromString(string data){
			XElement xmlData = XElement.Parse(data);
			ContentDataManager temp = new ContentDataManager();
			temp.instCnt = System.Convert.ToInt32( xmlData.Element("instCnt").Value );
			foreach(var item in xmlData.Element("contentDic").Elements()){
				//Console.WriteLine(item.ToString());
				var realTemp = ContentData.LoadFromXml( item );
				temp.contentDic.Add( realTemp.id, realTemp );
			}
			return temp;
		}
		public bool IsDuplicateKey(int schemeTypeID, string name){
			//If there is same schemeType and name.. then this should not be created.
			foreach(var item in contentDic){
				if(item.Value.schemeTypeID == schemeTypeID &&
				   item.Value.name == name){
					return true;
				}
			}
			return false;
		}
		public int CreateContent(int schemeTypeID, string name, bool isStruct = false){

			//If there is same schemeType and name.. then this should not be created.
			if(IsDuplicateKey(schemeTypeID,name)==true){
				return -1;
			}

			ContentData temp = new ContentData();
			temp.id = instCnt;
			temp.schemeTypeID = schemeTypeID;
			instCnt++;
			if(isStruct == true){
				temp.name = "s_"+DataEditorWindow.Inst.schemeData.schemeDic[schemeTypeID].name+"_"+temp.id.ToString();
				temp.isStruct = true;
			}else{
				temp.name = name;
			}
			Console.WriteLine("Creating content scheme="+temp.Scheme.name+" schemeTypeID="+schemeTypeID);
			contentDic.Add( temp.id, temp);

			//Need to create default attributes
			var scheme = temp.Scheme;
			for(int i = 0 ; i < temp.Scheme.attrib.Count ; i++){
				var attrib = temp.Scheme.attrib[i];
				temp.CreateAttrib(attrib);
			}
			return temp.id;
		}
		public void DeleteContent(int id){
			contentDic.Remove(id);
		}
		public List<ContentData> ContentListWithoutStruct
		{
			get
			{
				return (from item in contentDic
				        orderby item.Key ascending
				        where item.Value.isStruct == false
				        select item.Value).ToList();
			}
		}
		public List<ContentData> ContentList
		{
			get
			{
				return (from item in contentDic
				        orderby item.Key ascending
				        select item.Value).ToList();
			}
		}
		public ContentData[] GetContentMatchesSchemeWithKeyAscending(int schemeID){
			return (from item in ContentListWithoutStruct
			        where item.schemeTypeID == schemeID
			        orderby item.name ascending
			        select item).ToArray();
		}
		public ContentData[] GetContentMatchesScheme(int schemeID){
			var list = ContentListWithoutStruct;
			List<ContentData> tempList = new List<ContentData>();
			for(int i = 0 ; i < list.Count ; i++){
				if(list[i].schemeTypeID == schemeID){
					tempList.Add(list[i]);
				}
			}
			return tempList.ToArray();
		}
	}
	public class ContentData{
		public int id;
		public int schemeTypeID;
		public bool isStruct;
		public string name;
		public Dictionary<string,ContentDataAttrib> attribDic = new Dictionary<string, ContentDataAttrib>();
		public void CheckForAbandoned(){
			//CheckForAbbandoned
			Console.WriteLine("Checking Abandon from instance="+name);
			foreach(var item in Scheme.attrib){
				if(item.isStruct == false)
					continue;
				if(item.isArray == false){
					int refID = System.Convert.ToInt32( attribDic[item.name].values[0] );
					if(ContentDataManager.checkAbbandonedStructDic.Contains(refID) == true){
						ContentDataManager.checkAbbandonedStructDic.Remove(refID);
					}
				}else{
					for(int i = 0 ; i < attribDic[item.name].arrSize ; i++){
						int refID = System.Convert.ToInt32( attribDic[item.name].values[i] );
						//Console.WriteLine("Checking Abandon Item id="+refID+" attrib="+item.name);
						if(ContentDataManager.checkAbbandonedStructDic.Contains(refID) == true){
							//Console.WriteLine("Item id="+refID+" is Used in attrib="+item.name);
							ContentDataManager.checkAbbandonedStructDic.Remove(refID);
						}
					}
				}
			}
		}
		public void CheckForAttributeChange(){
			//Check For Added, Updated , Deleted.
			HashSet<string> added = new HashSet<string>();
			HashSet<string> deleted = new HashSet<string>();
			Dictionary<string,SchemeDataAttrib> tempAttribDic = new Dictionary<string, SchemeDataAttrib>();
			//Deleted.
			foreach(var pair in attribDic){
				deleted.Add(pair.Key);
			}
			for(int i = 0 ; i < Scheme.attrib.Count ; i++){
				
				if(deleted.Contains(Scheme.attrib[i].name) == true){
					deleted.Remove(Scheme.attrib[i].name);
				}
			}
			//Added
			for(int i = 0 ; i < Scheme.attrib.Count ; i++){
				added.Add( Scheme.attrib[i].name );
				tempAttribDic.Add( Scheme.attrib[i].name, Scheme.attrib[i] );
			}
			foreach(var pair in attribDic){
				
				if(added.Contains( pair.Key ) ==true){
					added.Remove(pair.Key);
				}
			}

			//Perform
			foreach(var key in deleted){
				Console.WriteLine(string.Format("Adjusting Deleted Attribute scheme={0} itemName={1} attrib={2}",Scheme.name,name,key));
				attribDic.Remove(key);
			}
			foreach(var key in added){
				Console.WriteLine(string.Format("Adjusting Added Attribute scheme={0} itemName={1} attrib={2}",Scheme.name,name,key));
				CreateAttrib( tempAttribDic[key] );
			}



			//Updated
			for(int i = 0 ; i < Scheme.attrib.Count ; i++){
				var orig = Scheme.attrib[i];
				var target = attribDic[orig.name];
				if( target.IsChanged(orig) == true){
					Console.WriteLine(string.Format("Adjusting Updated Attribute scheme={0} itemName={1} attrib={2}",Scheme.name,name,orig.name));
					attribDic.Remove(orig.name);
					CreateAttrib(orig);
				}

			}
		}
		public XElement SaveAsXml(){
			XElement xmlData = new XElement(name);

			//xmlData.Add( new XElement("id",id.ToString()));
			//xmlData.Add( new XElement("schemeTypeID",schemeTypeID.ToString()));
			//xmlData.Add( new XElement("isStruct",isStruct.ToString()));
			//xmlData.Add( new XElement("name",name));

			xmlData.SetAttributeValue("id",id.ToString());
			xmlData.SetAttributeValue("schemeTypeID",schemeTypeID.ToString());
			xmlData.SetAttributeValue("isStruct",isStruct.ToString());


			//XElement attribDicXml = new XElement("attribDic");
			foreach(var pair in attribDic){
				xmlData.Add( pair.Value.SaveAsXml(pair.Key) );
			}


			//xmlData.Add(attribDicXml);
			return xmlData;
		}
		public static ContentData LoadFromXml(XElement xmlData){
			ContentData temp = new ContentData();
			temp.id = System.Convert.ToInt32( xmlData.Attribute("id").Value );
			temp.schemeTypeID = System.Convert.ToInt32( xmlData.Attribute("schemeTypeID").Value );
			temp.isStruct = System.Convert.ToBoolean( xmlData.Attribute("isStruct").Value );
			temp.name = xmlData.Name.ToString();
			foreach(var item in xmlData.Elements()){
				var attribData = ContentDataAttrib.LoadFromXml(item);
				temp.attribDic.Add( item.Name.ToString(), attribData );
			}
			return temp;
		}
		public SchemeDataClass Scheme{
			get{
				return DataEditorWindow.Inst.schemeData.schemeDic[schemeTypeID];
			}
		}

		public void CreateAttrib(SchemeDataAttrib attrib){
			ContentDataAttrib instAttrib = new ContentDataAttrib();
			for(int j = 0 ; j < ContentDataAttrib.MAX ; j++){
				switch(attrib.type){
					case SchemeDataAttrib.Type.BOOL:
						instAttrib.values[j] = false.ToString();

					break;
					case SchemeDataAttrib.Type.CUSTOM:
					case SchemeDataAttrib.Type.FLOAT:
					case SchemeDataAttrib.Type.INT:
						instAttrib.values[j] = "0";
					break;
					case SchemeDataAttrib.Type.ENUM:
						instAttrib.values[j] = "Invalid";
					break;
					case SchemeDataAttrib.Type.FLAG_ENUM:
						instAttrib.values[j] = "";
					break;
					case SchemeDataAttrib.Type.STRING:
						instAttrib.values[j] = "";
					break;
					case SchemeDataAttrib.Type.TIMESPAN:
						instAttrib.values[j] = "00:00:00";
					break;
					case SchemeDataAttrib.Type.DATETIME:
						instAttrib.values[j] = System.DateTime.Now.ToString();
					break;
				}
			}
			Console.WriteLine("Creating attrib name="+attrib.name+" type="+attrib.type.ToString());

			if(attrib.isStruct == true && attrib.isArray == false){
				instAttrib.arrSize=1;
				var structID = DataEditorWindow.Inst.contentData.CreateContent(attrib.customTypeID,"",true);
				instAttrib.values[0] = structID.ToString();
			}

			instAttrib.isArray = attrib.isArray;
			instAttrib.type = attrib.type;
			instAttrib.schemeID = attrib.customTypeID;

			this.attribDic.Add(attrib.name,instAttrib);
		}

		public ContentDataAttrib GetAttrib(SchemeDataAttrib origAttrib){
			ContentDataAttrib attrib = null;
			if( attribDic.ContainsKey(origAttrib.name) == false ){
				throw new Exception("No Attrib found! attrib="+origAttrib.name);
				return null;
			}

			attrib = attribDic[origAttrib.name];
			return attrib;
		}
		public int GetAttribSize(string name){
			if(attribDic.ContainsKey(name) == false ){
				throw new Exception("No Attrib found attrib="+name);
				return 0;
			}
			return attribDic[name].arrSize;
		}
		public void SetAttribSize(SchemeDataAttrib origAttrib, int size){
			ContentDataAttrib attrib = null;
			if(attribDic.ContainsKey(origAttrib.name) == false ){
				throw new Exception("No Attrib found! attrib="+origAttrib.name);
				return;
			}

			attrib = attribDic[origAttrib.name];

			if(size == attrib.arrSize)
				return;

			if( origAttrib.isStruct == true ){
				if(size < attrib.arrSize){
					//Remove which created by struct.
					// size = 2   arrSize = 5
					// 2 3 4 needs to be removed
					for(int i = size; i < attrib.arrSize ; i++){
						DataEditorWindow.Inst.contentData.contentDic.Remove( attrib[i] );
						attrib[i] = 0;
					}
				}else{
					//Add struct.
					for(int i = attrib.arrSize ; i < size ; i++){
						int createdID = DataEditorWindow.Inst.contentData.CreateContent(origAttrib.customTypeID,"",true);
						attrib[i] = createdID;
					}
				}
			}

			attrib.arrSize = size;
		}
	}
	public class ContentDataAttrib{
		public const int MAX = 200;
		//public bool isRef = false;
		public string[] values = new string[MAX];
		//public int[] refValues = new int[MAX];
		public int arrSize = 0;
		public bool isArray = false;
		public SchemeDataAttrib.Type type;
		public int schemeID;

		public List<string> GetFlagNameList(int idx){
			if(string.IsNullOrEmpty(values[idx]) == true){
				return new List<string>();
			}
			return values[idx].Split(',').ToList();
		}
		public void SetFlagNameList(int idx, List<string> _value){
			System.Text.StringBuilder builder = new System.Text.StringBuilder();
			for(int i = 0 ; i < _value.Count ; i++){
				builder.Append(_value[i]);
				if(i < _value.Count-1){
					builder.Append(',');
				}
			}
			values[idx] = builder.ToString();
		}
		public bool ContainsFlag(int idx, string _value){
			if(GetFlagNameList(idx).Contains(_value) == true){
				return false;
			}
			return true;
		}
		public void AddFlag(int idx, string _value){
			var list = GetFlagNameList(idx);
			list.Add(_value);
			SetFlagNameList(idx,list);
		}
		public void RemoveFlag(int _idx, int _index){
			var list = GetFlagNameList(_idx);
			list.RemoveAt(_index);
			SetFlagNameList(_idx,list);
		}
		public bool IsChanged(SchemeDataAttrib orig){
			if(orig.type != this.type ||
			   orig.isArray != this.isArray ||
			   orig.customTypeID != this.schemeID){
				return true;
			}

			if(type == SchemeDataAttrib.Type.ENUM){

				if(isArray == true){
					int idx = 0;
					while(idx < arrSize){
						bool isEnumValid = false;
						for(int j = 0 ; j < orig.CustomClass.enumNames.Count ; j++){
							if(values[idx] == orig.CustomClass.enumNames[j]){
								isEnumValid = true;
								break;
							}
						}
						if(isEnumValid == false){
							for(int i = idx ; i < arrSize-1 ; i++){
								values[i] = values[i+1];
							}
							arrSize--;
						}else{
							idx++;
						}
					}
				}else{
					bool isEnumValid = false;
					for(int j = 0 ; j < orig.CustomClass.enumNames.Count ; j++){
						if(values[0] == orig.CustomClass.enumNames[j]){
							isEnumValid = true;
							break;
						}
					}
					if(isEnumValid == false){
						return true;	
					}
				}
			}

			if(type == SchemeDataAttrib.Type.FLAG_ENUM){
				//If there is no name inside.. Adjust those values..
				for(int i = 0 ; i < arrSize ; i++){
					//Check if its there..
					List<string> currentNames = GetFlagNameList(i);
					int idx = 0;
					while(idx < currentNames.Count){
						bool contains = false;
						for(int j = 0 ; j < orig.CustomClass.enumNames.Count ; j++){
							if(orig.CustomClass.enumNames[j] == currentNames[idx]){
								contains = true;
								break;
							}
						}
						if(contains == false){
							currentNames.RemoveAt(idx);
						}else{
							idx++;
						}
					}
					SetFlagNameList(i, currentNames);
				}
			}

			return false;
		}
		public XElement SaveAsXml(string name){
			XElement temp = new XElement(name);
			temp.SetAttributeValue("isArray",isArray.ToString());
			temp.SetAttributeValue("type",type.ToString());
			temp.SetAttributeValue("schemeID",schemeID.ToString());
			if(isArray == false){
				temp.Value = values[0];
			}else{
				for(int i = 0 ; i < arrSize ; i++){
					temp.Add(new XElement("obj",values[i]));
				}
			}
			return temp;
		}
		public static ContentDataAttrib LoadFromXml(XElement xmlData){
			ContentDataAttrib temp = new ContentDataAttrib();
			temp.isArray = System.Convert.ToBoolean(xmlData.Attribute("isArray").Value);
			temp.type = (SchemeDataAttrib.Type)System.Enum.Parse(typeof(SchemeDataAttrib.Type),xmlData.Attribute("type").Value);
			temp.schemeID = System.Convert.ToInt32(xmlData.Attribute("schemeID").Value);
			if(temp.isArray == false){
				temp.values[0] = xmlData.Value;
			}else{
				int totalCnt = 0;
				foreach(var item in xmlData.Elements()){
					temp.values[totalCnt] = item.Value;
					totalCnt++;
				}
				temp.arrSize = totalCnt;
			}
			return temp;
		}
		public int this[int i]{
			get{
				return System.Convert.ToInt32(values[i]);
			}set{
				values[i] = value.ToString();
			}
		}

		public ContentData RefContent{
			get{
				return GetRefContent(0);
			}
		}
		public ContentData GetRefContent(int idx){
			return DataEditorWindow.Inst.contentData.contentDic[this[idx]];
		}
		public ContentData[] RefContents{
			get{
				List<ContentData> tempList = new List<ContentData>();
				for(int i = 0 ; i < arrSize ; i++){
					tempList.Add( DataEditorWindow.Inst.contentData.contentDic[this[i]] );
				}
				return tempList.ToArray();
			}
		}

	}
}

