﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Gtk;
using Gdk;

namespace DataEditor
{
	
	public class ExcelDataEditorWindow:VBox
	{
		static Pango.FontDescription defaultFont = Pango.FontDescription.FromString("Symbol 9");
		Gtk.Window window;
		VBox topVBox;
		VBox listVBox;
		HashSet<string> expandInfoHash;
		int selectedSchemeIdx;
		string keyName = "";
		public ExcelDataEditorWindow(Gtk.Window _window)
		{
			window = _window;
			//this.ShowAll();
		}
		public void OnAllRefresh(){
			expandInfoHash = new HashSet<string>();
			foreach (var item in this.AllChildren)
			{
				this.Remove((Widget)item);
			}

			if(DataEditorWindow.Inst.schemeData.schemeDic.Count <= 0){
				this.PackStart(DataEditorWindow.CreateLabel("You need scheme first",0),false,true,0);
				this.ShowAll();
				//this.Show();
				return;
			}

			DataEditorWindow.Inst.contentData.CheckForChange();

			topVBox = new VBox(false,0);
			//topVBox.Show();
			ScrolledWindow scroll = new ScrolledWindow();
			listVBox = new VBox();
			//listVBox.Show();
			scroll.AddWithViewport(listVBox);
			scroll.Show();
			this.PackStart(topVBox,false,true,0);
			this.PackStart(scroll,true,true,0);

			/*
			 * Top thingy
			 * */
			{
				System.Action createItemAction = ()=>{
					string reason;
					if( DataEditorWindow.CheckValidKeyName(keyName,out reason) == false){
						DataEditorWindow.ShowDialog(window,reason);
						return;
					}

					int schemeID = DataEditorWindow.Inst.schemeData.GetSchemeIDByIdx(selectedSchemeIdx);

					int contentID = DataEditorWindow.Inst.contentData.CreateContent(schemeID, keyName);
					if(contentID == -1){
						DataEditorWindow.ShowDialog(window,"Same key exists!");
						return;
					}
					OnRefreshNew();
				};
				HBox topHBox = new HBox();
				topVBox.PackStart(topHBox,false,true,0);
				topHBox.PackStart( DataEditorWindow.CreateComboBoxWithLabel("Table:",selectedSchemeIdx,DataEditorWindow.Inst.schemeData.SchemeNames,selected=>{
					selectedSchemeIdx = selected;
					OnRefreshNew();
				},100,150),false,true,0);
				topHBox.PackStart( DataEditorWindow.CreateEntryWithLabel("key:",keyName,entry=>{
					keyName = entry.Text;
					createItemAction();
				},entry=>{
					keyName = entry.Text;
				},100,150),false,true,0);
			}
			//OnRefresh();
			OnRefreshNew();
			this.ShowAll();
			//this.Show();
		}
		static int lowWidth = 50;
		static int intWidth = 50;
		static int defaultWidth = 100;


		public void OnRefreshNew(){
			foreach (var item in listVBox.AllChildren)
			{
				listVBox.Remove((Widget)item);
			}
			HBox topHBox = new HBox();
			listVBox.PackStart(topHBox,true,true,0);
			SchemeDataClass selectedScheme = DataEditorWindow.Inst.schemeData.GetSchemeByIdx(selectedSchemeIdx);
			//ContentData[] contentArr = DataEditorWindow.Inst.contentData.GetContentMatchesSchemeWithKeyAscending(selectedScheme.id);
			ContentData[] contentArr = DataEditorWindow.Inst.contentData.GetContentMatchesScheme(selectedScheme.id);

			//DeleteBtn
			VBox deleteVBox = new VBox();
			deleteVBox.PackStart(DataEditorWindow.CreateLabel("_"),false,true,0);
			topHBox.PackStart(deleteVBox,false,true,0);
			for(int k = 0 ; k < contentArr.Length ; k++){
				int curIdx = k;
				var tempBtn = DataEditorWindow.CreateButton("X",()=>{
					DataEditorWindow.Inst.contentData.DeleteContent(contentArr[curIdx].id);
					OnRefreshNew();
				});
				tempBtn.ModifyBase(StateType.Normal,new Color(255,200,200));
				deleteVBox.PackStart(tempBtn,false,true,0);
			}

			//Show key..
			HBox keyHBox = new HBox();
			VBox colVBox = new VBox();
			EventBox ev = new EventBox();
			//ev.Add(keyHBox);
			keyHBox.PackStart(colVBox,false,true,0);
			//ev.ModifyBg(StateType.Normal,new Color(255,255,0));
			topHBox.PackStart(keyHBox,false,true,0);
			colVBox.PackStart(DataEditorWindow.CreateLabel("key",0.0f,0.5f,defaultWidth),false,true,0);
			for(int k = 0 ; k < contentArr.Length ; k++){
				int curIdx = k;
				var tempEntry = DataEditorWindow.CreateEntry(contentArr[k].name,entry=>{
					string reason;
					if( DataEditorWindow.CheckValidKeyName(entry.Text,out reason) == false){
						DataEditorWindow.ShowDialog(window,reason);
						entry.Text = contentArr[curIdx].name;
						return;
					}

					if( DataEditorWindow.Inst.contentData.IsDuplicateKey(selectedScheme.id, entry.Text) == true){
						DataEditorWindow.ShowDialog(window,"Its duplicate key!");
						entry.Text = contentArr[curIdx].name;
						return;
					}

					//Before Changing it...

					contentArr[curIdx].name = entry.Text;
				},null,defaultWidth);
				tempEntry.ModifyBase(StateType.Normal,new Color(200,255,200));
				colVBox.PackStart(tempEntry,false,true,0);
			}

			//isDark = false;
			depth = new List<string>();
			var hBoxCombo = CreateHBox();
			OnContentDataDraw(hBoxCombo.First,selectedScheme, contentArr,0);
			topHBox.PackStart(hBoxCombo.Second,false,true,0);
			listVBox.ShowAll();
		}
		public CLTuple<HBox,EventBox> CreateHBox(){
			HBox newHBox = new HBox();
			EventBox eBox = new EventBox();
			eBox.Add(newHBox);
			return new CLTuple<HBox, EventBox>(newHBox,eBox);
		}

		//bool isDark = false;
		HashSet<string> expandHash = new HashSet<string>();
		List<string> depth;
		void PushDepth(string val){
			depth.Add(val);
		}
		void PopDepth(){
			depth.RemoveAt(depth.Count-1);
		}
		string CurrentDepthStr{
			get{
				System.Text.StringBuilder builder = new System.Text.StringBuilder();
				depth.ForEach(val=>{
					builder.Append(val);
				});
				return builder.ToString();
			}
		}
		bool GetCurrentExpandState{
			get{
				return expandHash.Contains( CurrentDepthStr );
			}
		}
		void SetExpandState(bool value, string depth){
			if(value == true){
				expandHash.Add( depth );
			}else{
				expandHash.Remove( depth );
			}
		}
		public Color GetDepthColor(int depth){
			byte value = (byte)(230 - (10*depth));
			return new Color(value,value,value);
			//switch(depth){
			//	case 0:
			//	return new Color(230,230,230);
			//		case 1:
			//	return new Color(210,210,210);
			//		default:
			//	return new Color(190,190,190);
			//}
			//return new Color(255,255,255);
		}
		public void OnContentDataDraw(HBox hBox, SchemeDataClass scheme, ContentData[] contentArr,int depth){
			//HBox hBox = new HBox();
			//EventBox eBox = new EventBox();
			//eBox.Add(hBox);
			//eBox.ModifyBg(StateType.Normal,GetDepthColor(depth));
			for(int i = 0 ; i < scheme.attrib.Count ; i++){
				var attrib = scheme.attrib[i];
				if(attrib.isArray == true){
					//Label..
					VBox arrColumnVBox = new VBox();
					CLTuple<HBox,EventBox> newHBox = null;
					newHBox = CreateHBox();
					//newHBox.Second.ModifyBg(StateType.Normal,GetDepthColor(depth+1));
					//arrColumnVBox
					newHBox.First.PackStart(arrColumnVBox,false,true,0);
					hBox.PackStart(newHBox.Second);

					PushDepth(attrib.name);
					string currDepth = CurrentDepthStr;
					bool currExpand = GetCurrentExpandState;
					PopDepth();

					//HBox hiddableHBox = new HBox();
					//hBox.PackStart(hiddableHBox,false,true,0);

					//if(currExpand == false){
						
					//}else{
					//	hBox.PackStart(arrColumnVBox,false,true,0);
					//}
					HBox insideHBox = new HBox();
					newHBox.First.PackStart(insideHBox,false,true,0);
					//insideHBox.NoShowAll = true;

					arrColumnVBox.PackStart( DataEditorWindow.CreateCheckButtonWithLabel(attrib.name,currExpand,res=>{
						SetExpandState(res,currDepth);
						insideHBox.NoShowAll = false;
						if(res == false){
							newHBox.Second.ModifyBg(StateType.Normal,GetDepthColor(depth+1));
							insideHBox.ShowAll();
						}else{
							newHBox.Second.ModifyBg(StateType.Normal,GetDepthColor(depth));
							insideHBox.Hide();
						}
						//OnRefreshNew();
					},defaultWidth),false,true,0);
					for(int j = 0 ; j < contentArr.Length ; j++){
						var contentAttrib = contentArr[j].GetAttrib(attrib);
						int curIdx = j;
						var sizeEntry = DataEditorWindow.CreateEntryWithLabel("s:",contentAttrib.arrSize.ToString(),entry=>{
							int size = 0;
							if( int.TryParse(entry.Text,out size) == false){
								return;
							}
							if(size < 0)
								return;
							contentArr[curIdx].SetAttribSize(attrib, size);
							OnRefreshNew();
						},null,10,20);
						foreach(var item in sizeEntry.AllChildren){
							if(item.GetType() == typeof(Entry)){
								((Entry)item).ModifyBase(StateType.Normal,new Color(200,200,255));
							}
						}
						arrColumnVBox.PackStart(sizeEntry,false,true,0);
					}




					//Find biggest array number

					int biggestArrCnt = 0;
					for(int j = 0 ; j < contentArr.Length ; j++){
						var contentAttrib = contentArr[j].GetAttrib(attrib);
						if(biggestArrCnt < contentAttrib.arrSize){
							biggestArrCnt = contentAttrib.arrSize;
						}
					}
					for(int j = 0 ; j < biggestArrCnt ; j++){
						if(attrib.isStruct == true){
							//Gather all struct as list.
							List<ContentData> arrStructList = new List<ContentData>();
							for(int k = 0 ; k < contentArr.Length ; k++){
								var contentAttrib = contentArr[k].GetAttrib(attrib);
								if(j < contentAttrib.arrSize){
									arrStructList.Add( contentAttrib.GetRefContent(j) );
								}else{
									arrStructList.Add( null );
								}
							}
							//DoPrimitive!
							//OnContentData
							PushDepth(attrib.name);

							//OnContentDataDraw(newHBox.First,attrib.CustomClass,arrStructList.ToArray(),depth+1);
							OnContentDataDraw(insideHBox,attrib.CustomClass,arrStructList.ToArray(),depth+1);
							//var tempHBox = OnContentDataDraw(attrib.CustomClass,arrStructList.ToArray());
							//hBox.PackStart(tempHBox.Second,false,true,0);
							PopDepth();
						}else{
							VBox arrVBox = new VBox();
							//newHBox.First.PackStart(arrVBox,false,true,0);
							insideHBox.PackStart(arrVBox,false,true,0);
							//hBox.PackStart(arrVBox,false,true,0);
							arrVBox.PackStart(DataEditorWindow.CreateLabel(j.ToString()+":",0.0f,0.5f,defaultWidth),false,true,0);
							//ThisIsPrimitive..
							//VBox sampleVBox = new VBox();
							//hBox.PackStart(sampleVBox,false,true,0);
							//sampleVBox.PackStart(DataEditorWindow.CreateLabel("",0.5f,0.5f,defaultWidth),false,true,0);
							for(int k = 0 ; k < contentArr.Length ; k++){
								var contentAttrib = contentArr[k].GetAttrib(attrib);
								if(j < contentAttrib.arrSize){
									arrVBox.PackStart(GetInputThingFromAttrib(contentArr[k],attrib,contentAttrib,j),false,true,0);
								}else{
									arrVBox.PackStart(DataEditorWindow.CreateLabel("Empty",0.5f,0.5f,defaultWidth),false,true,0);
								}
							}
						}
					}
					if(currExpand == false){
						newHBox.Second.ModifyBg(StateType.Normal,GetDepthColor(depth+1));
						//insideHBox.ShowAll();
					}else{
						newHBox.Second.ModifyBg(StateType.Normal,GetDepthColor(depth));
						insideHBox.NoShowAll = true;
						//insideHBox.Hide();
					}

				}else{
					if(attrib.isStruct == true){
						//HBox insideHBox = new HBox();
						//newHBox.First.PackStart(insideHBox,false,true,0);
						//var structHBox = CreateHBox();
						//structHBox.Second.ModifyBg(StateType.Normal,GetDepthColor(depth+1));
						//hBox.PackStart(structHBox.First);

						var lab = DataEditorWindow.CreateLabel(attrib.name);
						//lab.ModifyFont(defaultFont);
						VBox vBox = new VBox();
						vBox.PackStart(lab,false,true,0);
						hBox.PackStart(vBox,false,true,0);


						//Gather all struct as list.
						List<ContentData> arrStructList = new List<ContentData>();
						for(int k = 0 ; k < contentArr.Length ; k++){
							var contentAttrib = contentArr[k].GetAttrib(attrib);
							arrStructList.Add( contentAttrib.RefContent );
						}
						//DoPrimitive!
						//OnContentData
						PushDepth(attrib.name);
						//var tempHBox = OnContentDataDraw(hBox,attrib.CustomClass,arrStructList.ToArray(),depth);
						//hBox.PackStart(tempHBox.Second,false,true,0);
						OnContentDataDraw(hBox,attrib.CustomClass,arrStructList.ToArray(),depth+1);
						PopDepth();
					}else{
						//ThisIsPrimitive
						VBox colVBox = new VBox();
						hBox.PackStart(colVBox,false,true,0);
						colVBox.PackStart(DataEditorWindow.CreateLabel(attrib.name,0.0f,0.5f,defaultWidth),false,true,0);
						for(int k = 0 ; k < contentArr.Length ; k++){
							if(contentArr[k] == null){
								colVBox.PackStart(DataEditorWindow.CreateLabel("Empty",0.5f,0.5f,defaultWidth),false,true,0);
								continue;
							}
							var contentAttrib = contentArr[k].GetAttrib(attrib);
							colVBox.PackStart(GetInputThingFromAttrib(contentArr[k],attrib,contentAttrib,0),false,true,0);
						}
					}
				}
			}
			//return new CLTuple<HBox,EventBox>(hBox,eBox);
		}

		public Widget GetInputThingFromAttrib(ContentData rootContent, SchemeDataAttrib attrib, ContentDataAttrib tempAttrib, int idx){
			int reqSize = defaultWidth;
			switch(attrib.type){
				case SchemeDataAttrib.Type.DATETIME:
				case SchemeDataAttrib.Type.TIMESPAN:
				case SchemeDataAttrib.Type.FLOAT:
				case SchemeDataAttrib.Type.INT:
				case SchemeDataAttrib.Type.FLAG_ENUM:
				case SchemeDataAttrib.Type.STRING:{
						return DataEditorWindow.CreateEntry(tempAttrib.values[idx],entry=>{
							tempAttrib.values[idx] = entry.Text;
						},entry=>{
							tempAttrib.values[idx] = entry.Text;
						},reqSize);
					}
				case SchemeDataAttrib.Type.CUSTOM:{
						ContentData[] contentMatchArr = DataEditorWindow.Inst.contentData.GetContentMatchesScheme(attrib.customTypeID);
						List<string> namesOfContents = (from item in contentMatchArr
						                                select item.name).ToList();
						namesOfContents.Insert(0,"Null");
						
						List<int> idOfContents = (from item in contentMatchArr
						                          select item.id).ToList();
						idOfContents.Insert(0,0);

						int currentSelected = 0;
						int idOfContent = System.Convert.ToInt32(tempAttrib.values[idx]);
						for(int i = 0 ; i < idOfContents.Count ; i++){
							if(idOfContent == idOfContents[i]){
								currentSelected = i;
								break;
							}
						}
						HBox tempHBox = new HBox();
						tempHBox.PackStart(DataEditorWindow.CreateComboBox(currentSelected,namesOfContents.ToArray(),selected=>{
							tempAttrib.values[idx] = idOfContents[selected].ToString();
						},reqSize-20),true,true,0);
						//tempHBox.PackStart(DataEditorWindow.CreateComboBox(currentSelected,namesOfContents,selected=>{
						//	tempAttrib.values[idx] = idOfContents[selected].ToString();
						//},reqSize-20),true,true,0);
						//tempHBox.PackStart(DataEditorWindow.CreateButton("L",()=>{
						//	for(int i = 0 ; i < contentMatchArr.Length ; i++){
						//		if(contentMatchArr[i].name == rootContent.name){
						//			tempAttrib.values[idx] = idOfContents[i].ToString();
						//			OnRefresh(rootContent);
						//			return;
						//		}
						//	}
						//},20),false,true,0);
						return tempHBox;
					}
				case SchemeDataAttrib.Type.BOOL:{

						bool isTrue = false;
						//if(tempAttrib.values[0]
						if( string.IsNullOrEmpty(tempAttrib.values[idx]) != true){
							isTrue = tempAttrib.values[idx] == "false"?false:true;
						}
						return DataEditorWindow.CreateCheckButton(isTrue,value=>{
							tempAttrib.values[idx] = value == false ? "false" : "true";
						},reqSize);
					}
				case SchemeDataAttrib.Type.ENUM:{
						var enumNames = attrib.CustomClass.enumNames.ToArray();
						//string[] namesOfEnum = DataEditorWindow.Inst.schemeData.scheme
						int currentSelected = -1;
						for(int i = 0 ; i < enumNames.Length ; i++){
							if(tempAttrib.values[idx] == enumNames[i]){
								currentSelected = i;
								break;
							}
						}
						if(currentSelected == -1){
							currentSelected = 0;
							tempAttrib.values[idx] = enumNames[0];
						}

						return DataEditorWindow.CreateComboBox(currentSelected,enumNames,selected=>{
							tempAttrib.values[idx] = enumNames[selected];
						},reqSize);
					}
			}
			return null;
		}
	}
}

