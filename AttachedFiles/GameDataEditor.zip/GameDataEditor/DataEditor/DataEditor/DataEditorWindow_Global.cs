﻿
using System;
using System.Collections.Generic;
using Gtk;
using Gdk;

namespace DataEditor
{
	public partial class DataEditorWindow:Gtk.Window
	{
		public static void ShowDialog(Gtk.Window wind, string text)
		{
			MessageDialog newDialog = new MessageDialog(wind, DialogFlags.DestroyWithParent,
			                                            MessageType.Info,
			                                            ButtonsType.Ok,
			                                            text);
			newDialog.Run();
			newDialog.Destroy();
		}
		public void ShowDialog(string text)
		{
			ShowDialog(this, text);
		}
		public void ShowOkDialog(string text, System.Action onOK)
		{
			MessageDialog newDialog = new MessageDialog(this, DialogFlags.DestroyWithParent,
			                                            MessageType.Question,
			                                            ButtonsType.OkCancel,
			                                            text);
			if (newDialog.Run() == (int)ResponseType.Ok)
			{
				onOK();
			}
			newDialog.Destroy();
		}

		public class WidgetCacher{

		}
		public static Dictionary<System.Type,List<CLTuple<bool,Widget>>> widgetDic;
		public static T GetWidget<T>()where T:Widget,new(){
			List<CLTuple<bool,Widget>> list = null;
			if(widgetDic.ContainsKey(typeof(T)) == false){
				list = new List<CLTuple<bool, Widget>>();
				widgetDic.Add(typeof(T),list);
			}else{
				list = widgetDic[typeof(T)];
			}

			CLTuple<bool,Widget> newWidget = null;
			for(int i = 0 ; i < list.Count ; i++){
				if(list[i].First == false){
					newWidget = list[i];
					break;
				}
			}
			if(newWidget == null){
				newWidget = new CLTuple<bool, Widget>(true,new T());
				list.Add(newWidget);
			}
			return (T)newWidget.Second;
		}
		//public static void DisposeWidget(Widget widget){
		//	if(widgetDic.ContainsKey(widget.GetType()) == false){
		//		throw new Exception("DisposeWidget there is no item="+widget.GetType().Name);
		//	}
		//	var listOfItem = widgetDic[widget.GetType()];
		//	for(int i = 0 ; i < listOfItem.Count ; i++){
		//		if(listOfItem[i].Second == widget){
		//			if(listOfItem[i].First == false){
		//				throw new Exception("DisposeWidget Already disposed="+widget.GetType().Name);
		//			}
		//			listOfItem[i].First = false;
		//			if(listOfItem[i].Second.GetType() == typeof(HBox)){
		//				HBox temp = (HBox)listOfItem[i].Second;
		//				foreach(var temp
		//			}
		//			return;
		//		}
		//	}
		//}
		public static Label CreateLabel(string name,float xAlign = 0.5f, float yAlign = 0.5f, int reqSize = -1)
		{
			Label temp = new Label(name);
			temp.SetAlignment(xAlign, yAlign);
			temp.SetSizeRequest(reqSize,22);
			return temp;
		}
		public static Label CreateLine(float xAlign = 0.0f, float yAlign = 0.5f)
		{
			Label temp = new Label("-------------------------------------------------------");
			temp.SetAlignment(xAlign, yAlign);
			return temp;
		}
		public static Button CreateButton(string name, System.Action onOK,int reqSize = -1)
		{
			Button btn = new Button(name);
			btn.Clicked += (object sender, EventArgs e) =>
			{
				onOK();
			};
			btn.SetSizeRequest(reqSize,22);
			return btn;
		}
		public static CheckButton CreateCheckButton(bool value,System.Action<bool> onActive, int reqSize = -1)
		{
			CheckButton temp = new CheckButton();
			temp.Active = value;
			temp.Toggled += (sender, e) =>
			{
				onActive(temp.Active);
			};
			temp.SetSizeRequest(reqSize,22);
			return temp;
		}
		public static CheckButton CreateCheckButtonWithLabel(string labelName, bool value, System.Action<bool> onActive, int reqLabelSize = -1)
		{
			CheckButton temp = new CheckButton(labelName);
			temp.Active = value;
			temp.Toggled += (sender, e) =>
			{
				onActive(temp.Active);
			};

			temp.SetSizeRequest(reqLabelSize,22);
			return temp;
		}
		public static HBox CreateEntryWithLabel(string labelName,string defaultName, System.Action<Entry> onFinished, System.Action<Entry> onEditing = null, int reqLabelSize = -1, int reqEntrySize = -1)
		{
			HBox hBox = new HBox(false, 0);
			hBox.PackStart(CreateLabel(labelName,0.0f,0.5f,reqLabelSize), false, true, 0);
			Entry entry = new Entry(defaultName);
			entry.Activated += (sender, e) =>
			{
				onFinished(entry);
			};
			if (onEditing != null)
			{
				entry.Changed += (sender, e) =>
				{
					onEditing(entry);
				};
			}
			hBox.PackEnd(entry, true, true, 0);

			entry.SetSizeRequest(reqEntrySize,22);
			return hBox;
		}
		public static Entry CreateEntry(string defaultName, System.Action<Entry> onFinished, System.Action<Entry> onEditing = null,int reqWidthSize = -1)
		{
			Entry entry = new Entry(defaultName);
			entry.Activated += (sender, e) =>
			{
				onFinished(entry);
			};
			if (onEditing != null)
			{
				entry.Changed += (sender, e) =>
				{
					onEditing(entry);
				};
			}
			if(reqWidthSize != -1){
				entry.SetSizeRequest(reqWidthSize,22);
			}
			return entry;
		}

		public static ComboBox CreateComboBox(int defaultSelected, string[] typeArr, System.Action<int> selected, int reqSize = -1)
		{
			ComboBox comboBox = new ComboBox(typeArr);
			comboBox.Changed += (sender, e) =>
			{
				ComboBox combo = sender as ComboBox;
				if (e == null)
					return;
				TreeIter iter;
				if (combo.GetActiveIter(out iter))
				{
					string value = (string)combo.Model.GetValue(iter, 0);
					//Console.WriteLine("Value!=" + value);
					int idx = -1;
					for (int i = 0; i < typeArr.Length; i++)
					{
						if (typeArr[i] == value)
						{
							idx = i;
						}
					}
					selected(idx);
				}
			};
			comboBox.SetSizeRequest(reqSize,22);
			comboBox.Active = defaultSelected;
			return comboBox;
		}
		public static HBox CreateComboBoxWithLabel(string label,int defaultSelected,string[] typeArr,System.Action<int> selected, int reqLabelSize = -1, int reqComboSize = -1)
		{
			HBox hBox = new HBox(false, 0);
			hBox.PackStart(CreateLabel(label,0.0f,0.5f,reqLabelSize), false, true, 0);
			ComboBox comboBox = new ComboBox(typeArr);
			comboBox.Changed += (sender, e) =>
			{
				ComboBox combo = sender as ComboBox;
				if (e == null)
					return;
				TreeIter iter;
				if (combo.GetActiveIter(out iter))
				{
					string value = (string)combo.Model.GetValue(iter, 0);
					//Console.WriteLine("Value!=" + value);
					int idx = -1;
					for (int i = 0; i < typeArr.Length; i++)
					{
						if (typeArr[i] == value)
						{
							idx = i;
						}
					}
					selected(idx);
				}
			};
			comboBox.Active = defaultSelected;
			comboBox.SetSizeRequest(reqComboSize,22);
			hBox.PackStart(comboBox, false, true, 0);

			return hBox;
		}
		public static void MakeIndent(HBox target, int depth){
			for(int i = 0 ; i < depth ; i++){
				Label lab = new Label("\t");
				target.PackStart(lab,false,true,0);
			}
		}
		public static bool CheckValidKeyName(string key,out string reason){
			reason = "";
			if(string.IsNullOrEmpty(key) == true){
				reason = "Length zero!";
				return false;
			}
			int someVal = 0;
			if(int.TryParse( key.Substring(0,1) , out someVal ) == true){
				reason = "No number start!";
				return false;
			}
			return true;
		}
	}
}

