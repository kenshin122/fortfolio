﻿using System;
using Gtk;
using System.Collections.Generic;
using Gdk;

namespace DataEditor
{
	public class SchemeWindow:VBox
	{
		VBox topVBox;
		VBox listVBox;
		string pathToFile = "";
		bool[] isUnfold = new bool[1024];
		int[] typeArr = new int[1024];
		int[] customTypeArr = new int[1024];
		int[] enumTypeArr = new int[1024];
		int[] flagEnumTypeArr = new int[1024];
		string currStr = "";
		Gtk.Window window;
		public SchemeWindow(Gtk.Window _window)
		{
			window = _window;
			topVBox = new VBox(false,0);
			ScrolledWindow scroll = new ScrolledWindow();
			listVBox = new VBox();

			//new DatePickerDialog(window
			//listVBox.PackStart(DataEditorWindow.CreateButton("DatePick",()=>{
			//	DatePickerDialog.ShowDialog(window,value=>{
			//		Console.WriteLine("Date="+value.ToString());
			//	});
			//}),false,true,0);

			scroll.AddWithViewport(listVBox);
			this.PackStart(topVBox,false,true,0);
			this.PackStart(scroll);

			//
			HBox hBox = new HBox();
			topVBox.PackStart(hBox);
			hBox.PackStart( DataEditorWindow.CreateButton("Load",()=>{
				FileChooserDialog chooser = new FileChooserDialog("Choose .xml file", window,
				                                                  FileChooserAction.Open,
				                                                  "Cancel", ResponseType.Cancel,
				                                                  "Open", ResponseType.Accept);
				if (chooser.Run() == (int)ResponseType.Accept){
					Console.WriteLine(chooser.Filename);
					if (System.IO.Path.GetExtension(chooser.Filename) == ".xml")
					{
						pathToFile = chooser.Filename;
						string stringData = System.IO.File.ReadAllText( pathToFile );
						DataEditorWindow.Inst.schemeData = SchemeDataManager.LoadFromString(stringData);
						OnRefresh();
					}
				}
				chooser.Destroy();
			}),false,true,0);
			hBox.PackStart( DataEditorWindow.CreateButton("Save",()=>{
				if( pathToFile.Length <= 0){
					FileChooserDialog chooser = new FileChooserDialog("Save .xml file", window,
					                                                  FileChooserAction.Save,
					                                                  "Cancel", ResponseType.Cancel,
					                                                  "Open", ResponseType.Accept);
					if (chooser.Run() == (int)ResponseType.Accept)
					{
						Console.WriteLine(chooser.Filename);
						if (System.IO.Path.GetExtension(chooser.Filename) == ".xml")
						{
							pathToFile = chooser.Filename;
							string data = DataEditorWindow.Inst.schemeData.SaveAsXml();
							System.IO.File.WriteAllText(pathToFile, data);
						}
					}
					chooser.Destroy();
				}else{
					string data = DataEditorWindow.Inst.schemeData.SaveAsXml();
					System.IO.File.WriteAllText(pathToFile, data);
				}
			}),false,true,0);
			hBox.PackStart( DataEditorWindow.CreateButton("Save as",()=>{
				FileChooserDialog chooser = new FileChooserDialog("Save .xml file", window,
				                                                  FileChooserAction.Save,
				                                                  "Cancel", ResponseType.Cancel,
				                                                  "Open", ResponseType.Accept);
				if (chooser.Run() == (int)ResponseType.Accept)
				{
					Console.WriteLine(chooser.Filename);
					if (System.IO.Path.GetExtension(chooser.Filename) == ".xml")
					{
						pathToFile = chooser.Filename;
						string data = DataEditorWindow.Inst.schemeData.SaveAsXml();
						System.IO.File.WriteAllText(pathToFile, data);
					}
				}
				chooser.Destroy();
			}),false,true,0);
			hBox.PackStart( DataEditorWindow.CreateButton("ExportClass",()=>{
				FileChooserDialog chooser = new FileChooserDialog("Choose dest directory",window,
				                                                  FileChooserAction.SelectFolder,
				                                                  "Cancel",ResponseType.Cancel,
				                                                  "Open",ResponseType.Accept);
				//string toPath = "";
				if(chooser.Run() == (int)ResponseType.Accept){
					//pathEntry.Text = chooser.Filename;
					//Console.WriteLine(chooser.Filename);
					SchemeCodeGen.GenerateCodeFromScheme(chooser.Filename,DataEditorWindow.Inst.schemeData);
				}
				chooser.Destroy();

			}),false,true,0);

			topVBox.PackStart(DataEditorWindow.CreateLine(),false,true,0);
			topVBox.PackStart( DataEditorWindow.CreateLabel("Create a new scheme",0),false,true,0);
			HBox schemeHBox = new HBox();

			schemeHBox.PackStart( DataEditorWindow.CreateEntryWithLabel("SchemeName","",entry=>{

			},entry=>{
				currStr = entry.Text;
			}),false,true,0);
			schemeHBox.PackStart( DataEditorWindow.CreateButton("CreateScheme",()=>{
				DataEditorWindow.Inst.schemeData.CreateScheme(SchemeDataClass.Type.Normal,currStr);
				OnRefresh();
			}),false,true,0);
			schemeHBox.PackStart( DataEditorWindow.CreateButton("CreateEnum",()=>{
				var created = DataEditorWindow.Inst.schemeData.CreateScheme(SchemeDataClass.Type.Enum,currStr);
				created.enumNames.Add("Invalid");
				OnRefresh();
			}),false,true,0);
			schemeHBox.PackStart( DataEditorWindow.CreateButton("CreateFlagEnum",()=>{
				var created = DataEditorWindow.Inst.schemeData.CreateScheme(SchemeDataClass.Type.Flag_Enum,currStr);
				//created.enumNames.Add("Invalid");
				OnRefresh();
			}),false,true,0);
			topVBox.PackStart(schemeHBox);
			topVBox.PackStart(DataEditorWindow.CreateLine(),false,true,0);
			topVBox.PackStart( DataEditorWindow.CreateLabel("SchemeList",0),false,true,0);
			topVBox.PackStart(DataEditorWindow.CreateLine(),false,true,0);
			this.ShowAll();

		}
		List<Entry> entries = new List<Entry>();

		void OnRefresh(){
			foreach (var item in listVBox.AllChildren)
			{
				listVBox.Remove((Widget)item);
			}

			//var data = DataEditorWindow.Inst.schemeData;
			var list = DataEditorWindow.Inst.schemeData.SchemeList;
			for(int i = 0 ; i < list.Count ; i++){
				PrintScheme(i, list[i], 0 );
			}

			this.ShowAll();
		}
		void PrintScheme(int idx,SchemeDataClass scheme,int depth){



			HBox topHBox = new HBox();
			DataEditorWindow.MakeIndent(topHBox,depth);

			topHBox.PackStart(DataEditorWindow.CreateCheckButton( isUnfold[idx], isActive=>{
				isUnfold[idx] = isActive;
				OnRefresh();
			}),false,true,0);
			Label nameLab = new Label(scheme.name);
			nameLab.SetSizeRequest(100,-1);
			nameLab.SetAlignment(0,0.5f);
			topHBox.PackStart(nameLab,false,true,0);

			topHBox.PackStart(DataEditorWindow.CreateButton("X",()=>{
				DataEditorWindow.Inst.schemeData.RemoveScheme(scheme.id);
				OnRefresh();
			}),false,true,0);

			var changeNameEntry = DataEditorWindow.CreateEntryWithLabel("Change","TypeIn",tempEntry=>{
				//Check name exists..
				string newName = tempEntry.Text;
				foreach(var pair in DataEditorWindow.Inst.schemeData.schemeDic){
					if(pair.Value == scheme)
						continue;
					if(pair.Value.name == newName){
						DataEditorWindow.ShowDialog(window,"Same name exists!");
						tempEntry.Text = "TypeIn";
						return;
					}
				}
				//Change it..
				scheme.name = newName;
				tempEntry.Text = "TypeIn";
				OnRefresh();
			},null,-1,100);
			topHBox.PackStart(changeNameEntry,false,true,0);

			listVBox.PackStart(topHBox,false,true,0);

			if(isUnfold[idx] == false)
				return;

			if(scheme.type == SchemeDataClass.Type.Enum ||
			   scheme.type == SchemeDataClass.Type.Flag_Enum){
				for(int i = 0 ; i < scheme.enumNames.Count; i++){
					PrintEnumAttribute(scheme,i ,depth+1);
				}
			}else{
				for(int i = 0 ; i < scheme.attrib.Count; i++){
					PrintAttribute(scheme,scheme.attrib[i],depth+1);
				}
			}


			HBox tempHBox = null;
			if(scheme.type == SchemeDataClass.Type.Enum ||
			   scheme.type == SchemeDataClass.Type.Flag_Enum){
				string temp = "";
				tempHBox = new HBox();
				DataEditorWindow.MakeIndent(tempHBox,depth+1);

				tempHBox.PackStart(DataEditorWindow.CreateEntryWithLabel("FieldName:","",entry=>{
					if(entry.Text.Length <= 0)
						return;
					if(scheme.enumNames.Contains(entry.Text))
						return;
					
					scheme.enumNames.Add( entry.Text );
					OnRefresh();
				},entry=>{
					temp = entry.Text;
				},-1,200),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateButton("Add",()=>{
					if(temp.Length <= 0)
						return;
					if(scheme.enumNames.Contains(temp))
						return;

					scheme.enumNames.Add( temp );
					OnRefresh();
				}),false,true,0);
				listVBox.PackStart(tempHBox,false,true,0);
				return;
			}

			//listVBox.PackStart(DataEditorWindow.CreateLabel(""),false,true,0);
			//DrawToolsForAttribute
			//HBox tempHBox = new HBox();
			//DataEditorWindow.MakeIndent(tempHBox,depth+1);
			//tempHBox.PackStart(DataEditorWindow.CreateLabel("Add a new field",0),false,true,0);
			//listVBox.PackStart(tempHBox,false,true,0);
			//BasicType
			{
				string temp = "";
				bool isArray = false;

				tempHBox = new HBox();
				DataEditorWindow.MakeIndent(tempHBox,depth+1);
				var comboBox = DataEditorWindow.CreateComboBoxWithLabel("BasicFieldType:",typeArr[idx],SchemeDataAttrib.TypeNames,selected=>{
					typeArr[idx] = selected;
				},130,200);
				tempHBox.PackStart(comboBox,false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateEntryWithLabel("FieldName:","",entry=>{
					scheme.CreateAttrib( (SchemeDataAttrib.Type)typeArr[idx], entry.Text, isArray);
					OnRefresh();
				},entry=>{
					temp = entry.Text;
				},-1,200),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateCheckButtonWithLabel("IsArray",isArray,isActive=>{
					isArray = isActive;
				}),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateButton("Add",()=>{
					scheme.CreateAttrib( (SchemeDataAttrib.Type)typeArr[idx], temp, isArray);
					OnRefresh();
				}),false,true,0);
				listVBox.PackStart(tempHBox,false,true,0);
			}
			//CustomType
			{
				string temp = "";
				bool isArray = false;
				bool isStruct = false;
				tempHBox = new HBox();
				DataEditorWindow.MakeIndent(tempHBox,depth+1);
				var comboBox = DataEditorWindow.CreateComboBoxWithLabel("CustomFieldType:",customTypeArr[idx],DataEditorWindow.Inst.schemeData.SchemeNames,selected=>{
					customTypeArr[idx] = selected;
				},130,200);
				tempHBox.PackStart(comboBox,false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateEntryWithLabel("FieldName:","",entry=>{
					int customTypeID = DataEditorWindow.Inst.schemeData.GetSchemeIDByIdx(customTypeArr[idx]);
					scheme.CreateAttribCustom( customTypeID, entry.Text, isArray, isStruct);
					OnRefresh();
				},entry=>{
					temp = entry.Text;
				},-1,200),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateCheckButtonWithLabel("IsArray",isArray,isActive=>{
					isArray = isActive;
				}),false,true,0);
				tempHBox.PackStart(DataEditorWindow.CreateCheckButtonWithLabel("IsStruct",isArray,isActive=>{
					isStruct = isActive;
				}),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateButton("Add",()=>{
					int customTypeID = DataEditorWindow.Inst.schemeData.GetSchemeIDByIdx(customTypeArr[idx]);
					scheme.CreateAttribCustom( customTypeID, temp, isArray, isStruct);
					OnRefresh();
				}),false,true,0);
				listVBox.PackStart(tempHBox,false,true,0);
			}
			//EnumType
			{
				string temp = "";
				bool isArray = false;
				tempHBox = new HBox();
				DataEditorWindow.MakeIndent(tempHBox,depth+1);
				var comboBox = DataEditorWindow.CreateComboBoxWithLabel("EnumFieldType:",enumTypeArr[idx],DataEditorWindow.Inst.schemeData.SchemeEnumNames,selected=>{
					enumTypeArr[idx] = selected;
				},130,200);
				tempHBox.PackStart(comboBox,false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateEntryWithLabel("FieldName:","",entry=>{
					scheme.CreateEnumAttrib( DataEditorWindow.Inst.schemeData.GetEnumIDByIdx( enumTypeArr[idx] ), entry.Text, isArray );
					OnRefresh();
				},entry=>{
					temp = entry.Text;
				},-1,200),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateCheckButtonWithLabel("IsArray",isArray,isActive=>{
					isArray = isActive;
				}),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateButton("Add",()=>{
					scheme.CreateEnumAttrib( DataEditorWindow.Inst.schemeData.GetEnumIDByIdx( enumTypeArr[idx] ), temp, isArray );
					OnRefresh();
				}),false,true,0);
				listVBox.PackStart(tempHBox,false,true,0);
			}
			//FlagEnumType
			{
				string temp = "";
				bool isArray = false;
				tempHBox = new HBox();
				DataEditorWindow.MakeIndent(tempHBox,depth+1);
				var comboBox = DataEditorWindow.CreateComboBoxWithLabel("FlagEnumFieldType:",flagEnumTypeArr[idx],DataEditorWindow.Inst.schemeData.SchemeFlagEnumNames,selected=>{
					flagEnumTypeArr[idx] = selected;
				},130,200);
				tempHBox.PackStart(comboBox,false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateEntryWithLabel("FieldName:","",entry=>{
					scheme.CreateFlagEnumAttrib( DataEditorWindow.Inst.schemeData.GetFlagEnumIDByIdx( flagEnumTypeArr[idx] ), entry.Text, isArray );
					OnRefresh();
				},entry=>{
					temp = entry.Text;
				},-1,200),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateCheckButtonWithLabel("IsArray",isArray,isActive=>{
					isArray = isActive;
				}),false,true,0);

				tempHBox.PackStart(DataEditorWindow.CreateButton("Add",()=>{
					scheme.CreateFlagEnumAttrib( DataEditorWindow.Inst.schemeData.GetFlagEnumIDByIdx( flagEnumTypeArr[idx] ), temp, isArray );
					OnRefresh();
				}),false,true,0);
				listVBox.PackStart(tempHBox,false,true,0);
			}
		}
		void PrintAttribute(SchemeDataClass origClass, SchemeDataAttrib attrib,int depth){
			HBox hBox = new HBox();
			DataEditorWindow.MakeIndent(hBox,depth);

			////////////////////
			Label typeLab = new Label();
			if(attrib.type == SchemeDataAttrib.Type.ENUM){
				typeLab.Text += "e_";
			}
			if(attrib.type == SchemeDataAttrib.Type.FLAG_ENUM){
				typeLab.Text += "f_";
			}
			if(attrib.type == SchemeDataAttrib.Type.CUSTOM ||
			   attrib.type == SchemeDataAttrib.Type.ENUM){
				typeLab.Text += DataEditorWindow.Inst.schemeData.schemeDic[ attrib.customTypeID ].name ;
			}else{
				typeLab.Text += attrib.type.ToString();
			}

			if(attrib.isArray == true){
				typeLab.Text += "[]";
			}
			if(attrib.isStruct == true){
				typeLab.Text += "[S]";
			}
			typeLab.SetSizeRequest(100,0);
			typeLab.SetAlignment(0,0.5f);
			hBox.PackStart(typeLab,false,true,0);

			/////////////////////
			Label nameLab = new Label();
			nameLab.Text = attrib.name;

			nameLab.SetSizeRequest(100,0);
			nameLab.SetAlignment(0,0.5f);
			hBox.PackStart(nameLab,false,true,0);

			/////////////////////
			hBox.PackStart(DataEditorWindow.CreateButton("X",()=>{
				origClass.RemoveAttrib(attrib);
				OnRefresh();
			}),false,true,0);

			var changeNameEntry = DataEditorWindow.CreateEntryWithLabel("Change","TypeIn",tempEntry=>{
				//Check there is same attrib name..
				string newName = tempEntry.Text;
				for(int i = 0 ; i < origClass.attrib.Count ; i++){
					if(origClass.attrib[i] == attrib)
						continue;
					//CheckSameName..
					if(origClass.attrib[i].name == newName){
						DataEditorWindow.ShowDialog(window,"Same name exists!");
						tempEntry.Text = "TypeIn";
						return;
					}
				}
				//change all attrib in data!
				foreach(var pair in DataEditorWindow.Inst.contentData.contentDic){
					if(pair.Value.schemeTypeID != origClass.id)
						continue;
					var contentAttrib = pair.Value.attribDic[attrib.name];
					pair.Value.attribDic.Remove(attrib.name);
					pair.Value.attribDic.Add(newName,contentAttrib);
				}
				attrib.name = newName;
				tempEntry.Text = "TypeIn";
				OnRefresh();
			},null,-1,100);
			hBox.PackStart(changeNameEntry,false,true,0);

			//
			listVBox.PackStart(hBox,false,true,0);
		}
		void PrintEnumAttribute(SchemeDataClass origClass,int idx, int depth){
			HBox hBox = new HBox();
			DataEditorWindow.MakeIndent(hBox,depth);

			/////////////////////
			hBox.PackStart(DataEditorWindow.CreateButton("X",()=>{
				origClass.enumNames.RemoveAt(idx);
				OnRefresh();
			}),false,true,0);

			////////////////////
			Label typeLab = new Label();
			typeLab.Text = origClass.enumNames[idx];
			typeLab.SetSizeRequest(100,0);
			typeLab.SetAlignment(0,0.5f);
			hBox.PackStart(typeLab,false,true,0);

			//Modifier..
			if(DataEditorWindow.Inst.contentData.contentDic.Count > 0){
				var myEntry = DataEditorWindow.CreateEntryWithLabel("Change","newName",entry=>{
					//Check if this is same enum name!
					for(int i = 0 ; i < origClass.enumNames.Count ; i++){
						if(i == idx)
							continue;
						if(origClass.enumNames[i] == entry.Text){
							DataEditorWindow.ShowDialog(window,"Same name exists!");
							entry.Text = "";
							return;
						}
					}
					string newName = entry.Text;
					//First.. look for the data that using this enum..
					//Need to change everything..
					foreach(var pair in DataEditorWindow.Inst.contentData.contentDic){
						foreach(var otherPair in pair.Value.attribDic){
							if( otherPair.Value.type == SchemeDataAttrib.Type.ENUM &&
							   origClass.type == SchemeDataClass.Type.Enum){
								//Console.WriteLine("Called?");
								if(otherPair.Value.schemeID == origClass.id){
									//If there is match.. then replace it..
									//Console.WriteLine("NotMatch??");
									int cnt = 1;
									if(otherPair.Value.isArray == true){
										cnt = otherPair.Value.arrSize;
									}
									for(int i = 0 ; i < cnt ;i++){
										if( otherPair.Value.values[i] == origClass.enumNames[idx] ){
											//Console.WriteLine(string.Format("Changing content={0} attrib={1} from={2} to={3}",
											//                                pair.Value.name,
											//                                otherPair.Key,
											//                                otherPair.Value.values[i],
											//                                newName));
											otherPair.Value.values[i] = newName;

										}
									}
								}
							}else if(otherPair.Value.type == SchemeDataAttrib.Type.FLAG_ENUM &&
							         origClass.type == SchemeDataClass.Type.Flag_Enum){
								if(otherPair.Value.schemeID == origClass.id){
									//If there is match.. then replace it..
									int cnt = 1;
									if(otherPair.Value.isArray == true){
										cnt = otherPair.Value.arrSize;
									}
									for(int i = 0 ; i < cnt ;i++){
										var flagNames = otherPair.Value.GetFlagNameList(i);
										for(int j = 0 ; j < flagNames.Count ;j++){
											if( flagNames[j] == origClass.enumNames[idx] ){
												flagNames[j] = newName;
											}
										}
										otherPair.Value.SetFlagNameList(i,flagNames);
									}
								}
							}
						}
					}

					//Change!
					origClass.enumNames[idx] = newName;
					OnRefresh();
				},null,-1,100);
				hBox.PackStart(myEntry,false,true,0);
			}
			//
			listVBox.PackStart(hBox,false,true,0);
		}
	}
}

