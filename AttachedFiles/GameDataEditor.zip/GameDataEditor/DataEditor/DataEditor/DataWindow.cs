﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Gtk;
using Gdk;

namespace DataEditor
{
	public class DataWindow:VBox
	{
		string pathToFile = "";
		int selectedSchemaIdx;

		Gtk.Window window;
		bool isExcelLike = false;

		NormalDataEditorWindow normalContentVBox;
		ExcelDataEditorWindow excelContentVBox;

		public DataWindow(Gtk.Window _window)
		{
			window = _window;
			this.ShowAll();
		}
		public void OnAllRefresh(){
			foreach (var item in this.AllChildren)
			{
				this.Remove((Widget)item);
			}

			if(DataEditorWindow.Inst.schemeData.schemeDic.Count <= 0){
				this.PackStart(DataEditorWindow.CreateLabel("You need scheme first",0),false,true,0);
				this.ShowAll();
				return;
			}

			DataEditorWindow.Inst.contentData.CheckForChange();

			HBox hBox = new HBox();
			this.PackStart(hBox,false,true,0);
			hBox.PackStart( DataEditorWindow.CreateButton("Load",()=>{
				FileChooserDialog chooser = new FileChooserDialog("Choose .xml file", window,
				                                                  FileChooserAction.Open,
				                                                  "Cancel", ResponseType.Cancel,
				                                                  "Open", ResponseType.Accept);
				if (chooser.Run() == (int)ResponseType.Accept){
					Console.WriteLine(chooser.Filename);
					if (System.IO.Path.GetExtension(chooser.Filename) == ".xml")
					{
						pathToFile = chooser.Filename;
						string stringData = System.IO.File.ReadAllText( pathToFile );
						DataEditorWindow.Inst.contentData = ContentDataManager.LoadFromString(stringData);
						OnAllRefresh();
					}
				}
				chooser.Destroy();
			}),false,true,0);
			hBox.PackStart( DataEditorWindow.CreateButton("Save",()=>{
				if( pathToFile.Length <= 0){
					FileChooserDialog chooser = new FileChooserDialog("Save .xml file", window,
					                                                  FileChooserAction.Save,
					                                                  "Cancel", ResponseType.Cancel,
					                                                  "Open", ResponseType.Accept);
					if (chooser.Run() == (int)ResponseType.Accept)
					{
						Console.WriteLine(chooser.Filename);
						if (System.IO.Path.GetExtension(chooser.Filename) == ".xml")
						{
							pathToFile = chooser.Filename;
							string data = DataEditorWindow.Inst.contentData.SaveAsXml();
							System.IO.File.WriteAllText(pathToFile, data);
						}
					}
					chooser.Destroy();
				}else{
					string data = DataEditorWindow.Inst.contentData.SaveAsXml();
					System.IO.File.WriteAllText(pathToFile, data);
				}
			}),false,true,0);
			hBox.PackStart( DataEditorWindow.CreateButton("Save as",()=>{
				FileChooserDialog chooser = new FileChooserDialog("Save .xml file", window,
				                                                  FileChooserAction.Save,
				                                                  "Cancel", ResponseType.Cancel,
				                                                  "Open", ResponseType.Accept);
				if (chooser.Run() == (int)ResponseType.Accept)
				{
					Console.WriteLine(chooser.Filename);
					if (System.IO.Path.GetExtension(chooser.Filename) == ".xml")
					{
						pathToFile = chooser.Filename;
						string data = DataEditorWindow.Inst.contentData.SaveAsXml();
						System.IO.File.WriteAllText(pathToFile, data);
					}
				}
				chooser.Destroy();
			}),false,true,0);
			hBox.PackStart( DataEditorWindow.CreateButton("ExportClass",()=>{
				FileChooserDialog chooser = new FileChooserDialog("Choose dest directory",window,
				                                                  FileChooserAction.SelectFolder,
				                                                  "Cancel",ResponseType.Cancel,
				                                                  "Open",ResponseType.Accept);
				//string toPath = "";
				if(chooser.Run() == (int)ResponseType.Accept){
					ContentCodeGen.GenerateCodeFromContent(chooser.Filename,DataEditorWindow.Inst.contentData);
				}
				chooser.Destroy();

			}),false,true,0);
			hBox.PackStart( DataEditorWindow.CreateButton("Test",()=>{
				Gtk.Clipboard clipboard = Gtk.Clipboard.Get(Gdk.Atom.Intern("CLIPBOARD",false));
				string text = clipboard.WaitForText();
				Console.WriteLine(text);
			}),false,true,0);
			hBox.PackStart( DataEditorWindow.CreateCheckButtonWithLabel("IsExcel",isExcelLike,value=>{
				isExcelLike = value;
				OnAllRefresh();
				//if(isExcelLike == false){
				//	Console.WriteLine("CheckCalled! normal");
				//	normalContentVBox = new NormalDataEditorWindow(window);
				//	normalContentVBox.OnAllRefresh();
				//}else{
				//	Console.WriteLine("CheckCalled! excel");
				//	excelContentVBox = new ExcelDataEditorWindow(window);
				//	excelContentVBox.OnAllRefresh();
				//}
			}),false,true,0);




			if(isExcelLike == false){
				//Console.WriteLine("InitCalled! normal");
				normalContentVBox = new NormalDataEditorWindow(window);
				normalContentVBox.OnAllRefresh();
				this.PackStart(normalContentVBox,true,true,0);
			}else{
				//Console.WriteLine("InitCalled! excel");
				excelContentVBox = new ExcelDataEditorWindow(window);
				excelContentVBox.OnAllRefresh();
				this.PackStart(excelContentVBox,true,true,0);
			}

			this.ShowAll();
		}
	}
}

