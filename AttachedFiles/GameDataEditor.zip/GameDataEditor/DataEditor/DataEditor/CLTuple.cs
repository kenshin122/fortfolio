﻿using System;
namespace DataEditor
{
	public class CLTuple<T1,T2>{
		public T1 First{get;set;}
		public T2 Second{get;set;}
		public CLTuple(){}
		public CLTuple(T1 one, T2 two){
			First = one;
			Second = two;
		}
	}
	public class CLTuple<T1,T2,T3>{
		public T1 First{get;set;}
		public T2 Second{get;set;}
		public T3 Third{get;set;}
		public CLTuple(){}
		public CLTuple(T1 one, T2 two, T3 three){
			First = one;
			Second = two;
			Third = three;
		}
	}
}

