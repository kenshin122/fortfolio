﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Gtk;
using Gdk;

namespace DataEditor
{
	public class NormalDataEditorWindow:VBox
	{
		const int STACK_MAX = 7;
		Gtk.Window window;

		VBox topVBox;
		VBox listVBox;
		string currStr = "";
		string searchFilterName = "";
		string[] searchFilterNames;
		string attribSearchFilterName = "";
		int selectedSchemeIdx;

		HashSet<string> foldInfo = new HashSet<string>();
		int[] contentTreeStack = new int[STACK_MAX];
		int contentTreeIdx = 0;
		public void PushTree(int idx){
			idx++;
			contentTreeStack[contentTreeIdx] = idx;
			contentTreeIdx++;
		}
		public void PopTree(){
			contentTreeStack[contentTreeIdx] = 0;
			contentTreeIdx--;
			//contentTreeStack[contentTre
		}
		public int[] CurrentPos{
			get{
				int[] temp = new int[STACK_MAX];
				for(int i = 0 ; i < STACK_MAX ; i++){
					temp[i] = contentTreeStack[i];
				}
				return temp;
			}
		}
		public bool GetFold(int[] pos){
			if(foldInfo.Contains(string.Format("{0}_{1}_{2}_{3}_{4}_{5}_{6}",pos[0],pos[1],pos[2],pos[3],pos[4],pos[5],pos[6])) == false)
				return false;
			return true;
		}
		public void SetFold(int[] pos, bool value){
			string key = string.Format("{0}_{1}_{2}_{3}_{4}_{5}_{6}",pos[0],pos[1],pos[2],pos[3],pos[4],pos[5],pos[6]);
			if(value == false)
				foldInfo.Remove(key);
			else
				foldInfo.Add(key);
		}

		public NormalDataEditorWindow(Gtk.Window _window)
		{
			window = _window;
			//this.ShowAll();
		}
		public void OnAllRefresh(){
			foreach (var item in this.AllChildren)
			{
				this.Remove((Widget)item);
			}

			if(DataEditorWindow.Inst.schemeData.schemeDic.Count <= 0){
				this.PackStart(DataEditorWindow.CreateLabel("You need scheme first",0),false,true,0);
				this.ShowAll();
				return;
			}

			DataEditorWindow.Inst.contentData.CheckForChange();

			topVBox = new VBox(false,0);
			ScrolledWindow scroll = new ScrolledWindow();
			listVBox = new VBox();
			scroll.AddWithViewport(listVBox);
			this.PackStart(topVBox,false,true,0);
			this.PackStart(scroll,true,true,0);

			//SearchRelated
			topVBox.PackStart(DataEditorWindow.CreateLine(),false,true,0);
			topVBox.PackStart( DataEditorWindow.CreateLabel("Create a new Item",0),false,true,0);
			HBox searchBox = new HBox();
			searchBox.PackStart(DataEditorWindow.CreateEntryWithLabel("Search:",searchFilterName,entry=>{},entry=>{
				searchFilterName = entry.Text;
				if(string.IsNullOrEmpty(searchFilterName) == true)
				{
					searchFilterNames = null;
				}else{
					List<string> tempStrList = new List<string>();
					searchFilterNames = searchFilterName.Split(',');
					for(int i = 0 ; i < searchFilterNames.Length ; i++){
						if(string.IsNullOrEmpty(searchFilterNames[i]) == true)
							continue;
						tempStrList.Add(searchFilterNames[i]);
					}
					searchFilterNames = tempStrList.ToArray();
				}
				OnRefresh();
			},-1,150),false,true,0);
			searchBox.PackStart(DataEditorWindow.CreateEntryWithLabel("AttribSearch:",attribSearchFilterName,entry=>{},entry=>{
				attribSearchFilterName = entry.Text;
				OnRefresh();
			},-1,150),false,true,0);
			topVBox.PackStart(searchBox,false,true,0);

			topVBox.PackStart(DataEditorWindow.CreateLine(),false,true,0);
			topVBox.PackStart( DataEditorWindow.CreateLabel("Create a new Item",0),false,true,0);


			HBox schemeHBox = new HBox();
			System.Action createItemAction = ()=>{
				string reason;
				if( DataEditorWindow.CheckValidKeyName(currStr,out reason) == false){
					DataEditorWindow.ShowDialog(window,reason);
					return;
				}

				int schemeID = DataEditorWindow.Inst.schemeData.GetSchemeIDByIdx(selectedSchemeIdx);

				int contentID = DataEditorWindow.Inst.contentData.CreateContent(schemeID, currStr);
				if(contentID == -1){
					DataEditorWindow.ShowDialog(window,"Same key exists!");
					return;
				}
				OnRefresh();
			};
			schemeHBox.PackStart( DataEditorWindow.CreateComboBoxWithLabel("Scheme:",selectedSchemeIdx,DataEditorWindow.Inst.schemeData.SchemeNames,selected=>{
				selectedSchemeIdx = selected;
			}),false,true,0);
			schemeHBox.PackStart( DataEditorWindow.CreateEntryWithLabel("ItemName","",entry=>{
				currStr = entry.Text;
				createItemAction();
			},entry=>{
				currStr = entry.Text;
			}),false,true,0);
			schemeHBox.PackStart( DataEditorWindow.CreateButton("Create",()=>{
				createItemAction();
			}),false,true,0);
			topVBox.PackStart(schemeHBox,false,true,0);







			topVBox.PackStart(DataEditorWindow.CreateLine(),false,true,0);
			topVBox.PackStart( DataEditorWindow.CreateLabel("Item List",0),false,true,0);
			topVBox.PackStart(DataEditorWindow.CreateLine(),false,true,0);






			OnRefresh();



			//this.ShowAll();
		}
		bool elapseAll = true;
		Dictionary<ContentData,Tuple<int,VBox>> vBoxDic;
		public void OnRefresh(ContentData targetContent = null){
			if(targetContent != null){
				VBox tempVBox = vBoxDic[targetContent].Item2;
				foreach (var item in tempVBox.AllChildren)
				{
					tempVBox.Remove((Widget)item);
				}
				PushTree(vBoxDic[targetContent].Item1);
				PrintContent(targetContent, tempVBox,targetContent, 0 );
				PopTree();
				tempVBox.ShowAll();
				return;
			}

			foreach (var item in listVBox.AllChildren)
			{
				listVBox.Remove((Widget)item);
			}
			HBox elapsedHBox = new HBox();
			elapsedHBox.PackStart( DataEditorWindow.CreateCheckButton(elapseAll,value=>{
				elapseAll = value;
				if(elapseAll == true){
					foldInfo.Clear();
				}else{
					int[] foldInfo = CurrentPos;
					for(int i = 0 ; i < DataEditorWindow.Inst.contentData.ContentList.Count ;i++){
						foldInfo[0] = i;
						SetFold(foldInfo,true);
					}
				}
				OnRefresh();
			}),false,true,0);
			elapsedHBox.PackStart(DataEditorWindow.CreateLabel("Collapse",0),false,true,0);
			listVBox.PackStart(elapsedHBox,false,true,0);


			var list = DataEditorWindow.Inst.contentData.ContentListWithoutStruct;
			vBoxDic = new Dictionary<ContentData, Tuple<int, VBox>>();
			for(int i = 0 ; i < list.Count ; i++){
				bool needToBeShown = true;
				if(searchFilterNames != null){
					for(int j = 0 ; j < searchFilterNames.Length ; j++){
						bool hasIt = false;
						if( list[i].name.Contains(searchFilterNames[j]) == true ||
						   list[i].Scheme.name.Contains(searchFilterNames[j]) == true){
							hasIt = true;
						}

						if(hasIt == false){
							needToBeShown = false;
						}
					}
				}

				if(needToBeShown == true){
					VBox tempVBox = new VBox();
					vBoxDic.Add(list[i],new Tuple<int,VBox>(i,tempVBox));
					listVBox.PackStart(tempVBox,false,true,0);
					PushTree(i);
					PrintContent(list[i],tempVBox,list[i], 0 );
					PopTree();
				}
			}
			this.ShowAll();
		}





		void PrintContent(ContentData rootContent, VBox vBox,ContentData content,int depth,bool removeTop = false){
			int[] currPos = CurrentPos;

			if(content.Scheme.HasOnlyPrimitiveAttribute() == true && depth > 0){
				PrintAttributeInRow(rootContent,vBox,content,depth+1);
				return;
			}

			HBox totalHBox = new HBox();
			vBox.PackStart(totalHBox,false,true,0);
			HBox indentBox = new HBox();
			VBox myVBox = new VBox();
			DataEditorWindow.MakeIndent(indentBox,depth);
			totalHBox.PackStart(indentBox,false,true,0);
			totalHBox.PackStart(myVBox,false,true,0);



			if(removeTop == false){
				HBox topHBox = new HBox();
				DataEditorWindow.MakeIndent(topHBox,depth);

				topHBox.PackStart(DataEditorWindow.CreateCheckButton( GetFold(currPos), isActive=>{
					SetFold( currPos, isActive );
					OnRefresh(rootContent);
					//Console.WriteLine("Refresh! idx="+curContentIdx);
				}),false,true,0);
				Label nameLab = new Label(content.Scheme.name+"::"+content.name);
				nameLab.SetSizeRequest(200,-1);
				nameLab.SetAlignment(0,0.5f);
				topHBox.PackStart(nameLab,false,true,0);
				if(depth <= 0){
					topHBox.PackStart(DataEditorWindow.CreateButton("X",()=>{
						DataEditorWindow.Inst.contentData.DeleteContent(content.id);
						OnRefresh();
					}),false,true,0);
				}
				myVBox.PackStart(topHBox,false,true,0);


				if(GetFold(currPos) == false)
					return;
			}



			for(int i = 0 ; i < content.Scheme.attrib.Count ; i++){
				bool isSkip = false;
				if(depth == 0){
					if(string.IsNullOrEmpty(attribSearchFilterName) == false){
						if(content.Scheme.attrib[i].name.Contains(attribSearchFilterName) == false)
							isSkip = true;
					}
				}
				if(isSkip == true)
					continue;

				PushTree(i);
				if(depth > 2){
					depth = 2;
				}
				PrintAttribute(rootContent, myVBox,content,content.Scheme.attrib[i], depth+1);
				PopTree();
			}
		}
		void PrintAttributeInRow(ContentData rootContent, VBox vBox,ContentData content,int depth){
			PrintAttributeInRow(rootContent,vBox,new ContentData[1]{content},depth);
		}
		void PrintAttributeInRow(ContentData rootContent, VBox vBox,ContentData[] contentArr,int depth){
			HBox totalHBox = new HBox();
			vBox.PackStart(totalHBox,false,true,0);
			HBox indentBox = new HBox();
			VBox myVBox = new VBox();
			DataEditorWindow.MakeIndent(indentBox,depth);
			totalHBox.PackStart(indentBox,false,true,0);
			totalHBox.PackStart(myVBox,false,true,0);

			//HBox labelBox 
			int globalWidth = 100;
			ContentData realContent = contentArr[0];
			//This is for top label.
			{
				HBox topLabelHBox = new HBox();
				myVBox.PackStart(topLabelHBox,false,true,0);
				for(int i = 0 ; i < realContent.Scheme.attrib.Count ; i++){
					SchemeDataAttrib tempAttrib = realContent.Scheme.attrib[i];
					//HBox singleHBox = new HBox();
					Label tempLabel = new Label(tempAttrib.name+"::"+GetAttribTypeLabel(tempAttrib).Text);
					tempLabel.SetAlignment(0,0.5f);
					tempLabel.SetSizeRequest(globalWidth,-1);
					topLabelHBox.PackStart(tempLabel,false,true,0);
				}
			}
			//This is for dataList
			for(int i = 0 ; i < contentArr.Length ; i++){
				ContentData selectedContent = contentArr[i];
				HBox tempMyHBox = new HBox();
				myVBox.PackStart(tempMyHBox,false,true,0);
				for(int j = 0 ; j < realContent.Scheme.attrib.Count ; j++){
					SchemeDataAttrib realAttrib = realContent.Scheme.attrib[j];
					var tempAttrib = selectedContent.GetAttrib(realAttrib);
					tempMyHBox.PackStart(GetInputThingFromAttrib(rootContent,realAttrib,selectedContent.GetAttrib(realAttrib),0,globalWidth),false,true,0);
				}
			}
		}
		void PrintAttribute(ContentData rootContent, VBox vBox, ContentData content, SchemeDataAttrib attrib ,int depth){
			int[] currPos = CurrentPos;

			VBox myVBox = GetIndentedVBox(vBox,depth);

			HBox hBox = new HBox();
			////////////////////
			if( attrib.isArray == true ||
			   attrib.isStruct == true ){
				hBox.PackStart(DataEditorWindow.CreateCheckButton( GetFold(currPos), isActive=>{
					SetFold( currPos, isActive );
					OnRefresh(rootContent);
				}),false,true,0);
			}

			////////////////////
			Label typeLab = GetAttribTypeLabel(attrib);
			hBox.PackStart(typeLab,false,true,0);

			/////////////////////
			Label nameLab = GetAttribNameLabel(attrib);
			hBox.PackStart(nameLab,false,true,0);

			var tempAttrib = content.GetAttrib(attrib);
			/////////////////////
			// need to place value!
			if( attrib.isArray == true ){
				hBox.PackStart( DataEditorWindow.CreateEntryWithLabel("Size:", content.GetAttribSize(attrib.name).ToString(),entry=>{
					int size = 0;
					if( int.TryParse(entry.Text,out size) == false)
						return;
					if(size < 0)
						return;
					content.SetAttribSize(attrib, size);
					//OnRefresh();
					OnRefresh(rootContent);
				},entry=>{

				},-1,100),false,true,0);
			}else{
				if(attrib.isStruct != true){
					PrintOrdinaryAttrib(hBox,rootContent,attrib,tempAttrib,0);
				}
			}


			myVBox.PackStart(hBox,false,true,0);

			if(GetFold(currPos) == false)
				return;

			if(attrib.isArray == true){
				if(attrib.isStruct == true){
					var contentArr = tempAttrib.RefContents;
					if(contentArr.Length > 0){
						if(contentArr[0].Scheme.HasOnlyPrimitiveAttribute() == true){
							PrintAttributeInRow(rootContent,vBox,contentArr,depth+1);
						}else{
							for(int i = 0 ; i < contentArr.Length ; i++){
								PushTree(i);
								PrintContent(rootContent, myVBox,contentArr[i],depth);
								PopTree();
							}
						}
					}
				}else{
					VBox otherVBox = GetIndentedVBox(myVBox,depth+1);
					for(int i = 0 ; i < tempAttrib.arrSize ; i++){
						HBox newHBox = new HBox();
						newHBox.PackStart( GetAttribTypeLabel(attrib),false,true,0);
						newHBox.PackStart( GetAttribNameLabel(attrib),false,true,0);
						PrintOrdinaryAttrib(newHBox,rootContent,attrib,tempAttrib,i);
						otherVBox.PackStart(newHBox,false,true,0);
					}
				}
			}else{
				if(attrib.isStruct == true){
					PushTree(0);
					PrintContent(rootContent, myVBox,tempAttrib.RefContent,depth+1,true);
					PopTree();
				}
			}
		}
		public static Widget GetInputThingFromAttrib(ContentData rootContent, SchemeDataAttrib attrib, ContentDataAttrib tempAttrib, int idx, int reqSize = -1){
			switch(attrib.type){
				case SchemeDataAttrib.Type.DATETIME:
				case SchemeDataAttrib.Type.TIMESPAN:
				case SchemeDataAttrib.Type.FLOAT:
				case SchemeDataAttrib.Type.INT:
				case SchemeDataAttrib.Type.STRING:{
						return DataEditorWindow.CreateEntry(tempAttrib.values[idx],entry=>{
							tempAttrib.values[idx] = entry.Text;
						},entry=>{
							tempAttrib.values[idx] = entry.Text;
						},reqSize);
					}
				case SchemeDataAttrib.Type.CUSTOM:{
						ContentData[] contentMatchArr = DataEditorWindow.Inst.contentData.GetContentMatchesScheme(attrib.customTypeID);
						List<string> namesOfContents = (from item in contentMatchArr
						                                select item.name).ToList();
						namesOfContents.Insert(0,"Null");
						List<int> idOfContents = (from item in contentMatchArr
						                          select item.id).ToList();
						idOfContents.Insert(0,0);
						
						int currentSelected = 0;
						int idOfContent = System.Convert.ToInt32(tempAttrib.values[idx]);
						for(int i = 0 ; i < idOfContents.Count ; i++){
							if(idOfContent == idOfContents[i]){
								currentSelected = i;
								break;
							}
						}
						return DataEditorWindow.CreateComboBox(currentSelected,namesOfContents.ToArray(),selected=>{
							tempAttrib.values[idx] = idOfContents[selected].ToString();
						},reqSize);
					}
				case SchemeDataAttrib.Type.BOOL:{

						int currentSelected = 0;
						//if(tempAttrib.values[0]
						if( string.IsNullOrEmpty(tempAttrib.values[idx]) != true){
							currentSelected = tempAttrib.values[idx] == "false"?0:1;
						}
						return DataEditorWindow.CreateComboBoxWithLabel("Value:",currentSelected,new string[]{"false","true"},selected=>{
							tempAttrib.values[idx] = selected == 0 ? "false" : "true";
						},reqSize);
					}
				case SchemeDataAttrib.Type.ENUM:{
						var enumNames = attrib.CustomClass.enumNames.ToArray();
						//string[] namesOfEnum = DataEditorWindow.Inst.schemeData.scheme
						int currentSelected = -1;
						for(int i = 0 ; i < enumNames.Length ; i++){
							if(tempAttrib.values[idx] == enumNames[i]){
								currentSelected = i;
								break;
							}
						}
						if(currentSelected == -1){
							currentSelected = 0;
							tempAttrib.values[idx] = enumNames[0];
						}

						return DataEditorWindow.CreateComboBox(currentSelected,enumNames,selected=>{
							tempAttrib.values[idx] = enumNames[selected];
						},reqSize);
					}
			}
			return null;
		}
		void PrintOrdinaryAttrib(HBox hBox, ContentData rootContent, SchemeDataAttrib attrib, ContentDataAttrib tempAttrib, int idx){
			switch(attrib.type){
				case SchemeDataAttrib.Type.DATETIME:
				case SchemeDataAttrib.Type.TIMESPAN:
				case SchemeDataAttrib.Type.FLOAT:
				case SchemeDataAttrib.Type.INT:
				case SchemeDataAttrib.Type.STRING:{
						hBox.PackStart( DataEditorWindow.CreateEntryWithLabel("Value:", tempAttrib.values[idx],entry=>{
							tempAttrib.values[idx] = entry.Text;
						},entry=>{
							tempAttrib.values[idx] = entry.Text;
						},-1,100),false,true,0);
					}
				break;
				case SchemeDataAttrib.Type.CUSTOM:{
						ContentData[] contentMatchArr = DataEditorWindow.Inst.contentData.GetContentMatchesScheme(attrib.customTypeID);
						string[] namesOfContents = (from item in contentMatchArr
						                            select item.name).ToArray();
						int[] idOfContents = (from item in contentMatchArr
						                      select item.id).ToArray();
						int currentSelected = 0;
						int idOfContent = System.Convert.ToInt32(tempAttrib.values[idx]);
						for(int i = 0 ; i < idOfContents.Length ; i++){
							if(idOfContent == idOfContents[i]){
								currentSelected = i;
								break;
							}
						}

						hBox.PackStart( DataEditorWindow.CreateComboBoxWithLabel("Value:",currentSelected,namesOfContents,selected=>{
							tempAttrib.values[idx] = idOfContents[selected].ToString();
						}),false,true,0);
						hBox.PackStart( DataEditorWindow.CreateButton("LinkSameKey",()=>{
							for(int i = 0 ; i < contentMatchArr.Length ; i++){
								if(contentMatchArr[i].name == rootContent.name){
									tempAttrib.values[idx] = idOfContents[i].ToString();
									OnRefresh(rootContent);
									return;
								}
							}
						}),false,true,0);
					}
				break;
				case SchemeDataAttrib.Type.BOOL:{

						int currentSelected = 0;
						//if(tempAttrib.values[0]
						if( string.IsNullOrEmpty(tempAttrib.values[idx]) != true){
							currentSelected = tempAttrib.values[idx] == "false"?0:1;
						}
						hBox.PackStart( DataEditorWindow.CreateComboBoxWithLabel("Value:",currentSelected,new string[]{"false","true"},selected=>{
							tempAttrib.values[idx] = selected == 0 ? "false" : "true";
						}),false,true,0);
					}
				break;
				case SchemeDataAttrib.Type.ENUM:{
						var enumNames = attrib.CustomClass.enumNames.ToArray();
						//string[] namesOfEnum = DataEditorWindow.Inst.schemeData.scheme
						int currentSelected = -1;
						for(int i = 0 ; i < enumNames.Length ; i++){
							if(tempAttrib.values[idx] == enumNames[i]){
								currentSelected = i;
								break;
							}
						}
						if(currentSelected == -1){
							currentSelected = 0;
							tempAttrib.values[idx] = enumNames[0];
						}

						hBox.PackStart( DataEditorWindow.CreateComboBoxWithLabel("Value:",currentSelected,enumNames,selected=>{
							tempAttrib.values[idx] = enumNames[selected];
						}),false,true,0);
					}
				break;
				case SchemeDataAttrib.Type.FLAG_ENUM:{
						var enumNames = attrib.CustomClass.enumNames.ToArray();
						List<string> matchings = new List<string>();
						List<string> currentNames = tempAttrib.GetFlagNameList(idx);
						for(int i = 0 ; i < enumNames.Length ; i++){
							for(int j = 0 ; j < currentNames.Count ; j++){
								if(currentNames[j] == enumNames[i]){
									matchings.Add( enumNames[i] );
								}
							}
						}
						hBox.PackStart(DataEditorWindow.CreateLabel("Value:"),false,true,0);
						//List those exists..
						for(int i = 0 ; i < matchings.Count ; i++){
							Console.WriteLine("matching="+matchings[i]+" I="+i);
							int tempIdx = i;
							hBox.PackStart(DataEditorWindow.CreateButton(matchings[i],()=>{
								//Remove This...
								Console.WriteLine("Delete!= tempIdx="+tempIdx+" idx="+idx);
								tempAttrib.RemoveFlag(idx, tempIdx);
								Console.WriteLine("DeleteSuccess!");
								OnRefresh(rootContent);
							}),false,true,0);
						}
						int selectedThing = 0;
						hBox.PackStart( DataEditorWindow.CreateComboBox(0,enumNames,selected=>{
							//tempAttrib.values[idx] = enumNames[selected];
							selectedThing = selected;
						}),false,true,0);
						hBox.PackStart(DataEditorWindow.CreateButton("Add",()=>{
							//tempAttrib.arrSize;
							tempAttrib.AddFlag(idx,enumNames[selectedThing]);
							Console.WriteLine("Added!");
							OnRefresh(rootContent);
						}),false,true,0);
					}
				break;
			}
		}
		VBox GetIndentedVBox(VBox vBox,int depth){
			HBox totalHBox = new HBox();
			vBox.PackStart(totalHBox,false,true,0);
			HBox indentBox = new HBox();
			VBox myVBox = new VBox();
			DataEditorWindow.MakeIndent(indentBox,depth);
			totalHBox.PackStart(indentBox,false,true,0);
			totalHBox.PackStart(myVBox,false,true,0);
			return myVBox;
		}
		Label GetAttribTypeLabel(SchemeDataAttrib attrib){
			Label typeLab = new Label();
			if(attrib.type == SchemeDataAttrib.Type.ENUM ||
			   attrib.type == SchemeDataAttrib.Type.FLAG_ENUM){
				typeLab.Text += "e_";
			}
			if(attrib.type == SchemeDataAttrib.Type.CUSTOM ||
			   attrib.type == SchemeDataAttrib.Type.ENUM ||
			   attrib.type == SchemeDataAttrib.Type.FLAG_ENUM){
				typeLab.Text += DataEditorWindow.Inst.schemeData.schemeDic[ attrib.customTypeID ].name ;
			}else{
				typeLab.Text += attrib.type.ToString();
			}

			if(attrib.isArray == true){
				typeLab.Text += "[]";
			}
			if(attrib.isStruct == true){
				typeLab.Text += "[S]";
			}
			typeLab.SetSizeRequest(150,0);
			typeLab.SetAlignment(0,0.5f);
			return typeLab;
		}
		Label GetAttribNameLabel(SchemeDataAttrib attrib){
			/////////////////////
			Label nameLab = new Label();
			nameLab.Text = attrib.name;

			nameLab.SetSizeRequest(200,0);
			nameLab.SetAlignment(0,0.5f);
			return nameLab;
		}
	}
}

