﻿using System;
using Gtk;
using Gdk;

namespace DataEditor
{
	public partial class DataEditorWindow:Gtk.Window
	{
		public static DataEditorWindow Inst;

		Notebook note;
		SchemeWindow schemeWindow;
		DataWindow dataWindow;
		RuntimeSchemeWindow runtimeSchemeWindow;

		public SchemeDataManager schemeData = new SchemeDataManager();
		public ContentDataManager contentData = new ContentDataManager();
		public DataEditorWindow():base("Data Editor Ver1.0")
		{
			Inst = this;
			SetDefaultSize(800, 600);
			SetPosition(WindowPosition.Center);
			DeleteEvent += delegate
			{
				Application.Quit();
			};

			schemeWindow = new SchemeWindow(this);
			dataWindow = new DataWindow(this);

			note = new Notebook();
			note.AppendPage(schemeWindow,new Label("Scheme"));
			note.AppendPage(dataWindow,new Label("Data"));
			note.SwitchPage += (o, args) => {
				//Console.WriteLine("Switch Page!="+args.PageNum);
				if(args.PageNum == 1){
					dataWindow.OnAllRefresh();
				}
			};



			this.Add(note);
			ShowAll();
		}
	}
}

