﻿using System;
using Gdk;
using Gtk;

namespace DataEditor
{
	public class DatePickerDialog
	{
		public static void ShowDialog(Gtk.Window window, System.Action<DateTime> onResult){
			Dialog dialog = new Dialog ("DatePicker",
			                            window,
			                            DialogFlags.DestroyWithParent,
			                            Gtk.Stock.Save, ResponseType.Accept,
			                            Gtk.Stock.Close,ResponseType.Close);
			Calendar cal = new Calendar();
			dialog.VBox.PackStart(cal);
			dialog.ShowAll();

			if ((ResponseType)dialog.Run () == ResponseType.Accept) {
				onResult(cal.Date);
			}
			dialog.Destroy ();
		}
	}
}

