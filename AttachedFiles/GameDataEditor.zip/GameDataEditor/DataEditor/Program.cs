﻿using System;
using Gtk;
using System.Collections.Generic;

namespace DataEditor
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			Application.Init();
			DataEditorWindow win = new DataEditorWindow();
			win.Show();
			Application.Run();
		}
	}
}
