using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.Caching.Distributed;
using System.Threading.Tasks;

namespace gameServer{
public static class PPJsonExtension
{
    public static async Task SetObjectAsJson(this IDistributedCache cache, string key, object value, DistributedCacheEntryOptions option = null)
    {
        string jsonString = await JsonConvert.SerializeObjectAsync(value);
        if( option != null){
            await cache.SetStringAsync(key,jsonString,option);
        }else{
            await cache.SetStringAsync(key,jsonString);
        }
        // cache.SetStringAsync(key,)
        
    }
    public static async Task<T> GetObjectFromJson<T>(this IDistributedCache cache, string key)
    {
        string jsonString = await cache.GetStringAsync(key);
        return jsonString == null ? default(T) : await JsonConvert.DeserializeObjectAsync<T>(jsonString);
    }
    public static async Task SetIntAsync(this IDistributedCache cache, string key, int value, DistributedCacheEntryOptions option = null){
        if(option != null){
            await cache.SetStringAsync(key, value.ToString(),option);
        }else{
            await cache.SetStringAsync(key, value.ToString());
        }
        
    }
    public static async Task<int?> GetIntAsync(this IDistributedCache cache, string key){
        string jsonString = await cache.GetStringAsync(key);
        return jsonString == null ? null : (int?)System.Convert.ToInt32(jsonString);
    }

    public static void SetObjectAsJson(this ISession session, string key, object value)
    {
        session.SetString(key, JsonConvert.SerializeObject(value));
    }

    public static T GetObjectFromJson<T>(this ISession session, string key)
    {
        var value = session.GetString(key);

        return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
    }

    public static void CheckParameterExists(this JObject source, params string[] args){
        if(source == null){
            throw new FIException(FIErr.WrongJson);
        }
        List<string> missingParamList = new List<string>();
        for(int i = 0 ; i < args.Length ; i++){
            if(source[args[i]] == null)
                missingParamList.Add(args[i]);
        }
        if(missingParamList.Count <= 0){
            return;
        }
        System.Text.StringBuilder builder = new System.Text.StringBuilder();
        for(int i = 0 ; i < missingParamList.Count ; i++){
            builder.Append(missingParamList[i]);
            if(i < missingParamList.Count - 1){
                builder.Append(",");
            }
        }
        throw new FIException(FIErr.ParameterMissing,builder.ToString());
    }
}
}
