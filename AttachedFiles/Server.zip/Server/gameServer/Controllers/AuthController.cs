using System;
using System.Collections.Generic;
using Microsoft.Extensions.Options;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
namespace gameServer{
    public class AuthSettings{
        public int sessionExpireTimeHours{get;set;}
        public string fbRedirect{get;set;}
        public string fbID{get;set;}
        public string fbSecret{get;set;}
        public string fbScope{get;set;}
    }
}

namespace gameServer.Controllers
{
    // [Route("enc/[controller]")]
    public class AuthController : BaseController
    {
        
        IOptions<AuthSettings> setting;
        public AuthController(IServiceProvider serviceProvider,IOptions<AuthSettings> _setting):base(serviceProvider){
            setting = _setting;            
        }
        [HttpGet("enc/auth/setcookie")]
        public string CookieSet(string value){
            HttpContext.Response.Cookies.Append("sess",value);
            return value;
        }
        [HttpGet("enc/sessSecure/auth/getcookie")]
        public string DoSomething(){
            var sess = HttpContext.Request.Cookies["sess"];
            return "value="+sess;
        }

        [HttpPost("enc/auth/loginDID")]
        public async Task<JObject> LoginDID([FromBody]JObject body){
            // HttpContext.Items
            body.CheckParameterExists("deviceID");
            //Check device id exists..
            var user = await (from item in DBContext.Auth
            where item.grantType == GrantType.DeviceID && item.grantValue == body["deviceID"].Value<string>()
            select item).FirstOrDefaultAsync();
            if(user == null){
                user = new DBAuthData();
                user.grantType = GrantType.DeviceID;
                user.grantValue = body["deviceID"].Value<string>();
                await DBContext.Auth.AddAsync(user);
                await DBContext.SaveChangesAsync();
            }
            var newGuid = Guid.NewGuid().ToString();
            await Redis.SetIntAsync($"sess{newGuid}",user.uid,new DistributedCacheEntryOptions(){
                AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(setting.Value.sessionExpireTimeHours)
            });
            HttpContext.Response.Cookies.Append("sess",newGuid);
            // return Result("Login success");
            
            // JObject res = new JObject();
            // res.Add(new JProperty("err",FIErr.Okay));
            // var updateJson = new JProperty("update");
            // var arr = new JArray();
            var obj = new{
                err=FIErr.Okay,
                updated=new{
                    DBAuthData=new object[]{
                        new{
                            uid=13,
                            grantType=GrantType.Facebook,
                            grantValue=user.grantValue
                        }
                    }
                }
            };
            return JObject.FromObject(obj);
        }






        [HttpGet("Facebook")]
        public void FacebookLogin(){
            // HttpContext.Response.Redirect();
        }
















        // GET api/values
        [HttpGet]
        public async Task<object> Get()
        {
            // Redis.SetAsync("count")
            int? counter = await Redis.GetIntAsync("counter");
            if(counter == null)
                counter = 0;
            counter++;
            await Redis.SetIntAsync("counter",counter.Value);
            return Result(new{value=counter.Value});
        }

    }
}
