using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json.Linq;

namespace gameServer.Controllers
{
    public class BaseController : Controller
    {
        protected IDistributedCache Redis;
        protected DBFIContext DBContext;
        public BaseController(IServiceProvider serviceProvider){
            Redis = (IDistributedCache)serviceProvider.GetService(typeof(IDistributedCache));
            DBContext = (DBFIContext)serviceProvider.GetService(typeof(DBFIContext));
        }
        protected JObject GetResultJson(){
            return new JObject(new JProperty("err",FIErr.Okay));
        }

        public IEnumerable<string> Nothing()
        {
            return new string[] { "value1", "value2" };
        }
        protected object Result(object obj){
            return new{err=FIErr.Okay,res=obj};
        }
    }
}
