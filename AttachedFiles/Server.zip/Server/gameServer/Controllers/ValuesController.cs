using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.EntityFrameworkCore;

namespace gameServer.Controllers
{
    [Route("enc/sess/[controller]")]
    public class ValuesController : BaseController
    {
        public ValuesController(IServiceProvider serviceProvider):base(serviceProvider){
            
        }

        [HttpPost("GetUserInfo")]
        public async Task<object> GetUserInfo(){
            var usrInfo = await(from item in DBContext.Auth
            where item.uid == (int)HttpContext.Items["userID"]
            select item).FirstOrDefaultAsync();
            return Result(usrInfo);
        }

        // GET api/values
        [HttpPost]
        public async Task<object> Get()
        {
            // Redis.SetAsync("count")
            int? counter = await Redis.GetIntAsync("counter");
            if(counter == null)
                counter = 0;
            counter++;
            await Redis.SetIntAsync("counter",counter.Value);
            return Result(new{value=counter.Value});
        }
    }
}
