using System;
using System.Collections.Generic;
using Microsoft.Extensions.Options;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json.Linq;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Google.Apis.AndroidPublisher.v2;
using Google.Apis.AndroidPublisher.v2.Data;
using Google.Apis.Services;
using Google.Apis.Auth.OAuth2;
using System.Security.Cryptography.X509Certificates;

namespace gameServer{
    public class GoogleIAPSettings{
        public string packageName{get;set;}
        public string password{get;set;}
        public string serviceAccountEmail{get;set;}
        public string pKeyFileName{get;set;}
    }
}
namespace gameServer.Controllers
{
    // [Route("enc/[controller]")]
    public class GoogleIAPController : BaseController
    {
        enum EGoogleConsumptionState{
			NotConsumed = 0,
			Consumed = 1,
		}
		enum EGooglePurchaseState{
			Purchased = 0,
			Canceled = 1,
		}
        IOptions<GoogleIAPSettings> setting;
        AndroidPublisherService androidService;
        public GoogleIAPController(IServiceProvider serviceProvider,IOptions<GoogleIAPSettings> _setting):base(serviceProvider){
            setting = _setting;
            Console.WriteLine("Checking="+setting.Value.pKeyFileName);
            Console.WriteLine("Checking="+setting.Value.serviceAccountEmail);
            byte[] p12RawData = System.IO.File.ReadAllBytes(setting.Value.pKeyFileName);
            var certificate = new X509Certificate2(p12RawData,"notasecret",X509KeyStorageFlags.Exportable);
            ServiceAccountCredential credential = new ServiceAccountCredential(
				new ServiceAccountCredential.Initializer(setting.Value.serviceAccountEmail)
				{
					Scopes = new[] { "https://www.googleapis.com/auth/androidpublisher" }
				}.FromCertificate(certificate)
			);

			androidService = new AndroidPublisherService (new BaseClientService.Initializer () {
				HttpClientInitializer = credential
			});
        }
        [HttpPost("enc/sess/googleiap/getorderid")]
        public async Task<JObject> GetOrderID([FromBody]JObject body){
            body.CheckParameterExists("itemKey","marketType");
            var itemKey = body["itemKey"].Value<string>();
            var marketType = body["marketType"].Value<EIAPMarket>();
            var order = new DBIAPOrder();
            order.orderID = Guid.NewGuid().ToString();
            order.itemKey = itemKey;
            order.marketType = marketType;
            order.transactionState = EIAPTransaction.OnRegist;
            await DBContext.IAPOrder.AddAsync(order);
            await DBContext.SaveChangesAsync();
            return new JObject(new JProperty("orderID",order.orderID));
        }
        [HttpPost("enc/sess/googleiap/verifytoken")]
        public async Task<JObject> VerifyToken([FromBody]JObject body){
            body.CheckParameterExists("orderID","purchaseToken");
            var orderID = body["orderID"].Value<string>();
            var purchaseToken = body["purchaseToken"].Value<string>();

            var orderEntity = await(from item in DBContext.IAPOrder
            where item.orderID == orderID
            select item).FirstOrDefaultAsync();

            if(orderEntity == null){
                throw new FIException(FIErr.IAP_CannotFindOrderID);
            }

            if(orderEntity.transactionState != EIAPTransaction.OnRegist)
                throw new FIException(FIErr.IAP_WrongTransaction);
            
            var productRecipt = await GetReciptFromGoogle(orderEntity.itemKey,purchaseToken);

            FIErr err = FIErr.Okay;
            if(productRecipt.DeveloperPayload != orderID){
                err = FIErr.IAP_NotMachingPayload;
            }else if(productRecipt.ConsumptionState == (int)EGoogleConsumptionState.Consumed){
                err = FIErr.IAP_AlreadyConsumed;
            }else if(productRecipt.PurchaseState == (int)EGooglePurchaseState.Canceled){
                err = FIErr.IAP_AlreadyCanceled;
            }

            if(err != FIErr.Okay){
                orderEntity.transactionState = EIAPTransaction.OnFailed;
                await DBContext.SaveChangesAsync();
                throw new FIException(err);    
            }

            orderEntity.transactionState = EIAPTransaction.OnVerified;
            await DBContext.SaveChangesAsync();

            return GetResultJson();
        }

        public async Task<ProductPurchase> GetReciptFromGoogle(string itemKey,string purchaseToken){
            var req = androidService.Purchases.Products.Get(
                setting.Value.packageName,
                itemKey,
                purchaseToken);
            return  await req.ExecuteAsync();
        }
    }
}
