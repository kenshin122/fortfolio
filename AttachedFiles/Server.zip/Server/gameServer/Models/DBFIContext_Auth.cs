using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace gameServer{

    public enum GrantType{
        DeviceID,
        Facebook,
        Google,
    }
    public class DBAuthData{
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int uid{get;set;}
        public GrantType grantType{get;set;}
        public string grantValue{get;set;}
    }
}