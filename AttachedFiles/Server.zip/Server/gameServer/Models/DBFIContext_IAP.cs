using System.ComponentModel.DataAnnotations;

namespace gameServer{
    public enum EIAPMarket{
		Google,
		Apple,
	}
	public enum EIAPTransaction{
		OnRegist = 0,
		OnFailed = 1,
		OnVerified = 4,
		OnUsed = 5,
	}
    public class DBIAPOrder{
        [Key]
        public string orderID{get;set;}
        public EIAPMarket marketType{get;set;}
        public EIAPTransaction transactionState{get;set;}
        public string itemKey{get;set;}

    }
}