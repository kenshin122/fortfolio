using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
namespace gameServer{
    public class DBSettings{
        public string fullUrl{get;set;}
        public string url{get;set;}
        public string user{get;set;}
        public string pwd{get;set;}
        public string TotalUrl{
            get{
                return string.Format(fullUrl,url,user,pwd);
            }
        }
    }
    public class DBFIContext:DbContext{
        IOptions<DBSettings> settings;
        public DBFIContext(DbContextOptions options,IOptions<DBSettings> _settings):base(options){
            settings = _settings;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            System.Console.WriteLine(settings.Value.TotalUrl);
            builder.UseSqlServer(settings.Value.TotalUrl);
        }
        public DbSet<DBAuthData> Auth{get;set;}
        public DbSet<DBIAPOrder> IAPOrder{get;set;}
    }
}