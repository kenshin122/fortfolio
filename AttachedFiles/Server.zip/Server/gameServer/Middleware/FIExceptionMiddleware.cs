using System;
using Microsoft.AspNetCore.Http;
using System.Globalization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
namespace gameServer{
    public class FIExceptionMiddleware{
        private readonly RequestDelegate _next;
        public FIExceptionMiddleware(RequestDelegate _delegate){
            _next = _delegate;
        }
        public async Task Invoke(HttpContext context){
            // Console.WriteLine("redisID="+config["redisID"]);
            try{
                await _next(context);
            }catch(FIException e){
                //ExpectedException!
                // string res = await JsonConvert.SerializeObjectAsync(new{err=e.err.ToString(),msg=e.Message});
                string res = await JsonConvert.SerializeObjectAsync(new{err=e.err,msg=e.Message});
                await context.Response.WriteAsync(res);
            }catch(Exception e){
                //This is internal error!
                string res = await JsonConvert.SerializeObjectAsync(new{err=FIErr.InternalErr,msg=""});
                await context.Response.WriteAsync(res);
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
            }
        }
    }
    public static class FIExceptionMiddlewareExtension{
        public static IApplicationBuilder UseFIException(this IApplicationBuilder builder){
            return builder.UseMiddleware<FIExceptionMiddleware>();
        }
    }
    public class FIException: Exception
    {
        public FIErr err;
        public Exception inner;
        public FIException(FIErr _err,string _message = ""):base(_message){
            err=_err;
        }
    }
    public enum FIErr{
	    InternetNotConnected = -1,
	    //Syste Error
	    Okay = 0,

	    UnexpectedClientBehavior,
	    InternalErr,
	    ClientTimeout,
	    ServerTimeout,
	    OnlyPostSupported,
	    WrongJson,
	    ParameterMissing,
	    CannotDecrypt,
	    UnsupportContentType,



    	NotLoggedIn = 100,
    	NotUserLoggedIn,
    	ExpiredSession,


	//IAPErr
    	IAP_CannotFindOrderID = 200,
    	IAP_WrongTransaction,
    	IAP_NotMachingPayload,
    	IAP_AlreadyConsumed,
    	IAP_AlreadyCanceled
    }
}