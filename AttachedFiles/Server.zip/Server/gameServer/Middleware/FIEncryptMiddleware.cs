using System;
using Microsoft.AspNetCore.Http;
using System.Globalization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using System.IO;
using Newtonsoft.Json;

namespace gameServer{
    public class FIEncryptMiddleware{
        private readonly RequestDelegate _next;
        public FIEncryptMiddleware(RequestDelegate _delegate){
            _next = _delegate;
        }
        public async Task Invoke(HttpContext context){
            Console.WriteLine("EncryptionCheck");
            // if( context.Request.ContentType != "application/json" ){
            //     throw new FIException(FIErr.UnsupportContentType);
            // }
            // if( context.Request.Method != "POST"){
            //     throw new FIException(FIErr.OnlyPostSupported);
            // }
            // string readedString = await new StreamReader(context.Request.Body).ReadToEndAsync();
            // if(string.IsNullOrEmpty(readedString) == true){
            //     throw new FIException(FIErr.InternalErr,"No Content");
            // }
            // string newStr = await JsonConvert.SerializeObjectAsync(new{Hello="kokonut",Orig=readedString});
            // context.Request.Body = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(newStr));
            await _next(context);
        }
    }
    public static class FIEncryptMiddlewareExtension{
        public static IApplicationBuilder UseFIEncrypt(this IApplicationBuilder builder){
            return builder.UseMiddleware<FIEncryptMiddleware>();
        }
    }
}