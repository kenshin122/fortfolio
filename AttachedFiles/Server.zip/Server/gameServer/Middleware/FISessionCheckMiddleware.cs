using System;
using Microsoft.AspNetCore.Http;
using System.Globalization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
namespace gameServer{
    public class FISessionCheckMiddleware{
        private readonly RequestDelegate _next;
        private readonly IDistributedCache redis;
        private readonly IOptions<AuthSettings> settings;
        public FISessionCheckMiddleware(RequestDelegate _delegate, IDistributedCache _redis, IOptions<AuthSettings> _settings){
            _next = _delegate;
            redis = _redis;
            settings = _settings;
        }
        public async Task Invoke(HttpContext context){
            var sessID = context.Request.Cookies["sess"];
            if(sessID == null){
                throw new FIException(FIErr.NotLoggedIn);
            }
            // int? userID = await redis.GetIntAsync($"sess{sessID}");
            // string userSess = await redis.GetObjectFromJson();
            string userSessJson = await redis.GetStringAsync($"sess{sessID}");
            var userSess = await JsonConvert.DeserializeObjectAsync<JObject>(userSessJson);
            if(userSess == null){
                throw new FIException(FIErr.ExpiredSession);
            }    
            context.Items["sess"] = userSess;
            await _next(context);
            userSessJson = await JsonConvert.SerializeObjectAsync(context.Items["sess"]);
            await redis.SetStringAsync($"sess{sessID}",userSessJson,new DistributedCacheEntryOptions(){
                AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(settings.Value.sessionExpireTimeHours)
            });
            // await redis.SetIntAsync($"sess{sessID}",userID.Value,new DistributedCacheEntryOptions(){
            //     AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(settings.Value.sessionExpireTimeHours)
            // });
        }
    }
    public static class FISessionCheckMiddlewareExtension{
        public static IApplicationBuilder UseFISessionCheck(this IApplicationBuilder builder){
            return builder.UseMiddleware<FISessionCheckMiddleware>();
        }
    }
}