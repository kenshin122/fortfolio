﻿//#define DEBUG_CONTENTPROVIDER

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Resources.Load를 대신해서 쓰는 클래스
/// 반드시 ContentsLoader를 초기화 한 후 사용해야 한다
/// </summary>
public enum CustomCoroutineRes
{
    MoveNext,
    RemoveFromQueue,
}
public class Coroutiner : MonoBehaviour
{
}

public partial class ContentsProvider
{
    static ContentsProvider singleton;
    public static ContentsProvider Instance
    {
        get
        {
            if (singleton == null)
            {
                singleton = new ContentsProvider();
            }
            return singleton;
        }
    }

    private Coroutiner coroutiner;
    private void StartCoroutine(IEnumerator enumer)
    {
        if (coroutiner == null)
        {
            var go = GameObject.Find("Coroutiner");
            if (go == null)
            {
                go = new GameObject("Coroutiner");
                coroutiner = go.AddComponent<Coroutiner>();
                GameObject.DontDestroyOnLoad(go);
            }
            else
            {
                coroutiner = go.GetComponent<Coroutiner>();
            }
        }
        coroutiner.StartCoroutine(enumer);
		return;
    }
    private ContentsLoadConfig _config;
    private ContentsLoadConfig config
    {
        get
        {
            if (_config == null)
            {
                _config = Resources.Load<ContentsLoadConfig>("ContentsLoadConfig");
                if (_config == null)
                {
                    throw new System.Exception("[Contents Instance] Need ContentsLoadConfig Asset. Create ContentsLoadConfig by Right Mouse button click on Resources folder, and choose Contents/Create ContentsLoadConfig");
                }
            }
            return _config;
        }
    }
    private Dictionary<string, ContentsProviderOperation> assetOperDic = new Dictionary<string, ContentsProviderOperation>();
    private ContentsProviderSceneOperation sceneOper;
    private Dictionary<int, List<GameObject>> reservedFreeablePrefabDic = new Dictionary<int, List<GameObject>>();
    private Dictionary<System.Type,string> _typeToExtensionDic;
    private Dictionary<System.Type,string> typeToExtensionDic{
        get{
            if(_typeToExtensionDic == null){
                _typeToExtensionDic = new Dictionary<System.Type,string>();
                _typeToExtensionDic.Add(typeof(GameObject),".prefab");
                _typeToExtensionDic.Add(typeof(Material),".mat");
            }
            return _typeToExtensionDic;
        }
    }
    /// <summary>
    /// 절대 호출하지 말것 ContentsLoader에서 사용하는 함수임.
    /// </summary>
    public void _Initialize(){
        assetOperDic.Clear();
        sceneOper = null;
        foreach(var pair in abDic){
            if(pair.Value.assetBundle != null){
                pair.Value.assetBundle.Unload(true);
            }
        }
        abDic.Clear();
    }
    public T LoadComponentInAsset<T>(string path, int freeMemFlag = ContentsFreeFlag.WhenSceneChanges) where T : MonoBehaviour
    {
        var res = LoadAsset<GameObject>(path, freeMemFlag);
        if (res == null)
            return null;
        return res.GetComponent<T>();
    }
    /// <summary>
    /// 원하는 타입의 리소스를 Path로부터 가져온다
    /// ContentsLoadConfig가 loadFromRemote=true 이면 Resources.Load 역할을 하고
    /// false일때는 AssetBundle로부터 가져온다
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    public T LoadAsset<T>(string path, int freeMemFlag = ContentsFreeFlag.WhenSceneChanges) where T : UnityEngine.Object
    {
        var res = LoadAsset(path, typeof(T), freeMemFlag);
        if (res == null)
        {
            return null;
        }
        return (T)res;
    }
    /// <summary>
    /// 원하는 타입의 리소스를 Path로부터 가져온다
    /// ContentsLoadConfig가 loadFromRemote=true 이면 Resources.Load 역할을 하고
    /// false일때는 AssetBundle로부터 가져온다
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    public Object LoadAsset(string path, System.Type typeInfo = null, int freeMemFlag = ContentsFreeFlag.WhenSceneChanges)
    {
        if (ContentsLoader.Instance.CurrentState != ContentsLoader.State.Usable)
            throw new System.Exception("[Contents LoadAsset] Not Initialized. Call ContentsLoader.StartInitialize first!");

        //Debug.Log("[ContentsProvider LoadAsset] Load Asset="+path);
#if DEBUG_CONTENTPROVIDER
        var rootSample = ContentsProfiling.Instance.StartSample(ContentsProfileType.LoadAsset, path);
#endif
        ////////////////////////////////////////////////////////////////////////////////
        /// 애셋번들 관련 Operation 생성
        ////////////////////////////////////////////////////////////////////////////////
        ContentsProviderOperation oper = null;
        if (assetOperDic.ContainsKey(path) == true)
        {
            oper = assetOperDic[path];
            if (oper.freeMemoryFlag != freeMemFlag)
            {
                Debug.LogWarningFormat("[ContentsProvider LoadAsset] Memory Free Flag has been changed from {0} to {1} for asset {2}\n It might not be desired situation so check if its right",
                oper.freeMemoryFlag, freeMemFlag, path);
                oper.freeMemoryFlag = freeMemFlag;
            }
        }
        else
        {
            oper = new ContentsProviderOperation();
            oper.freeMemoryFlag = freeMemFlag;
            assetOperDic.Add(path, oper);
        }

        ////////////////////////////////////////////////////////////////////////////////
        /// 이미 작업이 다 끝났다면 그냥 넘겨주면 된다
        ////////////////////////////////////////////////////////////////////////////////
        if (oper.isDone == true)
        {
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            if(oper.asset == null){
                if(typeInfo != null){
                    Debug.LogWarningFormat("[ContentsProvider LoadAsset] There is no asset called={0} type={1}",path,typeInfo.Name);
                }else{
                    Debug.LogWarningFormat("[ContentsProvider LoadAsset] There is no asset called={0}",path);
                }
            }
            //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] 1 Path={0}",path);
            return oper.asset;
        }
        else
        {
            //작업이 안끝났다. 비동기 상황에서 발생한 경우에는 강제로 끝내버린다.
            if (oper.isAsync == true)
            {
				Debug.LogWarningFormat("[ContentsProvider LoadAsset] Already in LoadAssetAsync. Don't use sync async simultaneously");
#if DEBUG_CONTENTPROVIDER
				rootSample.EndSample();
#endif
                //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] 2 Ended Path={0}",path);
				return null;
            }
            //그게아니라면 계속 로딩 진행..
        }
#if DEBUG_CONTENTPROVIDER
        ContentsProfile_Sample sample = null;
#endif
        ////////////////////////////////////////////////////////////////////////////////
        /// 로컬에서 가져오는거라면 로컬에서 가져온다.
        ////////////////////////////////////////////////////////////////////////////////
        if (config.loadFromRemote == false)
        {
            Object res = null;
#if DEBUG_CONTENTPROVIDER
            sample = rootSample.StartInnerSample(ContentsProfileType.LoadAssetActual, path);
#endif
            if (typeInfo != null)
            {
                res = Resources.Load(path, typeInfo);
            }
            else
            {
                res = Resources.Load(path);
            }
#if DEBUG_CONTENTPROVIDER
            sample.EndSample();
#endif
            if (res == null)
            {
                Debug.LogWarning("[ContentsProvider LoadAsset] No asset for path=" + path);
            }
            oper.asset = res;
            oper.currentProgressInValue = 1.0f;
            oper.isDone = true;
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] 3 Ended Path={0}",path);
            return res;
        }

        ////////////////////////////////////////////////////////////////////////////////
        /// 리소스가 애셋번들에 존재하는것을 확인하는 것보다, 현재 로컬에 리소스가 있는지 체크를 하는게 더 빠르다.
        ////////////////////////////////////////////////////////////////////////////////
        Object localRes = null;
#if DEBUG_CONTENTPROVIDER
        sample = rootSample.StartInnerSample(ContentsProfileType.LoadAssetActualCheck, path);
#endif
        if (typeInfo != null)
        {
            localRes = Resources.Load(path, typeInfo);
        }
        else
        {
            localRes = Resources.Load(path);
        }
#if DEBUG_CONTENTPROVIDER
        sample.EndSample();
#endif


        if (localRes != null)
        {
            oper.asset = localRes;
            oper.currentProgressInValue = 1.0f;
            oper.isDone = true;
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] 4 Ended Path={0}",path);
            return localRes;
        }

        ////////////////////////////////////////////////////////////////////////////////
        /// 번들 로딩
        ////////////////////////////////////////////////////////////////////////////////
        var pathLower = path.ToLower();
        if (oper.abLoaded == false)
        {
            //애셋번들은 기본적으로 lower case문자들로 동작한다. 그래서 다 바꿔줘야 함.
            oper.assetName = System.IO.Path.GetFileName(pathLower);
            oper.assetBundleName = pathLower.Remove(pathLower.LastIndexOf(oper.assetName, System.StringComparison.InvariantCultureIgnoreCase)).Trim('/');
            oper.assetName = oper.assetName.ToLower();
            oper.assetBundleName = oper.assetBundleName.ToLower();

            if (ContentsLoader.Instance.AssetBundleNameHash.Contains(oper.assetBundleName) == false)
            {
                var singleAssetBundleName = pathLower;
                int slideIdx = pathLower.IndexOf('/');
                if(slideIdx >= 0){
                    singleAssetBundleName = pathLower.Remove(slideIdx);
                }
                //단일 애셋번들에 포함되어 있는 것일 수도 있다.
                if (ContentsLoader.Instance.AssetBundleNameHash.Contains(singleAssetBundleName) == false)
                {
                    //단일 애셋어도 포함안되있다. 이건 그냥 존재하지 않는 리소스이기 때문에 빈 것을 돌려줌
                    Debug.LogWarningFormat("[ContentsProvider LoadAsset] Cannot find asset path={0} singleAssetBundle={1} pathLower={2}",path,singleAssetBundleName,pathLower);
#if DEBUG_CONTENTPROVIDER
                    rootSample.EndSample();
#endif
                    oper.asset = null;
                    oper.isDone = true;
                    oper.abLoaded = true;
                    oper.currentProgressInValue = 1.0f;
                    //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] 5 Ended Path={0}",path);
                    return null;
                }
                //단일애셋번들에 포함된 리소스이다.
                oper.assetBundleName = singleAssetBundleName;
                oper.isSingleAssetBundle = true;
            }
            //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] Path={0} LoadAssetBundle",path);
#if DEBUG_CONTENTPROVIDER
            var ab = this.LoadAssetBundle(oper.assetBundleName, rootSample);
#else
            var ab = this.LoadAssetBundle(oper.assetBundleName, null);
#endif
            //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] Path={0} End LoadAssetBundle",path);
            oper.abLoaded = true;
            oper.assetBundle = ab;
        }

        ////////////////////////////////////////////////////////////////////////////////
        /// 애셋번들 로딩을 했었고, 그래도 애셋번들이 없다면 이건 그냥 로드 못함.
        ////////////////////////////////////////////////////////////////////////////////
        if (oper.assetBundle == null)
        {
            Debug.LogWarningFormat("[ContentsProvider LoadAsset] There is no assetBundle {0} and cant get resource from path={1}\n{2}",oper.assetBundleName,path,oper.err);
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            oper.asset = null;
            oper.isDone = true;
            oper.currentProgressInValue = 1.0f;
            //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] 6 Ended Path={0}",path);
            return null;
        }

        ////////////////////////////////////////////////////////////////////////////////
        /// 리소스를 애셋번들로부터 가져오기
        ////////////////////////////////////////////////////////////////////////////////
        var properAssetName = string.Empty;
        if (oper.isSingleAssetBundle == true)
        {
            var expectedName = pathLower;
            if(typeInfo != null){
                if(typeToExtensionDic.ContainsKey(typeInfo) == true)
                    expectedName = string.Format("{0}{1}",pathLower,typeToExtensionDic[typeInfo]);
                else
                    Debug.LogWarningFormat("[ContentsProvider LoadAsset] No vaild type {0} extension not found path {1}",typeInfo.Name,path);
            }
            foreach (var filePath in oper.assetBundle.GetAllAssetNames())
            {
                if (filePath.Contains(expectedName))
                {
                    properAssetName = filePath;
                    break;
                }
            }
            if(string.IsNullOrEmpty(properAssetName) == true){
                Debug.LogWarningFormat("[ContentsProvider LoadAsset] There is no asset {0} in assetBundle {1} expectedName {2}",path,oper.assetBundleName,expectedName);
                #if DEBUG_CONTENTPROVIDER
                rootSample.EndSample();
                #endif
                oper.asset = null;
                oper.isDone = true;
                oper.currentProgressInValue = 1.0f;
                //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] 7 Ended Path={0}",path);
                return null;
            }
        }
        else
        {
            properAssetName = oper.assetName;
        }

        Object gotAsset = null;

#if DEBUG_CONTENTPROVIDER
        sample = rootSample.StartInnerSample(ContentsProfileType.LoadAssetActualFromAB, path);
#endif
        if (typeInfo != null)
        {
            gotAsset = oper.assetBundle.LoadAsset(properAssetName, typeInfo);
        }
        else
        {
            gotAsset = oper.assetBundle.LoadAsset(properAssetName);
        }
#if DEBUG_CONTENTPROVIDER
        sample.EndSample();
#endif
        if (gotAsset == null)
        {
            Debug.LogWarningFormat("[ContentsProvider LoadAsset] There is no assetPath {0} inside assetBundle {1} properAssetName {2} typeof {3} ", path, oper.assetBundleName, properAssetName, typeInfo.Name);
        }
        oper.asset = gotAsset;
        oper.currentProgressInValue = 1.0f;
        oper.isDone = true;
#if DEBUG_CONTENTPROVIDER
        rootSample.EndSample();
#endif
        //ContentsProfiling.LeaveLog("[ContentsProvider LoadAsset] 8 Ended Path={0}",path);
        return gotAsset;
    }
    /// <summary>
    /// LoadAsset의 비동기 버전
    /// </summary>
    /// <param name="path">
    /// 리소스 경로
    /// </param>
    /// <param name="onRes">
    /// 로드가 완료되면 delegate를 통해 받고 싶을때 사용
    /// </param>
    /// <returns>
    /// 비동기 로딩 정보 및 결과를 담고있는 Operation 객체
    /// </returns>
    public IContentProviderOperation LoadAssetAsync(string path, System.Action<Object> onRes = null, System.Type typeInfo = null, int freeMemFlag = ContentsFreeFlag.WhenSceneChanges)
    {
        if (ContentsLoader.Instance.CurrentState != ContentsLoader.State.Usable)
            throw new System.Exception("[Contents LoadAsset] Not Initialized. Call ContentsLoader.StartInitialize first!");
        //이미 있는 작업 중에 넘겨준다.
        if (assetOperDic.ContainsKey(path) == true)
        {
            var assetOper = assetOperDic[path];
            if (assetOper.freeMemoryFlag != freeMemFlag)
            {
                Debug.LogWarningFormat("[ContentsProvider LoadAssetAsync] Memory Free Flag has been changed from {0} to {1} for asset {2}\n It might not be desired situation so check if its right",
                assetOper.freeMemoryFlag, freeMemFlag, path);
                assetOper.freeMemoryFlag = freeMemFlag;
            }
            //만약 작업이 다 끝났다면 그냥 넘겨주면 된다.
            if (assetOper.isDone == false)
            {
                if (onRes != null)
                {
                    assetOper.callbackForResultList.Add(onRes);
                }
                return assetOper;
            }
            if (onRes != null)
                onRes(assetOper.asset);
            return assetOper;
        }

        ContentsProviderOperation oper = new ContentsProviderOperation();
        if (onRes != null)
            oper.callbackForResultList.Add(onRes);
        oper.freeMemoryFlag = freeMemFlag;
        oper.path = path;
        oper.isAsync = true;
        assetOperDic.Add(path, oper);
        oper.enumeration = LoadAssetSequence(oper, typeInfo);
        StartCoroutine(oper.enumeration);
        return oper;
    }
    IEnumerator LoadAssetSequence(ContentsProviderOperation oper, System.Type typeInfo)
    {
#if DEBUG_CONTENTPROVIDER
        var rootSample = ContentsProfiling.Instance.StartSample(ContentsProfileType.LoadAsset, oper.path + " Async");
        ContentsProfile_Sample actualSample = null;
#endif

        //로컬 리소스를 가져올 때는 그냥 유니티 함수로 가져온다.
        if (config.loadFromRemote == false)
        {
            ResourceRequest resOper = null;
#if DEBUG_CONTENTPROVIDER
            actualSample = rootSample.StartInnerSample(ContentsProfileType.LoadAssetActual, oper.path + " Async");
#endif
            if (typeInfo != null)
            {
                resOper = Resources.LoadAsync(oper.path, typeInfo);
            }
            else
            {
                resOper = Resources.LoadAsync(oper.path);
            }
            while (resOper.isDone == false)
            {
                oper.currentProgressInValue = resOper.progress;
                yield return null;
            }
#if DEBUG_CONTENTPROVIDER
            actualSample.EndSample();
#endif
            oper.isDone = true;
            oper.asset = resOper.asset;
            oper.err = ContentsProviderError.CANNOT_FIND_RESOURCES_FROM_LOCAL;
            if (resOper.asset == null)
            {
                Debug.LogWarning("[ContentsProvider LoadAssetSequence] No asset for path=" + oper.path);
            }
            foreach (var listener in oper.callbackForResultList)
            {
                listener.Invoke(oper.asset);
            }
            oper.callbackForResultList.Clear();
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            yield break;
        }

        //이미 리소스가 로컬에 있는 것이면 그것을 가져온다. 애셋번들에 없을 수도 있기 때문.
        //Resources.Exists(path) 처럼 리소스가 존재하는지 체크를 할 수가 없기 때문에 그냥 일단 로드해보는 것.
        ResourceRequest localResOper = null;
#if DEBUG_CONTENTPROVIDER
        actualSample = rootSample.StartInnerSample(ContentsProfileType.LoadAssetActualCheck, oper.path + " Async");
#endif
        if (typeInfo != null)
        {
            localResOper = Resources.LoadAsync(oper.path, typeInfo);
        }
        else
        {
            localResOper = Resources.LoadAsync(oper.path);
        }

        while (localResOper.isDone == false)
        {
            oper.currentProgressInValue = localResOper.progress;
            yield return null;
        }
#if DEBUG_CONTENTPROVIDER
        actualSample.EndSample();
#endif
        if (localResOper.asset != null)
        {
            oper.currentProgressInValue = 1.0f;
            oper.isDone = true;
            oper.asset = localResOper.asset;
            foreach (var listener in oper.callbackForResultList)
            {
                listener.Invoke(oper.asset);
            }
            oper.callbackForResultList.Clear();
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            yield break;
        }


        //애셋번들은 lower case이기 때문에 변경해준다.
        oper.currentProgressInValue = 0.0f;
        var pathLower = oper.path.ToLower();
        var assetName = System.IO.Path.GetFileName(pathLower);
        var assetBundleName = pathLower.Remove(pathLower.LastIndexOf(assetName, System.StringComparison.InvariantCultureIgnoreCase)).Trim('/');
        var isSingleAsset = false;
        assetName = assetName.ToLower();
        assetBundleName = assetBundleName.ToLower();

        //애셋번들이 단일애셋번들인지 아닌지 판별.
        var abArr = ContentsLoader.Instance.ABManifest.GetAllAssetBundles();
        if (ContentsLoader.Instance.AssetBundleNameHash.Contains(assetBundleName) == false)
        {
            var singleAssetBundleName = pathLower.Remove(pathLower.IndexOf('/'));
            if (ContentsLoader.Instance.AssetBundleNameHash.Contains(singleAssetBundleName) == false)
            {
                Debug.LogWarningFormat("[ContentsProvider LoadAsset] Cannot find asset path={0} singleAssetBundle={1} pathLower={2}",oper.path,singleAssetBundleName,pathLower);
                // foreach (var abName in ContentsLoader.Instance.AssetBundleNameHash)
                // {
                //     Debug.Log(abName);
                // }
                oper.err = ContentsProviderError.CANNOT_FIND_RESOURCES;
                oper.isDone = true;
                oper.asset = null;
                foreach (var listener in oper.callbackForResultList)
                {
                    listener.Invoke(oper.asset);
                }
                oper.callbackForResultList.Clear();
#if DEBUG_CONTENTPROVIDER
                rootSample.EndSample();
#endif
                yield break;
            }
            //단일애셋번들이다.
            assetBundleName = singleAssetBundleName;
            isSingleAsset = true;
        }
#if DEBUG_CONTENTPROVIDER
        var abOper = this.LoadAssetBundleAsync(assetBundleName, rootSample);
#else
        var abOper = this.LoadAssetBundleAsync(assetBundleName, null);
#endif
        while (abOper.isDone == false)
        {
            oper.currentProgressInValue = abOper.progress / 2.0f;
            yield return null;
        }
        if (string.IsNullOrEmpty(abOper.error) == false || abOper.assetBundle == null)
        {
            Debug.LogWarningFormat("[ContentsProvider LoadAssetSequence] Cannot Load Asset {0} because cannot load assetBundle={1}",oper.path,assetBundleName);
            oper.asset = null;
            oper.currentProgressInValue = 1.0f;
            oper.isDone = true;
            oper.err = ContentsProviderError.CANNOT_FIND_ASSETBUNDLE;
            foreach (var listener in oper.callbackForResultList)
            {
                listener.Invoke(oper.asset);
            }
            oper.callbackForResultList.Clear();
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            yield break;
        }

        //단일애셋번들일 경우 이름을 고쳐준다.
        var properAssetName = string.Empty;
        if (isSingleAsset == true)
        {
            var expectedName = pathLower;
            if(typeInfo != null){
                if(typeToExtensionDic.ContainsKey(typeInfo) == true)
                    expectedName = string.Format("{0}{1}",pathLower,typeToExtensionDic[typeInfo]);
                else
                    Debug.LogWarningFormat("[ContentsProvider LoadAsset] No vaild type {0} extension not found path {1}",typeInfo.Name,oper.path);
            }
            foreach (var filePath in abOper.assetBundle.GetAllAssetNames())
            {
                if (filePath.Contains(expectedName))
                {
                    properAssetName = filePath;
                    break;
                }
            }
            if(string.IsNullOrEmpty(properAssetName) == true){
                Debug.LogWarningFormat("[ContentsProvider LoadAsset] There is no asset {0} in assetBundle {1} expectedName {2}",oper.path,oper.assetBundleName,expectedName);
                oper.asset = null;
                oper.currentProgressInValue = 1.0f;
                oper.isDone = true;
                oper.err = ContentsProviderError.CANNOT_FIND_ASSETBUNDLE;
                foreach (var listener in oper.callbackForResultList)
                {
                    listener.Invoke(oper.asset);
                }
                oper.callbackForResultList.Clear();
                #if DEBUG_CONTENTPROVIDER
                rootSample.EndSample();
                #endif
                yield break;
            }
        }
        else
        {
            properAssetName = assetName;
        }

        AssetBundleRequest loadOper = null;
#if DEBUG_CONTENTPROVIDER
        actualSample = rootSample.StartInnerSample(ContentsProfileType.LoadAssetActualFromAB, oper.path + " Async");
#endif
        if (typeInfo != null)
        {
            loadOper = abOper.assetBundle.LoadAssetAsync(properAssetName, typeInfo);
        }
        else
        {
            loadOper = abOper.assetBundle.LoadAssetAsync(properAssetName);
        }
        while (loadOper.isDone == false)
        {
            oper.currentProgressInValue = 0.5f + (float)loadOper.progress / 2.0f;
            yield return null;
        }
#if DEBUG_CONTENTPROVIDER
        actualSample.EndSample();
#endif
        if (loadOper.asset == null)
        {
            Debug.LogWarning("[ContentsProvider LoadAssetSequence] Cannot find asset " + properAssetName + " from assetBundle " + assetBundleName + " path=" + pathLower);
            oper.isDone = true;
            oper.currentProgressInValue = 1.0f;
            oper.err = ContentsProviderError.CANNOT_FIND_RESOURCES_FROM_ASSETBUNDLE;
            foreach (var listener in oper.callbackForResultList)
            {
                listener.Invoke(oper.asset);
            }
            oper.callbackForResultList.Clear();
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            yield break;
        }
        oper.assetBundle = abOper.assetBundle;
        oper.isDone = true;
        oper.currentProgressInValue = 1.0f;
        oper.err = ContentsProviderError.FINE;
        oper.asset = loadOper.asset;
        foreach (var listener in oper.callbackForResultList)
        {
            listener.Invoke(oper.asset);
        }
        oper.callbackForResultList.Clear();
#if DEBUG_CONTENTPROVIDER
        rootSample.EndSample();
#endif
    }

    /// <summary>
    /// Scene을 동기로 로딩한다
    /// loadFromRemote가 false이면 일반 유니티 LoadScene과 동일
    /// true면 애셋번들을 통해 로딩한다
    /// 만약 LoadSceneAsync가 진행되는 도중에 호출하면 실행이 안될것이다
    /// </summary>
    /// <param name="sceneName"></param>
    /// <param name="mode"></param>
    /// <returns></returns>
    public void LoadScene(string sceneName, LoadSceneMode mode = LoadSceneMode.Single)
    {
        if (sceneOper != null)
        {
            throw new System.Exception("[ContentsProvider LoadScene] Cannot load scene while loading " + sceneOper.path + " current=" + sceneName);
        }
#if DEBUG_CONTENTPROVIDER
        var rootSample = ContentsProfiling.Instance.StartSample(ContentsProfileType.LoadScene, sceneName);
#endif
        bool isReadFromLocal = config.loadFromRemote == false || Application.CanStreamedLevelBeLoaded(sceneName);
        //로컬 씬을 읽어들인다.
        if (isReadFromLocal)
        {
            //Scene AssetBundle을 로드하였다면 이제 원래 씬매니저 호출 함수로 로드가 가능해진다.
            //Scene전환되면서 어짜피 Scene이 Resources.UnloadUnused를 호출할테니.. 레퍼런스만 지워준다.
            SetMemoryFreeEvent(ContentsFreeFlag.WhenSceneChanges, false);
#if DEBUG_CONTENTPROVIDER
            var actSample = rootSample.StartInnerSample(ContentsProfileType.LoadSceneActual, sceneName);
#endif
            UnityEngine.SceneManagement.SceneManager.LoadScene(sceneName, mode);
#if DEBUG_CONTENTPROVIDER
            actSample.EndSample();
#endif
            return;
        }
        //먼저 Scene애셋을 애셋번들로부터 읽어들여야 한다.
        var lowerCaseSceneName = sceneName.ToLower();
        var modifiedSceneName = string.Format("scenes/{0}", lowerCaseSceneName);

#if DEBUG_CONTENTPROVIDER
        var ab = this.LoadAssetBundle(modifiedSceneName, rootSample);
#else
        var ab = this.LoadAssetBundle(modifiedSceneName, null);
#endif
        if (ab == null)
        {
#if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
#endif
            throw new System.Exception("[ContentsProvider LoadScene] There is no assetbundle for scene " + modifiedSceneName);
        }
        //Scene AssetBundle을 로드하였다면 이제 원래 씬매니저 호출 함수로 로드가 가능해진다.
        //Scene전환되면서 어짜피 Scene이 Resources.UnloadUnused를 호출할테니.. 레퍼런스만 지워준다.
        SetMemoryFreeEvent(ContentsFreeFlag.WhenSceneChanges, false);
#if DEBUG_CONTENTPROVIDER
        var actualSample = rootSample.StartInnerSample(ContentsProfileType.LoadSceneActual, sceneName);
#endif
        UnityEngine.SceneManagement.SceneManager.LoadScene(sceneName, mode);
#if DEBUG_CONTENTPROVIDER
        actualSample.EndSample();
#endif
    }

    /// <summary>
    /// Scene을 비동기로 로딩한다
    /// loadFromRemote가 false이면 일반 유니티 LoadScene과 동일
    /// true면 애셋번들을 통해 로딩한다
    /// LoadAssetAsync 함수들과 달리, 현재 Scene이 로딩중에는 호출이 안된다는 것이다
    /// 주의할 것
    /// </summary>
    /// <param name="sceneName"></param>
    /// <param name="mode"></param>
    /// <returns></returns>
    public IContentProviderSceneOperation LoadSceneAsync(string sceneName, LoadSceneMode mode = LoadSceneMode.Single)
    {
        if (sceneOper != null)
        {
            throw new System.Exception("[ContentsProvider LoadSceneAsync] Cannot load scene while loading " + sceneOper.path + " current=" + sceneName);
        }
        sceneOper = new ContentsProviderSceneOperation();
        sceneOper.path = sceneName;
        StartCoroutine(LoadSceneAsyncSequence(sceneOper, mode));
        return sceneOper;
    }
    private IEnumerator LoadSceneAsyncSequence(ContentsProviderSceneOperation oper, LoadSceneMode mode)
    {
#if DEBUG_CONTENTPROVIDER
        var rootSample = ContentsProfiling.Instance.StartSample(ContentsProfileType.LoadScene, oper.path);
#endif
        bool isReadFromLocal = config.loadFromRemote == false || Application.CanStreamedLevelBeLoaded(oper.path);
        //로컬 씬을 읽어들인다.
        if (isReadFromLocal)
        {
            //Scene AssetBundle을 로드하였다면 이제 원래 씬매니저 호출 함수로 로드가 가능해진다.
            //Scene전환되면서 어짜피 Scene이 Resources.UnloadUnused를 호출할테니.. 레퍼런스만 지워준다.
			if(mode != LoadSceneMode.Additive)
            	SetMemoryFreeEvent(ContentsFreeFlag.WhenSceneChanges, false);
#if DEBUG_CONTENTPROVIDER
            var tempSample = rootSample.StartInnerSample(ContentsProfileType.LoadSceneActual, oper.path);
#endif
            var newSceneOper = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(oper.path, mode);
            while (newSceneOper.isDone == false)
            {
                oper.currentProgressInValue = newSceneOper.progress;
                yield return null;
            }
            oper.currentProgressInValue = 1.0f;
            yield return null;
            oper.isDone = true;
            sceneOper = null;
#if DEBUG_CONTENTPROVIDER
            tempSample.EndSample();
            rootSample.EndSample();
#endif
            yield break;
        }

        //먼저 Scene애셋을 애셋번들로부터 읽어들여야 한다.
        var lowerCaseSceneName = oper.path.ToLower();
        var modifiedSceneName = string.Format("scenes/{0}", lowerCaseSceneName);
        #if DEBUG_CONTENTPROVIDER
        var abOper = this.LoadAssetBundleAsync(modifiedSceneName, rootSample);
        #else
        var abOper = this.LoadAssetBundleAsync(modifiedSceneName, null);
        #endif
        while (abOper.isDone == false)
        {
            oper.currentProgressInValue = abOper.progress / 2.0f;
            yield return null;
        }
        if (string.IsNullOrEmpty(abOper.error) == false)
        {
            Debug.LogErrorFormat("[ContentsProvider LoadSceneAsyncSequence] Cannot Find AssetBundle for Scene {0}\nAssetBundleErr={1}", modifiedSceneName,abOper.error);
            oper.err = ContentsProviderError.CANNOT_FIND_SCENE_ASSETBUNDLE;
            oper.currentProgressInValue = 1.0f;
            oper.isDone = true;
            sceneOper = null;
            #if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
            #endif
            yield break;
        }

        //Scene AssetBundle을 로드하였다면 이제 원래 씬매니저 호출 함수로 로드가 가능해진다.
        //Scene전환되면서 어짜피 Scene이 Resources.UnloadUnused를 호출할테니.. 레퍼런스만 지워준다.
		if(mode != LoadSceneMode.Additive)
        	SetMemoryFreeEvent(ContentsFreeFlag.WhenSceneChanges, false);
        #if DEBUG_CONTENTPROVIDER
        var actualSceneSample = rootSample.StartInnerSample(ContentsProfileType.LoadSceneActual, oper.path);
        #endif
        //ContentsProvider.PrintLog("ContentsProvider BeforeSceneAsync");
		Debug.LogWarningFormat("[ContentsProvider LoadSceneAsync] Start loading Scene {0}",oper.path);
        var nextSceneOper = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(oper.path, mode);
        //ContentsProvider.PrintLog("ContentsProvider AfterSceneAsync");
        // nextSceneOper.allowSceneActivation = false;
		nextSceneOper.allowSceneActivation = false;
        while (nextSceneOper.progress < 0.9f)
        {
            oper.currentProgressInValue = 0.5f + nextSceneOper.progress / 2.0f;
            yield return null;
        }
		nextSceneOper.allowSceneActivation = true;
		Debug.LogWarningFormat("[ContentsProvider LoadSceneAsync] Scene {0} Ready",oper.path);
        #if DEBUG_CONTENTPROVIDER
        actualSceneSample.EndSample();
        #endif
        oper.currentProgressInValue = 1.0f;
        oper.isDone = true;
        sceneOper = null;
        #if DEBUG_CONTENTPROVIDER
        rootSample.EndSample();
        #endif
    }

    /// <summary>
    /// 메모리를 해제해야 할 시점에 ContentsFreeFlag에 정의된 값을 쓰거나, 사용자가 정의한 Flag값을 쓰면 된다
    /// 호출된 시점에 지정된 플래그의 리소스에 대한 참조를 없애버린다
    /// 참고로 만약 Scene에 LoadAsset을 통해 얻은 GameObject가 생존해 있다면, 해당 리소스는 메모리에서 안내려올 것이다
    /// 이건 비단 다른 Asset들도 마찬가지. 참조하는 곳이 있으면 메모리로부터 내려오지 않는다
    /// 만약 플래그가 호출됬을때 삭제되길 바란다면,
    /// </summary>
    /// <param name="freeMemFlag">정의된 플래그 이름.ContentsFreeFlag나 사용자 정의 Flag</param>
    /// <param name="shouldCallUnloadAsset">레퍼런스를 날린 후에 Resources.UnloadUnusedAsset을 호출할 것인가 말 것인가</param>
    public void SetMemoryFreeEvent(int freeMemFlag, bool shouldCallUnloadAsset = true)
    {
        //리소스를 로딩중인것들이 있을 수 있음. 얘내들은 일단 로딩이 다 끝난후에 정리할지 말아야할지를 정해야 한다.
        foreach (var pair in assetOperDic)
        {
            if (pair.Value.isDone == true)
                continue;
            if (pair.Value.isAsync == false)
                continue;
			//NotDoneProcess..
			Debug.LogWarningFormat("[ContentsProvider SetMemoryFreeEvent] Will not remove that is on loading {0}",pair.Value.assetName);
        }

        //선별한다..
        var listOfNeedToBeRemoved = (from oper in assetOperDic
                                     where ((oper.Value.freeMemoryFlag & freeMemFlag) > 0) && oper.Value.isDone == true
                                     select oper.Key).ToList();
        foreach (var key in listOfNeedToBeRemoved)
        {
            var oper = assetOperDic[key];
            assetOperDic.Remove(key);
        }
//        Debug.LogWarningFormat("[ContentsProvider SetMemoryFreeEvent] Freeing total={0} assets by event {1}", listOfNeedToBeRemoved.Count, freeMemFlag);
        if (listOfNeedToBeRemoved.Count > 0)
        {
            if (shouldCallUnloadAsset == true)
                Resources.UnloadUnusedAssets();
        }
    }

    /// <summary>
    /// Shader.Find를 대체할 함수이다. Shader.Find는 로컬에서 셰이더를 가져오겠지만, 애셋번들에 포함된 셰이더는 가져오지 못한다.
    /// 따라서 로컬이든 애셋번들이든 있으면 알아서 가져온다.
    /// </summary>
    /// <param name="name">셰이더 이름</param>
    /// <returns></returns>
    public Shader LoadShaderByName(string name){
        #if DEBUG_CONTENTPROVIDER
        var rootSample = ContentsProfiling.Instance.StartSample(ContentsProfileType.LoadShader,name);
        #endif

        if( ContentsLoader.Instance.CurrentState != ContentsLoader.State.Usable){
            Debug.LogWarningFormat("[ContentsProvider LoadShaderByName] Need ContentsLoader to initialized!");
            #if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
            #endif
            return null;
        }

        if (config.loadFromRemote == false)
        {
            var tempRes = Shader.Find(name);
            #if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
            #endif
            return tempRes;
        }

        //일단 번들에 있는건지 체크하고..
        if( ContentsLoader.Instance.Info.shaderDic.ContainsKey(name) == false){
            //없으면 혹시 로컬에 있나?
            var foundShader = Shader.Find(name);
            if(foundShader == null){
                Debug.LogWarningFormat("[ContentsProvider LoadShaderByName] Cannot find shader name={0}",name);
                #if DEBUG_CONTENTPROVIDER
                rootSample.EndSample();
                #endif
                return null;
            }
            #if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
            #endif
            return foundShader;
        }
        
        //번들에 있다.
        var shaderInfo = ContentsLoader.Instance.Info.shaderDic[name];
        #if DEBUG_CONTENTPROVIDER
        var ab = LoadAssetBundle(shaderInfo.assetBundleName,rootSample);
        #else
        var ab = LoadAssetBundle(shaderInfo.assetBundleName,null);
        #endif
        if(ab == null){
            Debug.LogWarningFormat("[ContentsProvider LoadShaderByName] Cannot find assetBundle {0} for shader {1}",shaderInfo.assetBundleName,name);
            #if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
            #endif
            return null;
        }
        var res = ab.LoadAsset(shaderInfo.path,typeof(Shader));
        if(res == null){
            Debug.LogWarningFormat("[ContentsProvider LoadShaderByName] Cannot find shader name={0} in assetBundle={1}",name,shaderInfo.assetBundleName);
            #if DEBUG_CONTENTPROVIDER
            rootSample.EndSample();
            #endif
            return null;
        }
        #if DEBUG_CONTENTPROVIDER
        rootSample.EndSample();
        #endif
        return (Shader)res;
    }

    //임시코드임. 이거 풀링으로 빼내야돼.
    // 에셋번들을 로드 할 수 있으며 오브젝트 풀링에 추가한다.
    public Transform CreateAssetInPool(string poolName, string path)
    {
        if (string.IsNullOrEmpty(path))
        {
#if UNITY_EDITOR
            Debug.Log("path " + path + " is Null or Empty");
#endif
            return null;
        }

        if (string.IsNullOrEmpty(poolName))
        {
#if UNITY_EDITOR
            Debug.Log("poolName " + poolName + " is Null or Empty");
#endif
            return null;
        }

        GameObject assetPref = LoadAsset<GameObject>(path);
        if (null == assetPref)
        {
#if UNITY_EDITOR
            Debug.Log("LoadPrefab " + path + " is Fail.");
#endif
            return null;
        }
        Transform objTrsf = null;
        //Sunny
        //if (_globalConfig.Pooling)
        //{
        //    objTrsf = PoolManager.Pools.Spawn(poolName, assetPref);
        //}
        //if (null != objTrsf)
        //    return objTrsf;

        //Not use Pool
        var go = GameObject.Instantiate<GameObject>(assetPref);
        if (null != go)
        {
            objTrsf = go.transform;
        }

        return objTrsf;
    }





    // Dictionary<string,List<string>> abDependencyDic = new Dictionary<string,List<string>>();
    // int depthChecker = 0;
    // public ABNode GetDependentMapAsNode(){
    // 	var rootNode = new ABNode();
    // 	rootNode.key = "root";
    // 	var dic = new Dictionary<string,ABNode>();
    // 	foreach(var pair in abDependencyDic){
    // 		var childNode = SetABNodeRecursive(pair.Key,dic);
    // 		rootNode.childList.Add(childNode);
    // 	}
    // 	//깊이를 체크
    // 	foreach(var pair in dic){
    // 		depthChecker = 0;
    // 		HashSet<ABNode> hash = new HashSet<ABNode>();

    // 		CheckDepthRecursive(0,pair.Value,hash);

    // 		pair.Value.depth = depthChecker;
    // 	}

    // 	rootNode.childList = (from item in rootNode.childList
    // 	orderby item.depth descending
    // 	select item).ToList();
    // 	PrintNodeRecursive(0,rootNode);
    // 	return rootNode;
    // }
    // public void CheckDepthRecursive(int depth, ABNode root,HashSet<ABNode> hash){
    // 	hash.Add(root);
    // 	if(depthChecker<depth)
    // 		depthChecker = depth;
    // 	foreach(var child in root.childList){
    // 		if(hash.Contains(child))
    // 			continue;
    // 		CheckDepthRecursive(depth+1,child,hash);
    // 	}
    // 	hash.Remove(root);
    // }
    // private ABNode SetABNodeRecursive(string key,Dictionary<string,ABNode> dic){
    // 	if(dic.ContainsKey(key)==true){
    // 		return dic[key];
    // 	}

    // 	ABNode rootNode = new ABNode();
    // 	rootNode.key = key;
    // 	dic.Add(key,rootNode);
    // 	foreach(var dep in abDependencyDic[rootNode.key]){
    // 		ABNode childNode = SetABNodeRecursive(dep,dic);
    // 		rootNode.childList.Add(childNode);
    // 		if(rootNode.depth<childNode.depth)
    // 			rootNode.depth = childNode.depth;
    // 	}
    // 	return rootNode;
    // }
    // private void PrintNodeRecursive(int depth, ABNode node){
    // 	System.Text.StringBuilder builder = new System.Text.StringBuilder();
    // 	for(int i = 0 ; i <depth ; i++){
    // 		builder.Append("\t");
    // 	}
    // 	builder.AppendFormat(node.key);
    // 	Debug.Log(builder.ToString()+" Dep="+node.depth.ToString());
    // 	foreach(var dep in node.childList){
    // 		PrintNodeRecursive(depth+1,dep);
    // 	}
    // }
    // private string GetTab(int count){
    // 	switch(count){
    // 		case 0:
    // 		return "";
    // 		case 1:
    // 		return "\t";
    // 		case 2:
    // 		return "\t\t";
    // 		case 3:
    // 		return "\t\t\t";
    // 		case 4:
    // 		return "\t\t\t\t";
    // 		case 5:
    // 		return "\t\t\t\t\t";
    // 		case 6:
    // 		return "\t\t\t\t\t\t";
    // 		case 7:
    // 		return "\t\t\t\t\t\t\t";
    // 		case 8:
    // 		return "\t\t\t\t\t\t\t\t";
    // 		case 9:
    // 		return "\t\t\t\t\t\t\t\t\t";
    // 		case 10:
    // 		return "\t\t\t\t\t\t\t\t\t\t";
    // 		case 11:
    // 		return "\t\t\t\t\t\t\t\t\t\t\t";
    // 		case 12:
    // 		return "\t\t\t\t\t\t\t\t\t\t\t\t";
    // 		default:
    // 		throw new System.Exception("WTF?");
    // 	}
    // }
    // string startedTraceStr;
    // Stack<string> abStack = new Stack<string>();
    //동기적으로 로드하는거라면 스킵해야 하기 때문에..




}