﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContentsProfiling{
	public static bool isShowDebug = false;
	private static ContentsProfiling singleton;
	public static ContentsProfiling Instance{
		get{
			if(singleton == null){
				singleton = new ContentsProfiling();
			}
			return singleton;
		}
	}
	public List<ContentsProfile_Sample> SampleList = new List<ContentsProfile_Sample>();
	public ContentsProfile_Sample StartSample(ContentsProfileType type,string info){
		var sample = new ContentsProfile_Sample();
		sample.type = type;
		sample.startTime = System.DateTime.Now;
		SampleList.Add(sample);
		return sample;
	}
	static bool isStarted = false;
	static System.DateTime startTime;
	public static void LeaveLog(string file,params object[] args){
		bool initialized = false;
		if(isStarted == false){
			initialized = true;
			isStarted = true;
			startTime = System.DateTime.Now;
		}
		var elapsed = System.DateTime.Now - startTime;
		var str = string.Format(file,args);
		if(initialized == true)
			System.IO.File.AppendAllText("ProfileLog.txt","Initialized\n");
		System.IO.File.AppendAllText("ProfileLog.txt",string.Format("{0} {1}\n",elapsed.TotalSeconds,str));
	}
}
public class ContentsProfile_Sample{
	public ContentsProfileType type;
	public string info;
	public System.DateTime startTime;
	public System.TimeSpan elapsedTime;
	public List<ContentsProfile_Sample> innerSamples = new List<ContentsProfile_Sample>();
	public ContentsProfile_Sample StartInnerSample(ContentsProfileType type,string info){
		var newItem = new ContentsProfile_Sample();
		newItem.type = type;
		newItem.info = info;
		newItem.startTime = System.DateTime.Now;
		newItem.elapsedTime = System.TimeSpan.FromMilliseconds(-1);
		innerSamples.Add(newItem);
		return newItem;
	}
	public void EndSample(){
		elapsedTime = System.DateTime.Now - startTime;
	}
}
public enum ContentsProfileType{
	LoadAsset,
	LoadAssetActual,
	LoadAssetActualCheck,
	LoadAssetActualFromAB,
	LoadAssetBundle,
	LoadAssetBundle_WWW,
	LoadAssetBundle_Load,
	LoadAssetBundleGetDependency,
	LoadAssetBundleDependency,
	GetAllDependency,
	LoadScene,
	LoadSceneActual,
	FreeMemory,
}
