﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 메모리 Free 시점에 대한 정의
/// 비트 연산 1<<5 까진 ContentsProvider에서 사용하니 이후 값을 사용 부탁
/// </summary>
public class ContentsFreeFlag{
	public const int LiveForever = 0;
	public const int WhenSceneChanges = 1 << 0;
	public const int TestFlag = 1 << 1;
}
