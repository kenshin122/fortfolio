﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IContentProviderOperation{
	ContentsProviderError Err{get;}
	bool IsDone{ get; }
	float CurrentProgressInValue{get;}
	UnityEngine.Object Asset{ get; }
	T GetAsset<T>()where T:UnityEngine.Object;
}
public interface IContentProviderSceneOperation{
	ContentsProviderError Err{get;}
	bool IsDone{ get; }
	float CurrentProgressInValue{get;}
}