﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class ABNode{
	public string key;
	public List<ABNode> childList = new List<ABNode>();
	public int depth;
}
/*
 * 애셋번들 관련된 처리 루틴을 모아놓은 스크립트
 */
public partial class ContentsProvider{
	Dictionary<string,AssetBundleLoadOperation> abDic = new Dictionary<string, AssetBundleLoadOperation>();
	Queue<AssetBundleLoadOperation> abQueue = new Queue<AssetBundleLoadOperation>();
	public IEnumerator asyncEnumerator;

	private AssetBundle LoadAssetBundle(string assetBundleName,ContentsProfile_Sample rootSample,int depth = 0,bool readDependency = true){
		#if DEBUG_CONTENTPROVIDER
		var abSample = rootSample.StartInnerSample(ContentsProfileType.LoadAssetBundle,assetBundleName+" cnt="+abDic.Count.ToString());
		#endif
		AssetBundleLoadOperation returnOper = null;
		
		//이미 작업이 있다.
		if (abDic.ContainsKey (assetBundleName) == true) {
			returnOper = abDic [assetBundleName];
			//안끝난 작업이다. 로드 못함!
			if(returnOper.isDone == false){
				string errMsg = string.Format("[ContentsProvider LoadAssetBundle] AssetBundle={0} Is In LoadAssetBundleAsync Process.",assetBundleName);
				Debug.LogWarning(errMsg);
				#if DEBUG_CONTENTPROVIDER
				abSample.EndSample();
				#endif
				//ContentsProfiling.LeaveLog("[ContentsProvider LoadAssetBundle] Not Ready={0}",assetBundleName);
				return null;
			}
			//끝났지만 애셋번들이 없음.
			if(returnOper.assetBundle == null){
				string errMsg = string.Format("[ContentsProvider LoadAssetBundle] AssetBundle={0} Cannot Load AssetBundle",assetBundleName);
				Debug.LogWarning(errMsg);
				#if DEBUG_CONTENTPROVIDER
				abSample.EndSample();
				#endif
				//ContentsProfiling.LeaveLog("[ContentsProvider LoadAssetBundle] Ready {0} But No AssetBundle",assetBundleName);
				return null;
			}
			#if DEBUG_CONTENTPROVIDER
			abSample.EndSample();
			#endif
			//ContentsProfiling.LeaveLog("[ContentsProvider LoadAssetBundle] Ready {0} Giving",assetBundleName);
			return returnOper.assetBundle;
		}else{
			//없다. 새로 만들어준다.
			returnOper = new AssetBundleLoadOperation();
			returnOper.assetBundleName = assetBundleName;
			returnOper.progress = 1.0f;
			//동기기 때문에 그냥 isDone true로해도됨.
			returnOper.isDone = true;
			abDic.Add (assetBundleName, returnOper);
			
		}

		//본인 애셋이 존재하지도 않는다면.. 굳이 로드할필요도 없지 않은가.
		if( ContentsLoader.Instance.AssetBundleNameHash.Contains(assetBundleName) == false){
			string errMsg = string.Format("[ContentsProvider LoadAssetBundle] AssetBundle={0} Does not exist in AssetBundleManifest",assetBundleName);
			Debug.LogWarning(errMsg);
			returnOper.error = errMsg;
			#if DEBUG_CONTENTPROVIDER
			abSample.EndSample();
			#endif
			//ContentsProfiling.LeaveLog("[ContentsProvider LoadAssetBundle] Not exists {0}",assetBundleName);
			return null;
		}

		//ContentsProfiling.LeaveLog("[ContentsProvider LoadAssetBundle] Creating New {0}",assetBundleName);
		if(readDependency == true){
			//연관 애셋번들도 로드해주어야 한다.
			#if DEBUG_CONTENTPROVIDER
			var getDepSample = abSample.StartInnerSample(ContentsProfileType.LoadAssetBundleGetDependency,assetBundleName+" cnt="+abDic.Count.ToString());
			#endif
			var dependencies = ContentsLoader.Instance.ABManifest.GetAllDependencies(assetBundleName);
			#if DEBUG_CONTENTPROVIDER
			getDepSample.EndSample();
			#endif
			if (dependencies.Length > 0) {
				#if DEBUG_CONTENTPROVIDER
				var depSample = abSample.StartInnerSample(ContentsProfileType.LoadAssetBundleDependency,assetBundleName+" cnt="+abDic.Count.ToString());
				#endif
				// var depList = new List<string>();
				//ContentsProfiling.LeaveLog("[ContentsProvider LoadAssetBundle] Start Dependency={0}",assetBundleName);
				foreach (var dep in dependencies) {
					//만약 이미 로드한 애셋이면 그냥 넘겨주겠지
					#if DEBUG_CONTENTPROVIDER
					var depAB = LoadAssetBundle (dep,depSample,depth+1,false);
					#else
					var depAB = LoadAssetBundle (dep,null,depth+1,false);
					#endif
				}
				//ContentsProfiling.LeaveLog("[ContentsProvider LoadAssetBundle] End Dependency={0}",assetBundleName);
				#if DEBUG_CONTENTPROVIDER
				depSample.EndSample();
				#endif
			}
		}

		//애셋번들을 로드
		#if DEBUG_CONTENTPROVIDER
		var wwwSample = abSample.StartInnerSample(ContentsProfileType.LoadAssetBundle_WWW,assetBundleName+" cnt="+abDic.Count.ToString());
		#endif
		var abPath = string.Format("{0}/{1}",ContentsLoader.Instance.contentPath,assetBundleName);
		var assetBundle = AssetBundle.LoadFromFile(abPath);
		#if DEBUG_CONTENTPROVIDER
		wwwSample.EndSample();
		#endif
		if (assetBundle == null) {
			string errMsg = string.Format("[ContentsProvider LoadAssetBundle] AssetBundle={0} Cannot Load AssetBundle",assetBundleName);
			Debug.LogWarning(errMsg);
			returnOper.error = errMsg;
			#if DEBUG_CONTENTPROVIDER
			abSample.EndSample();
			#endif
			return null;
		}
		returnOper.assetBundle = assetBundle;
		#if DEBUG_CONTENTPROVIDER
		abSample.EndSample();
		#endif
		//ContentsProfiling.LeaveLog("[ContentsProvider LoadAssetBundle] Done={0}",assetBundleName);
		return assetBundle;
	}

	//비동기로 애셋번들을 로드한다
	private AssetBundleLoadOperation LoadAssetBundleAsync(string assetBundleName,ContentsProfile_Sample rootSample){
		//이미 있는 애셋번들작업이면 그걸 줘야 함.
		if (abDic.ContainsKey (assetBundleName) == true) {
			// Debug.Log("[ContentsProvider LoadAssetBundleAsync] Giving already ab="+assetBundleName);
			var resOper = abDic[assetBundleName];
			if(resOper.isDone == true)
				if(resOper.assetBundle == null)
					Debug.LogWarningFormat("[ContentsProvider LoadAssetBundleAsync] AssetBundle {0} Not Exists",resOper.assetBundleName);
			return abDic [assetBundleName];
		}

		var oper = new AssetBundleLoadOperation ();
		oper.assetBundleName = assetBundleName;
		oper.sample = rootSample;
		abQueue.Enqueue(oper);
		abDic.Add(assetBundleName,oper);
		if(asyncEnumerator == null){
			asyncEnumerator = ProcessAssetBundleQueue();
			StartCoroutine( asyncEnumerator );
		}
		return oper;
	}
	
	IEnumerator ProcessAssetBundleQueue(){
		// AssetBundleLoadOperation oper = notReadyABDic.
		while(true){
			if(abQueue.Count <= 0)
				break;
			var toDoOper = abQueue.Dequeue();
			//Debug.Log("Queue Loading AssetBundle Dependency="+toDoOper.assetBundleName);
			// ContentsProfiling.LeaveLog("Queue Loading AssetBundle Dependency="+toDoOper.assetBundleName);
			yield return LoadAssetBundleSequence(toDoOper,toDoOper.sample);
			//Debug.Log("Queue End Loading AssetBundle Dependency="+toDoOper.assetBundleName);
			// ContentsProfiling.LeaveLog("Queue End Loading AssetBundle Dependency="+toDoOper.assetBundleName);
		}
		asyncEnumerator = null;
	}

	IEnumerator LoadAssetBundleSequence(AssetBundleLoadOperation oper,ContentsProfile_Sample rootSample, bool shouldLoadDependency = true){
		#if DEBUG_CONTENTPROVIDER
		var abSample = rootSample.StartInnerSample(ContentsProfileType.LoadAssetBundle,oper.assetBundleName+" Async"+" cnt="+abDic.Count.ToString());
		#endif
		//Debug.Log("Loading AssetBundle="+oper.assetBundleName);
		// ContentsProfiling.LeaveLog("Loading AssetBundle="+oper.assetBundleName);
		//본인 애셋이 존재하지도 않는다면.. 굳이 로드할필요도 없지 않은가.
		if( ContentsLoader.Instance.AssetBundleNameHash.Contains(oper.assetBundleName) == false){
			oper.error = string.Format("[ContentsProvider LoadAssetBundleSequence] AssetBundle={0} Does not exist in AssetBundleManifest",oper.assetBundleName);
			oper.progress = 1.0f;
			oper.isDone = true;
			#if DEBUG_CONTENTPROVIDER
			abSample.EndSample();
			#endif
			yield break;
		}
		
		List<AssetBundleLoadOperation> depList = null;
		if(shouldLoadDependency == true){
			//Debug.Log("Loading AssetBundle Dependency="+oper.assetBundleName);
			// ContentsProfiling.LeaveLog("Loading AssetBundle="+oper.assetBundleName);
			var totalOperList = new List<AssetBundleLoadOperation>();
			depList = new List<AssetBundleLoadOperation>();
			var alreadyOperList = new List<AssetBundleLoadOperation>();
			#if DEBUG_CONTENTPROVIDER
			var depGetSample = abSample.StartInnerSample(ContentsProfileType.LoadAssetBundleGetDependency,oper.assetBundleName+" Async");
			#endif
			string[] dependencies = ContentsLoader.Instance.ABManifest.GetAllDependencies(oper.assetBundleName);

			#if DEBUG_CONTENTPROVIDER
			depGetSample.EndSample();
			var depSample = abSample.StartInnerSample(ContentsProfileType.LoadAssetBundleDependency,oper.assetBundleName+" Async"+" cnt="+abDic.Count.ToString());
			#endif
			foreach(var dep in dependencies){
				if(abDic.ContainsKey(dep)==true){
					totalOperList.Add(abDic[dep]);
					alreadyOperList.Add(abDic[dep]);
					continue;
				}
				var depOper = new AssetBundleLoadOperation();
				depOper.assetBundleName = dep;
				#if DEBUG_CONTENTPROVIDER
				depOper.sample = depSample;
				#endif
				depList.Add(depOper);
				abDic.Add(dep,depOper);
				totalOperList.Add(depOper);
			}
			yield return 2.0f;
			foreach(var dep in depList){
				#if DEBUG_CONTENTPROVIDER
				StartCoroutine(LoadAssetBundleSequence(dep,depSample,false));
				#else
				StartCoroutine(LoadAssetBundleSequence(dep,null,false));
				#endif
			}

			//다른 애셋번들들이 로드가 다 끝날때까지 기다린다
			while (true) {
				float sumOfPercentages = 0;
				for (int i = 0; i < totalOperList.Count; i++) {
					sumOfPercentages += totalOperList [i].progress;
				}
				sumOfPercentages = (sumOfPercentages / (float)totalOperList.Count) / 2.0f;
				oper.progress = sumOfPercentages;

				bool isAllLoaded = true;
				foreach(var myOper in depList){
					if(myOper.progress < 1.0f){
						isAllLoaded = false;
						break;
					}
				}
				foreach(var tempOper in alreadyOperList){
					if(tempOper.isDone == false){
						isAllLoaded = false;
						break;
					}
				}
				if (isAllLoaded == true) {
					break;
				}
				yield return null;
			}
			//Debug.Log("Done Loading AssetBundle Dependency="+oper.assetBundleName);
			#if DEBUG_CONTENTPROVIDER
			depSample.EndSample();
			#endif
		}

		//본인의 애셋번들을 로드한다
		// ContentsProfiling.LeaveLog("LoadingSelfAssetBundle="+oper.assetBundleName);
		// var hash = ContentsLoader.Instance.ABManifest.GetAssetBundleHash( oper.assetBundleName);
		#if DEBUG_CONTENTPROVIDER
		var actualSample = abSample.StartInnerSample(ContentsProfileType.LoadAssetBundle_WWW,oper.assetBundleName+" Async"+" cnt="+abDic.Count.ToString());
		#endif
		var abPath = string.Format("{0}/{1}",ContentsLoader.Instance.contentPath,oper.assetBundleName);
		var abOper = AssetBundle.LoadFromFileAsync(abPath);
		while(abOper.isDone){
			oper.progress = 0.5f + (abOper.progress / 2.0f);
			yield return null;
		}
		oper.progress = 1.0f;
		#if DEBUG_CONTENTPROVIDER
		actualSample.EndSample();
		#endif
		var actualAB = abOper.assetBundle;
		if (actualAB == null) {
			oper.error = "www.assetBundle null";
			// www.Dispose ();
			Debug.Log ("There is no ab "+oper.assetBundleName);
			#if DEBUG_CONTENTPROVIDER
			abSample.EndSample();
			#endif
			MarkUsableToAll(shouldLoadDependency,oper,depList);
			yield break;
		}
		oper.assetBundle = actualAB;
		MarkUsableToAll(shouldLoadDependency,oper,depList);
		#if DEBUG_CONTENTPROVIDER
		abSample.EndSample();
		#endif
	}
	void MarkUsableToAll(bool shouldLoadDependency, AssetBundleLoadOperation originOper, List<AssetBundleLoadOperation> relatedOperList){
		originOper.progress = 1.0f;
		if(shouldLoadDependency == false)
			return;
		originOper.isDone = true;
		foreach(var oper in relatedOperList){
			oper.isDone = true;
		}
	}
}
