﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class ContentsProvider{
	private class AssetBundleLoadOperation{
        public bool isDone;
		// public IEnumerator enumerator;
		public AssetBundle assetBundle;
		public string assetBundleName;
		public float progress;
		//To check whether loaded but failed..
		public string error;
        public ContentsProfile_Sample sample;
	}
	private class ContentsProviderOperation:IContentProviderOperation{
		public ContentsProviderError err;
		public bool isDone;
		public float currentProgressInValue;
		public UnityEngine.Object asset;
		public ContentsProviderError Err{get{ return err; }}
		public bool IsDone{ get{ return isDone; }}
		public float CurrentProgressInValue{get{ return currentProgressInValue; }}
		public UnityEngine.Object Asset{ get { return asset; } }
		public T GetAsset<T>()where T:UnityEngine.Object{
			return (T)asset;
		}
		//This is for internal use only
		public bool isAsync;
		public IEnumerator enumeration;
		public string path;
		public string assetName;
		public int freeMemoryFlag;
		public string assetBundleName;
		public bool isSingleAssetBundle;
		public AssetBundle assetBundle;
		public bool abLoaded;
		public List<System.Action<Object>> callbackForResultList = new List<System.Action<Object>>();
	}
	private class ContentsProviderSceneOperation:IContentProviderSceneOperation{
		public ContentsProviderError err;
		public bool isDone;
		public float currentProgressInValue;
		public ContentsProviderError Err{get{ return err; }}
		public bool IsDone{ get{ return isDone; }}
		public float CurrentProgressInValue{get{ return currentProgressInValue; }}
		//This is for internal use only
		public string path;
	}
}