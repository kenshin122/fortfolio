﻿namespace AssetService
{
	public static class ContentsGlobal
	{
		public static readonly string AppName = "ProjectM";
		public static readonly string ContentsInfoFilename = "contents-info.json";
		public static readonly string ManifestName = "Assetbundles";
		public static readonly string ShareName = "Share";
		public static readonly string LocalRepositoryPath = "ContentsRepository";
		public static readonly string ResourcesAssetbundlesRootPath = "Assets/_Assetbundles";
		public static readonly string ResourcesSharePath = "Assets/Resources/_Share";

		// TODO: 제거, 젠킨스에서 콘트롤 하도록 변경 예정.
		public static readonly string LogValidateAssetbundlesFile = "log-validate-assetbundles.txt";

		public static readonly string LogSyncAssetbundlesFile = "log-sync-assetbundles.txt";
		public static readonly string LogBuildAssetbundlesFile = "log-build-assetbundles.txt";

		public static readonly string PropertyBuildContentsVersionKey = "FROM_UNITY_BUILD_CONTENTS_VERSION";
		public static readonly string PropertyRepositoryPathKey = "FROM_UNITY_REPOSITORY_PATH";
		public static readonly string PropertyBuildContentsPathKey = "FROM_UNITY_BUILD_CONTENTS_PATH";
		public static readonly string PropertyBuildContentsSizeKey = "FROM_UNITY_BUILD_CONTENTS_SIZE";
		public static readonly string PropertyBuildContentsUncompressPathKey = "FROM_UNITY_BUILD_CONTENTS_UNCOMPRESS_PATH";
		public static readonly string PropertyBuildContentsUncompressSizeKey = "FROM_UNITY_BUILD_CONTENTS_UNCOMPRESS_SIZE";
		public static readonly string PropertyPrevContentsPathKey = "FROM_UNITY_PREV_CONTENTS_PATH";
		public static readonly string PropertyValidateAssetbundlesLogPathKey = "FROM_UNITY_VALIDATE_LOG_PATH";
	}
}