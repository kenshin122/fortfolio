﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName="ContentsLoadConfig",menuName="Contents/Create ContentsLoadConfig",order=1)]
public class ContentsLoadConfig : ScriptableObject {
	[Tooltip("ContentsProvider.LoadAsset이 CDN으로부터 가져올지 아니면 로컬에서 가져올지 결정하는 여부")]
	public bool loadFromRemote = false;
	[Tooltip("빌드할때 애셋번들대상 리소스들을 project 바깥으로 빼낼지 말지 결정")]
	public bool moveFolderWhenBuild = false;
	[Tooltip("Obsolete 사용하지 않음")]
	public bool debugRuntimeABDependency = false;
	public string contentsInfoFilename = "contents-info.json";
	public string manifestName = "Assetbundles";
	[Tooltip("애셋번들을 가져올 CDN 주소")]
	public string repositoryPath = "https://cdn.red-mobile.co.kr/ContentsRepository/";
}
