﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
using System;

public partial class ContentsLoader{
	IEnumerator InitializationSequence(InitOperation oper,System.Action<Err,string> onRes){
		curState = State.Initializing;
        var url = Path.Combine (config.repositoryPath, Utilities.Utility.GetPlatformName ()).Replace (@"\", "/");

        //리비전 번호를 가져온다.
        var revUrl = url+"/rev.txt";
        var revInfoWWW = new WWW(revUrl);
        yield return revInfoWWW;
        if(string.IsNullOrEmpty(revInfoWWW.error) == false){
            curState = State.NeedInitialization;
			if(onRes!=null)
				onRes (Err.CANNOT_GET_REV_INFO, revInfoWWW.error);
			oper.err = Err.CANNOT_GET_REV_INFO;
			oper.errDescription = revInfoWWW.error;
			oper.isDone = true;
			revInfoWWW.Dispose ();
			yield break;    
        }
        revTxt = revInfoWWW.text;
        revInfoWWW.Dispose();

		var contentBaseUrl = string.Format("{0}/{1}",url,revTxt);
		var contentInfoUrl = string.Format("{0}/{1}",contentBaseUrl,config.contentsInfoFilename).Replace (@"\", "/");
        // Debug.Log("ContentBaseURL="+contentBaseUrl);
        // Debug.Log("ContentInfoURL="+contentInfoUrl);

		//First.. Get contents-info file from url..
		Debug.Log(string.Format("[ContentsLoader StartInitializeSequence] Getting url={0}",contentInfoUrl));
		var www = new WWW (contentInfoUrl);
		oper.currentProgressInValue = 0.0f;
		oper.currentProgressDescription = "Getting ContentsInfo From " + contentsInfo;
		while (www.isDone == false) {
			oper.currentProgressInValue = www.progress;
			yield return null;
		}
		oper.currentProgressInValue = 1.0f;
		//Resting for show on display.
		yield return null;

		if (string.IsNullOrEmpty (www.error) == false) {
			curState = State.NeedInitialization;
			if(onRes!=null)
				onRes (Err.CANNOT_GET_CONTENTS_INFO, www.error);
			oper.err = Err.CANNOT_GET_CONTENTS_INFO;
			oper.errDescription = www.error;
			oper.isDone = true;
			www.Dispose ();
			yield break;
		}

		oper.currentProgressInValue = 0.0f;
		oper.currentProgressDescription = "Parsing contentsinfo xml";
		yield return null;
		contentsInfo = JsonConvert.DeserializeObject<ContentsInfo> (System.Text.Encoding.UTF8.GetString (www.bytes));
		www.Dispose ();
		oper.currentProgressInValue = 1.0f;
		oper.currentProgressDescription = "Done parsing contentsinfo xml";
		yield return null;











		//Load AssetBundleManifest..
		var manifestUrl = Path.Combine (contentBaseUrl, config.manifestName+"/"+config.manifestName).Replace (@"\", "/");
		Debug.Log(string.Format("[ContentsLoader StartInitializeSequence] Getting url={0}",manifestUrl));
		www = new WWW (manifestUrl);
		oper.currentProgressInValue = 0.0f;
		oper.currentProgressDescription = "Getting AssetBundleManifest From " + manifestUrl;
		while (www.isDone == false) {
			oper.currentProgressInValue = www.progress;
			yield return null;
		}
		oper.currentProgressInValue = 1.0f;
		//Resting for show on display.
		yield return null;

		if (string.IsNullOrEmpty (www.error) == false) {
			curState = State.NeedInitialization;
			if(onRes!=null)
				onRes (Err.CANNOT_GET_MANIFEST, www.error);
			oper.err = Err.CANNOT_GET_MANIFEST;
			oper.errDescription = www.error;
			oper.isDone = true;
			www.Dispose ();
			yield break;
		}

		manifest = www.assetBundle.LoadAsset<AssetBundleManifest> ("AssetBundleManifest");
		www.Dispose ();
		







		//Check if needs patch or not.
		Debug.Log(string.Format("[ContentsLoader StartInitializeSequence] Checking needs patch or not"));
		var bundleInfoList = new List<BundleFileInfo> ();
		bundleInfoList.AddRange (contentsInfo.scenebundleList);
		bundleInfoList.AddRange (contentsInfo.assetbundleList);
		patchData = new PatchData ();
		foreach (var info in bundleInfoList) {
			patchData.totalContentsSize += info.size;
			if (CacheManager.IsCached (info.name, info.hash) == false) {
				patchData.patchSize += info.size;
				patchData.patchFileInfoList.Add (info);
			} else {
				patchData.cachedSize += info.size;
			}
		}
		//Dont need patch
		if (patchData.patchFileInfoList.Count <= 0) {
			curState = State.Usable;
			if(config.debugRuntimeABDependency == true){
				var res = Resources.Load("ContentsProfileCanvas");
				GameObject.Instantiate(res);
			}
			
			if(onRes!=null)
				onRes (Err.FINE,string.Empty);
			oper.isDone = true;
			yield break;
		}
		//Need patching.
		curState = State.NeedPatch;
		if(onRes!=null)
			onRes (Err.FINE,string.Empty);
		oper.isDone = true;
	}
}