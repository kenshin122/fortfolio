﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
using System;

public partial class ContentsLoader{
	private class InitOperation:IContentsInitOperation{
		public ContentsLoader.Err err;
		public string errDescription;
		public bool isDone;
		public string currentProgressDescription;
		public float currentProgressInValue;
		public ContentsLoader.Err Err{get{ return err; }}
		public string ErrDescription {get{ return errDescription; }}
		public bool IsDone{ get{ return isDone; }}
		public string CurrentProgressDescription{get{ return currentProgressDescription; }}
		public float CurrentProgressInValue{get{ return currentProgressInValue; }}
	}
	private class PatchOperation:InitOperation,IContentsPatchOperation{
		public float currentSubProgressInValue;
		public float CurrentSubProgressInValue{get{ return currentSubProgressInValue; }}
		public long totalPatchSizeByte;
		public long TotalPatchSizeByte{get{return totalPatchSizeByte;}}
		public long partialPatchSizeByte;
		public long PartialPatchSizeByte{get{return partialPatchSizeByte;}}
		public int totalFileCount;
		public int TotalFileCount{get{return totalFileCount;}}
		public int currentDownloadFileIndex;
		public int CurrentDownloadFileIndex{get{return currentDownloadFileIndex;}}
	}
}
