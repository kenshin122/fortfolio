﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
using System;

public partial class ContentsLoader{
	IEnumerator PatchingSequence(PatchOperation oper, System.Action<Err,string> onRes){
		curState = State.Patching;
		//SetCachableSize
		CacheManager.CachingMaxSize = contentsInfo.assetbundlesSize;

        


		//Need this to redownload.
		var url = Path.Combine (config.repositoryPath, Utilities.Utility.GetPlatformName ()).Replace (@"\", "/");
        var contentBaseUrl = string.Format("{0}/{1}",url,revTxt);
        var contentAssetBundleUrl = string.Format("{0}/{1}",contentBaseUrl,config.manifestName);
		int counter = 0;
		oper.totalPatchSizeByte = contentsInfo.assetbundlesSize;
		oper.totalFileCount = patchData.patchFileInfoList.Count;
		foreach (var info in patchData.patchFileInfoList) {
			oper.partialPatchSizeByte = info.size;
			oper.currentDownloadFileIndex = counter;
			oper.currentProgressInValue = (float)counter / (float)patchData.patchFileInfoList.Count;


			var fileUrl = string.Format("{0}/{1}",contentAssetBundleUrl,info.name);
			var hash = manifest.GetAssetBundleHash( info.name );

			oper.currentSubProgressInValue = 0;
			oper.currentProgressDescription = string.Format ("Downloading {0}", fileUrl);
			yield return null;
			Debug.Log("[ContentsLoader PatchingSequence] Try Download from "+fileUrl+"\n hash="+hash);
			var www = WWW.LoadFromCacheOrDownload(fileUrl, hash );
			while (www.isDone == false) {
				oper.currentSubProgressInValue = www.progress;
				yield return null;
			}
			oper.currentSubProgressInValue = 1.0f;
			yield return null;

			if (string.IsNullOrEmpty (www.error) == false) {
				if (onRes != null)
					onRes (Err.CANNOT_DOWNLOAD_PATCH_FILE, www.error);
				oper.isDone = true;
				oper.err = Err.CANNOT_DOWNLOAD_PATCH_FILE;
				oper.errDescription = www.error;
				www.Dispose ();
				yield break;
			}

			if (www.assetBundle == null) {
				if (onRes != null)
					onRes (Err.CANT_EXTRACT_ASSETBUNDLE, fileUrl);
				oper.isDone = true;
				oper.err = Err.CANT_EXTRACT_ASSETBUNDLE;
				oper.errDescription = fileUrl;
				www.Dispose ();
				yield break;
			}

			www.assetBundle.Unload (true);
			www.Dispose ();

			counter++;
		}
		curState = State.Usable;
		if(config.debugRuntimeABDependency == true){
			var res = Resources.Load("ContentsProfileCanvas");
			GameObject.Instantiate(res);
		}
		oper.isDone = true;
		oper.currentProgressInValue = 1.0f;
		oper.currentSubProgressInValue = 1.0f;
		oper.currentProgressDescription = "Paching done";
		if (onRes != null)
			onRes (Err.FINE, string.Empty);
		
	}
}