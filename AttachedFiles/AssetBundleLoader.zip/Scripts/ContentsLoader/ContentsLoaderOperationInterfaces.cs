﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IContentOperationBase{
	ContentsLoader.Err Err{get;}
	string ErrDescription {get;}
	bool IsDone{ get; }
	string CurrentProgressDescription{get;}
	float CurrentProgressInValue{get;}
}
public interface IContentsInitOperation:IContentOperationBase{
	
}
public interface IContentsPatchOperation:IContentOperationBase{
	float CurrentSubProgressInValue{get;}
	long TotalPatchSizeByte{get;}
	long PartialPatchSizeByte{get;}
	int TotalFileCount{get;}
	int CurrentDownloadFileIndex{get;}
}