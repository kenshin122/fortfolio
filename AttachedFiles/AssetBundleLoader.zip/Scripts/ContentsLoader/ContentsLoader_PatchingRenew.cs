﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
using System;

public partial class ContentsLoader{
	string assetBundleBaseUrl{
		get{
			return string.Format("{0}/{1}",nextRevUrl,config.manifestName);
		}
	}
	IEnumerator PatchingSequenceRenew(PatchOperation oper, System.Action<Err,string> onRes){
		curState = State.Patching;

		//일단 contentsInfo를 받는다.. 여기에 내가 받아야 할 목록이 있기 때문..
		var contentInfoUrl = string.Format("{0}/{1}",nextRevUrl,config.contentsInfoFilename);
		Debug.LogFormat("[ContentsLoader PatchingSequence] Getting ContentsInfo from url={0}",contentInfoUrl);
		var www = new WWW(contentInfoUrl);
		oper.currentProgressInValue = 0.0f;
		oper.currentProgressDescription = "패치 정보를 가져오고 있습니다.";
		while(www.isDone == false){
			oper.currentProgressInValue = www.progress;
			yield return null;
		}
		//에러체크..
		if(string.IsNullOrEmpty(www.error) == false){
			curState = State.NeedPatch;
			oper.currentProgressDescription = "패치 정보를 가져오는데 실패했습니다.";
			if(onRes!=null)
				onRes (Err.CANNOT_GET_CONTENTS_INFO, www.error);
			Debug.LogWarningFormat("[ContentsLoader PatchingSequence] Cannot Get ContentsInfo from url={0}\nerr={1}",contentInfoUrl);
			oper.err = Err.CANNOT_GET_CONTENTS_INFO;
			oper.errDescription = www.error;
			oper.isDone = true;
			www.Dispose ();
			yield break;
		}
		var contentsInfoTxt = www.text;
		contentsInfo = JsonConvert.DeserializeObject<ContentsInfo> (contentsInfoTxt);
		www.Dispose ();

		//받아야 할 것들..
		//지워야 할 것들을 분류한다..
		var listOfNeedAdded = new List<BundleFileInfo>();
		var listOfNeedRemoved = new List<BundleFileInfo>();
		var remoteABList = new List<BundleFileInfo>();
		foreach(var item in contentsInfo.assetbundleList){
			listOfNeedAdded.Add(item);
			remoteABList.Add(item);
		}
		foreach(var item in contentsInfo.scenebundleList){
			listOfNeedAdded.Add(item);
			remoteABList.Add(item);
		}

		var currentHaveList = new List<BundleFileInfo>();
		//로컬에서 contentsInfo를 가져온다. 이녀석이 현재 가지고 있는 녀석들이 있기 떄문..
		var localContentInfoPath = string.Format("{0}/{1}",contentPath,config.contentsInfoFilename);
		ContentsInfo curContentInfo = null;
		if(System.IO.File.Exists(localContentInfoPath) == true){
			var txtInfo = System.IO.File.ReadAllText(localContentInfoPath);
			curContentInfo = JsonConvert.DeserializeObject<ContentsInfo>(txtInfo);	
		}else{
			curContentInfo = new ContentsInfo();
			curContentInfo.assetbundleList = new List<BundleFileInfo>();
			curContentInfo.scenebundleList = new List<BundleFileInfo>();
		}
		//현재보유중인 리스트를 만드는 동시에, 지워져야 할 것들을 위해 지워질 리스트에도 넣는다.
		foreach(var item in curContentInfo.assetbundleList){
			currentHaveList.Add(item);
			listOfNeedRemoved.Add(item);
		}
		foreach(var item in curContentInfo.scenebundleList){
			currentHaveList.Add(item);
			listOfNeedRemoved.Add(item);
		}
		

		//같은것들을 배제하면 새로받을것들이 남는다..
		int idx = 0;
		while(idx <listOfNeedAdded.Count){
			bool isSame = false;
			var item = listOfNeedAdded[idx];
			foreach(var temp in currentHaveList){
				if(temp.name != item.name)
					continue;
				if(temp.crc != item.crc)
					continue;
				if(temp.hash != item.hash)
					continue;
				isSame = true;
				break;
			}
			if(isSame == true){
				listOfNeedAdded.RemoveAt(idx);
			}else{
				idx++;
			}
		}
		//이미 있는 것들에서 Remote에 있는 리스트 것들을 배제하면 지워야 할 게 남는다.
		idx = 0;
		while(idx < listOfNeedRemoved.Count){
			bool isSame = false;
			var item = listOfNeedRemoved[idx];
			foreach(var temp in remoteABList){
				if(temp.name != item.name)
					continue;
				if(temp.crc != item.crc)
					continue;
				if(temp.hash != item.hash)
					continue;
				isSame = true;
				break;
			}
			if(isSame == true){
				listOfNeedRemoved.RemoveAt(idx);
			}else{
				idx++;
			}
		}
		//다 지워.. 지워져야할것들!
		foreach(var item in listOfNeedRemoved){
			var filePath = string.Format("{0}/{1}",contentPath,item.name);
			if(System.IO.File.Exists(filePath)==false)
				continue;
			System.IO.File.Delete(filePath);
		}


		int counter = 0;
		long totalBytes = 0;
		long totalReceivedBytes = 0;
		foreach(var item in listOfNeedAdded)
			totalBytes+=item.size;

		//다운로드를 받는다..
		foreach(var item in listOfNeedAdded){
			//이 셋중 하나인 상황일 수 있음.
			//다운로드중이었거나
			//다운로드받았거나
			//다운로드시작도안했거나

			//이미 받았는지?
			var filePath = string.Format("{0}/{1}",contentPath,item.name);
			if(System.IO.File.Exists(filePath) == true){
				//CRC체크썸을 통해 받은건지 안받은건지 판별..
				
				var crc = Utilities.Utility.GetFileCrc(filePath);
				// Debug.Log("OrigCRC="+item.crc+" calcCRC="+crc);
				if(crc == item.crc){
					//받은거다..
					counter++;
					totalReceivedBytes += item.size;
					Debug.LogFormat("[ContentsLoader PatchingSequence] It's same file. Dont need download again file={0}",filePath);
					continue;
				}else{
					Debug.LogWarningFormat("[ContentsLoader PatchingSequence] Found file that doesn't match name={0}\nIt Might be leftover when downloaded",filePath);
					System.IO.File.Delete(filePath);
				}
			}

			//디렉토리가 없을수도 있다. 만들어주자.
			var downloadRootPath = System.IO.Path.GetDirectoryName(filePath);
			//Debug.Log("RootPath="+downloadRootPath+" FileName="+filePath);
			if(System.IO.Directory.Exists(downloadRootPath) == false)
				System.IO.Directory.CreateDirectory(downloadRootPath);
			
			//받자..
			var abUrl = string.Format("{0}/{1}",assetBundleBaseUrl,item.name);
			var fileWWW = new WWW(abUrl);
			Debug.LogFormat("[ContentsLoader PatchingSequence] Downloading file {0}",abUrl);
			oper.currentProgressInValue = (float)counter / (float)listOfNeedAdded.Count;
			oper.currentProgressDescription = item.name;
			oper.currentDownloadFileIndex = counter;
			while(fileWWW.isDone == false){
				oper.currentSubProgressInValue = fileWWW.progress;
				yield return null;
			}
			Debug.LogFormat("[ContentsLoader PatchingSequence] Done Donwload {0}",abUrl);
			if(string.IsNullOrEmpty(fileWWW.error) == false){
				curState = State.NeedPatch;
				if (onRes != null)
					onRes (Err.CANNOT_DOWNLOAD_PATCH_FILE, fileWWW.error);
				Debug.LogWarningFormat("[ContentsLoader PatchingSequence] Cannot download file from url={0}\nerr={1}",abUrl,fileWWW.error);
				oper.isDone = true;
				oper.err = Err.CANNOT_DOWNLOAD_PATCH_FILE;
				oper.errDescription = fileWWW.error;
				fileWWW.Dispose ();
				yield break;
			}
			System.IO.File.WriteAllBytes(filePath,fileWWW.bytes);
			fileWWW.Dispose();

			counter++;
		}


		//애셋번들 매니페스트도 받는다..
		var abManifestUrl = string.Format("{0}/{1}",assetBundleBaseUrl,config.manifestName);
		www = new WWW(abManifestUrl);
		oper.currentProgressInValue = 0.0f;
		oper.currentProgressDescription = "매니페스트를 받는 중입니다";
		while(www.isDone == false){
			oper.currentProgressInValue = www.progress;
			yield return null;
		}
		oper.currentProgressInValue = 1.0f;
		if(string.IsNullOrEmpty(www.error) == false){
			curState = State.NeedPatch;
			oper.currentProgressDescription = "매니페스트 받기를 실패하였습니다";
			oper.currentProgressInValue = 1.0f;
			if(onRes!=null)
				onRes (Err.CANNOT_GET_MANIFEST, www.error);
			Debug.LogWarningFormat("[ContentsLoader PatchingSequence] Cannot download AssetBundleManifest from url={0}\nerr={1}",abManifestUrl,www.error);
			oper.err = Err.CANNOT_GET_MANIFEST;
			oper.errDescription = www.error;
			oper.isDone = true;
			www.Dispose ();
			yield break;
		}
		var abManifestAB = www.assetBundle;
		if(abManifestAB == null){
			curState = State.NeedPatch;
			oper.currentProgressDescription = "매니페스트 해석이 실패하였습니다";
			oper.currentProgressInValue = 1.0f;
			if(onRes!=null)
				onRes (Err.CANNOT_LOAD_MANIFEST_FROM_ASSETBUNDLE, www.error);
			Debug.LogWarningFormat("[ContentsLoader PatchingSequence] Cannot load AssetBundleManifest from AssetBundle. Might be coruppted. url={0}",abManifestUrl);
			oper.err = Err.CANNOT_LOAD_MANIFEST_FROM_ASSETBUNDLE;
			oper.errDescription = string.Empty;
			oper.isDone = true;
			www.Dispose ();
			yield break;
		}
		manifest = abManifestAB.LoadAsset<AssetBundleManifest>("AssetBundleManifest");
		var abManifestPath = string.Format("{0}/{1}",contentPath,config.manifestName);
		System.IO.File.WriteAllBytes(abManifestPath,www.bytes);
		www.Dispose();

		//현재 ContentsInfo를 덮어씌운다.
		System.IO.File.WriteAllText(localContentInfoPath,contentsInfoTxt);
		//리비젼을 한단계 올린다.
		System.IO.File.WriteAllText(revPath,targetRev.ToString());

		curState = State.Usable;
		oper.isDone = true;
		oper.currentProgressInValue = 1.0f;
		oper.currentSubProgressInValue = 1.0f;
		oper.currentProgressDescription = "패치가 완료되었습니다";
		if(onRes != null)
			onRes(Err.FINE,string.Empty);
		Debug.LogFormat("[ContentsLoader PatchingSequence] Patch Done. Gone to revision {0}",targetRev);
	}
}