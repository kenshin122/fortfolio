﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
using System;

/// <summary>
/// 애셋번들을 받아오는 일을 하는 클래스
/// 이 클래스로 초기화, 패치 후 ContentsProvider로 리소스를 로딩이 가능하다
/// </summary>
public partial class ContentsLoader{
	
	private class PatchData
	{
		public long deviceFreeSpaceSize;
		public long patchSize;
		public long cachedSize;
		public long totalContentsSize;
		public List<BundleFileInfo> patchFileInfoList = new List<BundleFileInfo>();
	}

	public enum State{
		NeedInitialization,
		Initializing,
		NeedPatch,
		Patching,
		Usable
	}

	public enum Err{
		FINE = 0,
		CANNOT_GET_REV_INFO = 1,
		CANNOT_GET_CONTENTS_INFO = 2,
		CANNOT_GET_MANIFEST = 3,
		CANNOT_DOWNLOAD_PATCH_FILE = 4,
		CANT_EXTRACT_ASSETBUNDLE = 5,
		CANNOT_LOAD_MANIFEST_FROM_ASSETBUNDLE = 6,
	}
	static ContentsLoader singleton;
	public static ContentsLoader Instance{
		get{
			if(singleton == null){
//				Debug.LogWarningFormat("[ContentsLoader Instance] Created");
				singleton = new ContentsLoader();
			}
			return singleton;
		}
	}
	// ~ContentsLoader(){
	// 	if(Application.isEditor == false)
	// 		Debug.LogErrorFormat("[ContentsLoader Destructor] Destroyed for no reason");
	// }

	public State CurrentState{ get { return curState; } }
	public AssetBundleManifest ABManifest{get{return manifest;}}
	public State curState;
	private AssetBundleManifest manifest;
	private PatchData patchData;
	private ContentsInfo contentsInfo;
	public ContentsInfo Info{get{return contentsInfo;}}
	private ContentsLoadConfig _config;
	private ContentsLoadConfig config{
		get{
			if(_config == null){
				_config = Resources.Load<ContentsLoadConfig> ("ContentsLoadConfig");
				if (_config == null) {
					throw new System.Exception ("[Contents Instance] Need ContentsLoadConfig Asset. Create ContentsLoadConfig by Right Mouse button click on Resources folder, and choose Contents/Create ContentsLoadConfig");
				}
			}
			return _config;
		}
	}
	private Coroutiner coroutiner;
	private Coroutine StartCoroutine(IEnumerator enumer){
		if(coroutiner == null){
			var go = GameObject.Find("Coroutiner");
			if(go == null){
				go = new GameObject("Coroutiner");
				coroutiner = go.AddComponent<Coroutiner>();
				GameObject.DontDestroyOnLoad(go);
			}else{
				coroutiner = go.GetComponent<Coroutiner>();
			}
		}
		return coroutiner.StartCoroutine(enumer);
	}
	private string revTxt;
	private HashSet<string> _assetBundleHash;
	/*
	 * <summary>
	 * 보유하고 있는 애셋번들 목록을 준다.
	 * </summary>
	 * */
	public HashSet<string> AssetBundleNameHash{
		get{
			if (_assetBundleHash == null) {
				var temp = manifest.GetAllAssetBundles ();
				_assetBundleHash = new HashSet<string> ();
				foreach (var inst in temp) {
					// Debug.Log("Hash="+inst);
					_assetBundleHash.Add (inst.ToLower());
				}
			}
			return _assetBundleHash;
		}
	}

	/// <summary>
	/// ContentsLoader를 초기화하는 작업을 한다. 만약 Resources/ContentsLoadConfig의 LoadFromRemote가 false면, 아무일도 안하고 CurrentState.Usable로 전환된다.
	/// LoadFromRemote가 true일 경우 하는 일은 다음과 같다.
	/// -ContentsLoadConfig의 RepositoryPath로부터 contents-info.xml 파일을 가져온다.
	/// -RepositoryPath로부터 AssetBundleManifest를 가져와서 로딩한다.
	/// -위의 두 파일을 확인 후 패치가 필요하면 CurrentState.NeedPatch로, 패치가 필요없다면 CurrentState.Usable로 전환한다.
	/// </summary>
	/// <param name="onRes">
	/// delegate를 넘겨줘 결과를 받을 수 있다.
	/// </param>
	/// <returns>
	/// 현재 ContentsLoader의 Initialize작업이 얼마나 됬는지에 대한 정보를 얻을 수 있는 객체를 돌려받음.
	/// Coroutine에서 유용하게 쓰인다.
	/// </returns>
	public IContentsInitOperation StartInitialize(bool isForceInit = false,System.Action<Err,string> onRes = null){
		//초기화를강제한다.
		if(isForceInit == true){
			switch(curState){
				case State.Usable:{
					//이전 리소스를 전부 정리한다.
					ContentsProvider.Instance._Initialize();
					curState = State.NeedInitialization;
				}
				break;
				case State.NeedPatch:
				curState = State.NeedInitialization;
				break;
			}
		}
		if (curState != State.NeedInitialization) {
			Debug.LogWarning("[ContentsLoader StartInitialize] Cannot Start Intialize, current state="+curState.ToString());
			return null;
		}
		var oper = new InitOperation ();
		if (config.loadFromRemote == false) {
			curState = State.Usable;
			oper.err = Err.FINE;
			oper.isDone = true;
			if(onRes!=null)
				onRes(Err.FINE, string.Empty);
			return oper;
		}
		// StartCoroutine (InitializationSequence (oper, onRes));
		StartCoroutine(InitializationSequenceRenew(oper,onRes));
		return oper;
	}

	/// <summary>
	/// CurrentState.NeedPatch일때만 패치가 가능
	/// 변경된 애셋번들을 RepositoryPath로부터 다운로드 받는다
	/// </summary>
	/// <param name="onRes">
	/// delegate로 끝났을때 결과를 받고 싶을때
	/// </param>
	/// <returns>
	/// 진행정보에 대한 Operation객체를 돌려줌
	/// </returns>
	public IContentsPatchOperation StartPatching(System.Action<Err,string> onRes = null){
		if (curState != State.NeedPatch) {
			throw new System.Exception ("[ContentsLoader StartPatching] Cannot Patch, current state="+curState.ToString());
		}

		var oper = new PatchOperation ();

		// StartCoroutine (PatchingSequence (oper,onRes));
		StartCoroutine (PatchingSequenceRenew (oper,onRes));
		return oper;
	}


	

	
	
	
}
