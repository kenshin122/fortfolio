﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using System.IO;
using System;

public partial class ContentsLoader{
	string rawUrl{
		get{
			return string.Format("{0}/{1}",config.repositoryPath,Utilities.Utility.GetPlatformName());
		}
	}
	string nextRevUrl{
		get{
			return string.Format("{0}/{1}",rawUrl,targetRev);
		}
	}
	public string contentPath{
		get{
			return string.Format("{0}/{1}",Application.persistentDataPath,"Contents");
		}
	}
	string revPath{
		get{
			return string.Format("{0}/{1}",contentPath,"rev.txt");
		}
	}
	int curRev = -1;
	int targetRev = -1;
	IEnumerator InitializationSequenceRenew(InitOperation oper,System.Action<Err,string> onRes){
		curState = State.Initializing;

        //리비전 번호를 가져온다.
        var revUrl = rawUrl+"/rev.txt";
        var revInfoWWW = new WWW(revUrl);
		oper.currentProgressDescription = "최신정보를 가져오고 있습니다";
		oper.currentProgressInValue = 0.0f;
		while(revInfoWWW.isDone == false){
			oper.currentProgressInValue = revInfoWWW.progress;
			yield return null;
		}
		oper.currentProgressInValue = 1.0f;
        if(string.IsNullOrEmpty(revInfoWWW.error) == false){
			oper.currentProgressInValue = 1.0f;
			oper.currentProgressDescription = "최신정보를 가져오는데 실패했습니다";
            curState = State.NeedInitialization;
			if(onRes!=null)
				onRes (Err.CANNOT_GET_REV_INFO, revInfoWWW.error);
			Debug.LogWarningFormat("[ContentsLoader InitializationSequence] Cannot get revision from url={0}",revUrl);
			oper.err = Err.CANNOT_GET_REV_INFO;
			oper.errDescription = revInfoWWW.error;
			oper.isDone = true;
			revInfoWWW.Dispose ();
			yield break;
        }
        targetRev = System.Convert.ToInt32(revInfoWWW.text);
        revInfoWWW.Dispose();

		//현재 내 리비전 번호를 가져온다.
		curRev = -1;
		if(System.IO.File.Exists(revPath) == true){
			curRev = System.Convert.ToInt32(System.IO.File.ReadAllText(revPath));
		}

		//리비젼 체크
		if(curRev <targetRev){
			//패치필요..
			curState = State.NeedPatch;

		}else if(curRev > targetRev){
			//말도안돼 이건.. 서버쪽 리비전이 내려가버렸네.. 그래도 패치하자..
			curState = State.NeedPatch;
		}else{
			//안해도돼.
			curState = State.Usable;
		}

		if(curState == State.NeedPatch){
			Debug.LogWarningFormat("[ContentsLoader InitializationSequence] Need patch! BeforeRev={0} AfterRev={1}",curRev,targetRev);
			oper.currentProgressDescription = "패치가 필요합니다";
		}else{
			//ContentsInfo를 읽어들인다.
			var localContentInfoPath = string.Format("{0}/{1}",contentPath,config.contentsInfoFilename);
			var txtJson = System.IO.File.ReadAllText(localContentInfoPath);
			//Debug.Log(txtJson);
			contentsInfo = JsonConvert.DeserializeObject<ContentsInfo>(txtJson);
			// foreach(var item in contentsInfo.shaderDic){
			// 	Debug.Log(item.Key);
			// }
			
			//애셋번들매니페스트 로드해둠..
			var manifestPath = string.Format("{0}/{1}",contentPath,config.manifestName);
			var manifestOper = AssetBundle.LoadFromFileAsync(manifestPath);
			oper.currentProgressDescription = "매니페스트를 가져오는 중입니다";
			oper.currentProgressInValue = 0.0f;
			while(manifestOper.isDone == false)
				yield return null;
			oper.currentProgressInValue = 1.0f;
			Debug.LogFormat("[ContentsLoader InitializationSequence] Manifest Loaded");
			manifest = manifestOper.assetBundle.LoadAsset<AssetBundleManifest>("AssetBundleManifest");
			oper.currentProgressDescription = "초기화가 완료되었습니다";
		}

		if( onRes != null)
			onRes(Err.FINE,string.Empty);
		oper.isDone = true;
	}
}