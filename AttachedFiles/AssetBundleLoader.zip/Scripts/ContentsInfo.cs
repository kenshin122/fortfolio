﻿using System;
using System.Collections.Generic;
using Object = UnityEngine.Object;
[Serializable]
public class ContentsInfo
{
	public string appName;
	public string appRevision;
	public string platform;
	public string buildTimestamp;
	public long contentsVersion;
	public string manifestName;
	public long assetbundlesSize;
	public List<BundleFileInfo> scenebundleList;
	public List<BundleFileInfo> assetbundleList;
	public Dictionary<string,ShaderContentsInfo> shaderDic;
}
public class ShaderContentsInfo{
	public string assetBundleName;
	public string path;
}
